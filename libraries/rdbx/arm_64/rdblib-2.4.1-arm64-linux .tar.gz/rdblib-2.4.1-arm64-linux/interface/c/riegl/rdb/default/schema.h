/*
 *******************************************************************************
 *
 *  Copyright 2022 RIEGL Laser Measurement Systems
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  SPDX-License-Identifier: Apache-2.0
 *
 *******************************************************************************
 */
/*!
 *******************************************************************************
 *
 * \author RIEGL LMS GmbH, Austria
 * \brief  Description of RIEGL RDB 2 database file contents
 *
 *  NOTE: All information in this file is preliminary, since the
 *        definition of the database schemas is not yet complete.
 *
 *******************************************************************************
 */

#ifndef RDB_2125FB67_4790_4EE4_BC63_844F2ACC9D90
#define RDB_2125FB67_4790_4EE4_BC63_844F2ACC9D90

// File schema version
const char* const RDB_SCHEMA_VERSION = "7476cf6f";
const char* const RDB_SCHEMA_DATE = "2022-11-09";

// Schema for ".avg.fwa" files
const char* const RDB_SCHEMA_RIEGL_AVG_FWA(
    "{\"identifier\":\"avg.fwa\",\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"r"
    "iegl.gain\",\"riegl.raw_range\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_s"
    "bl_id\",\"riegl.deviation?\",\"riegl.pulse_width?\"],\"extension\":\"avg.fwa\","
    "\"metadata\":[]}"
);

// Schema for ".avg.sbx" files
const char* const RDB_SCHEMA_RIEGL_AVG_SBX(
    "{\"identifier\":\"avg.sbx\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_chann"
    "el\",\"riegl.wfm_sbl_mean\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_o"
    "ffset\",\"riegl.wfm_sda_first\",\"riegl.wfm_sda_count\"],\"extension\":\"avg.s"
    "bx\",\"metadata\":[]}"
);

// Schema for ".avg.sidx" files
const char* const RDB_SCHEMA_RIEGL_AVG_SIDX(
    "{\"identifier\":\"avg.sidx\",\"attributes\":[\"riegl.id\",\"riegl.shot_timestam"
    "p_hr*\",\"riegl.wfm_sbl_first\",\"riegl.wfm_sbl_count\",\"riegl.echo_first?\""
    ",\"riegl.echo_count?\"],\"extension\":\"avg.sidx\",\"metadata\":[\"riegl.shot_i"
    "nfo\",\"riegl.waveform_info\",\"riegl.echo_info?\",\"riegl.waveform_averagin"
    "g_settings\"]}"
);

// Schema for ".avg.sp{C}" files
const char* const RDB_SCHEMA_RIEGL_AVG_SPC(
    "{\"identifier\":\"avg.sp{C}\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_"
    "value\"],\"extension\":\"avg.sp{C}\",\"metadata\":[]}"
);

// Schema for ".cpx" files
const char* const RDB_SCHEMA_RIEGL_CPX(
    "{\"identifier\":\"cpx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_a"
    "ccuracies\",\"riegl.control_object_type\",\"riegl.zenith_vector\",\"riegl.us"
    "ed_for_adjustment\",\"riegl.acquisition_date?\",\"riegl.cp_surface_inclina"
    "tion_angle\",\"riegl.cp_surface_inclination_tolerance_angle\",\"riegl.cp_s"
    "earch_radius?\",\"riegl.cp_maximum_distance?\",\"riegl.import_line_number\""
    "],\"extension\":\"cpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.control_object_"
    "catalog\",\"riegl.item_names\",\"riegl.imported_files\"]}"
);

// Schema for ".doix" files
const char* const RDB_SCHEMA_RIEGL_DOIX(
    "{\"identifier\":\"doix\",\"attributes\":[\"riegl.id\",\"riegl.shot_origin\",\"rie"
    "gl.shot_direction*\",\"riegl.scan_line_index\",\"riegl.shot_index_line\"],\""
    "extension\":\"doix\",\"metadata\":[]}"
);

// Schema for ".fwa" files
const char* const RDB_SCHEMA_RIEGL_FWA(
    "{\"identifier\":\"fwa\",\"attributes\":[\"riegl.id*\",\"riegl.amplitude\",\"riegl"
    ".gain\",\"riegl.raw_range\",\"riegl.wfm_echo_time_offset\",\"riegl.wfm_sbl_i"
    "d\",\"riegl.deviation?\",\"riegl.pulse_width?\"],\"extension\":\"fwa\",\"metadat"
    "a\":[]}"
);

// Schema for ".mpx" files
const char* const RDB_SCHEMA_RIEGL_MPX(
    "{\"identifier\":\"mpx\",\"attributes\":[\"riegl.id\",\"riegl.xy_map*\",\"riegl.am"
    "plitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.timestamp_min?\","
    "\"riegl.timestamp_max?\",\"riegl.point_count\",\"riegl.point_count_grid_cel"
    "l\",\"riegl.pixel_linear_sums?\",\"riegl.pixel_square_sums?\",\"riegl.height"
    "_min\",\"riegl.height_max\",\"riegl.height_mean\",\"riegl.height_center\",\"ri"
    "egl.surface_normal\",\"riegl.pca_thickness\",\"riegl.std_dev\",\"riegl.voxel"
    "_count\"],\"extension\":\"mpx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.pixel_in"
    "fo\",\"riegl.time_base?\"]}"
);

// Schema for ".mtch" files
const char* const RDB_SCHEMA_RIEGL_MTCH(
    "{\"identifier\":\"mtch\",\"attributes\":[\"riegl.xyz*\",\"riegl.plane_reference"
    "s\",\"riegl.plane_patch_distance\",\"riegl.plane_patch_lateral_distance\",\""
    "riegl.plane_patch_link_vector\",\"riegl.id\"],\"extension\":\"mtch\",\"metadat"
    "a\":[\"riegl.plane_patch_matching\"]}"
);

// Schema for ".mvx" files
const char* const RDB_SCHEMA_RIEGL_MVX(
    "{\"identifier\":\"mvx\",\"attributes\":[\"riegl.id\",\"riegl.xyz_map*\",\"riegl.a"
    "mplitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.timestamp_min?\""
    ",\"riegl.timestamp_max?\",\"riegl.point_count\",\"riegl.shape_id\",\"riegl.co"
    "variances?\",\"riegl.pca_axis_min\",\"riegl.pca_axis_max\",\"riegl.pca_exten"
    "ts\",\"riegl.std_dev\",\"riegl.voxel_collapsed\"],\"extension\":\"mvx\",\"metada"
    "ta\":[\"riegl.geo_tag\",\"riegl.time_base?\",\"riegl.voxel_info\"]}"
);

// Schema for ".obsx" files
const char* const RDB_SCHEMA_RIEGL_OBSX(
    "{\"identifier\":\"obsx\",\"attributes\":[\"riegl.xyz\",\"riegl.surface_normal\","
    "\"riegl.plane_slope_class?\",\"riegl.id*\",\"riegl.sda1_plane_patch_one\",\"r"
    "iegl.sda1_plane_patch_two\",\"riegl.sda1_source_file_one\",\"riegl.sda1_so"
    "urce_file_two\"],\"extension\":\"obsx\",\"metadata\":[\"riegl.geo_tag\",\"riegl."
    "plane_slope_class_info?\",\"riegl.pointcloud_info\",\"riegl.sda1_source_fi"
    "les\"]}"
);

// Schema for ".opefx" files
const char* const RDB_SCHEMA_RIEGL_OPEFX(
    "{\"identifier\":\"opefx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz"
    "_accuracies?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.point_cou"
    "nt\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.pl"
    "ane_confidence_normal\",\"riegl.model_fit_quality?\",\"riegl.used_for_adju"
    "stment\",\"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl"
    ".platform_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform"
    "_xyz_ROCS_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\""
    ",\"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"rie"
    "gl.reference_object_id\"],\"extension\":\"opefx\",\"metadata\":[\"riegl.device"
    "\",\"riegl.device_geometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parame"
    "ters\",\"riegl.scan_pattern?\",\"riegl.time_base\",\"riegl.item_names\",\"rieg"
    "l.control_object_reference_file\"]}"
);

// Schema for ".opp" files
const char* const RDB_SCHEMA_RIEGL_OPP(
    "{\"identifier\":\"opp\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_a"
    "ccuracies?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.point_count"
    "\",\"riegl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plan"
    "e_confidence_normal\",\"riegl.model_fit_quality?\",\"riegl.used_for_adjust"
    "ment\",\"riegl.xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.p"
    "latform_rpy_ROCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_x"
    "yz_ROCS_ENU\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\""
    "riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl"
    ".reference_object_id\"],\"extension\":\"opp\",\"metadata\":[\"riegl.device\",\"r"
    "iegl.device_geometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters"
    "\",\"riegl.scan_pattern?\",\"riegl.time_base\",\"riegl.item_names\",\"riegl.co"
    "ntrol_object_reference_file\"]}"
);

// Schema for ".opx" files
const char* const RDB_SCHEMA_RIEGL_OPX(
    "{\"identifier\":\"opx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.contr"
    "ol_object_type\",\"riegl.model_cs_axis_x?\",\"riegl.model_cs_axis_y?\",\"rie"
    "gl.model_cs_axis_z?\",\"riegl.model_fit_quality?\",\"riegl.obs_confidence_"
    "xy?\",\"riegl.obs_confidence_z?\",\"riegl.obs_signal_confidence_rot?\",\"rie"
    "gl.obs_confidence_range?\",\"riegl.obs_confidence_theta?\",\"riegl.obs_con"
    "fidence_phi?\",\"riegl.point_count?\",\"riegl.used_for_adjustment\",\"riegl."
    "xyz_socs\",\"riegl.timestamp\",\"riegl.mirror_facet\",\"riegl.platform_rpy_R"
    "OCS_NED\",\"riegl.platform_drpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\","
    "\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.shift_vector\",\"riegl.raw_ran"
    "ge\",\"riegl.raw_frame_angle\",\"riegl.raw_line_angle\",\"riegl.reference_ob"
    "ject_id\"],\"extension\":\"opx\",\"metadata\":[\"riegl.device\",\"riegl.device_g"
    "eometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan"
    "_pattern?\",\"riegl.time_base\",\"riegl.control_object_catalog\",\"riegl.ite"
    "m_names\",\"riegl.control_object_reference_file\"]}"
);

// Schema for ".owp" files
const char* const RDB_SCHEMA_RIEGL_OWP(
    "{\"identifier\":\"owp\",\"attributes\":[\"riegl.id*\",\"riegl.raw_range\",\"riegl"
    ".amplitude\",\"riegl.deviation\",\"riegl.gain\"],\"extension\":\"owp\",\"metadat"
    "a\":[]}"
);

// Schema for ".pefx" files
const char* const RDB_SCHEMA_RIEGL_PEFX(
    "{\"identifier\":\"pefx\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.xyz_"
    "accuracies?\",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.std_dev\",\""
    "riegl.plane_confidence_normal\",\"riegl.plane_width\",\"riegl.plane_height"
    "\",\"riegl.vertex_first\",\"riegl.vertex_count\",\"riegl.used_for_adjustment"
    "\",\"riegl.acquisition_date?\",\"riegl.import_line_number\",\"riegl.import_l"
    "ine_count\"],\"extension\":\"pefx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.vert"
    "ex_info\",\"riegl.item_names\",\"riegl.imported_files\"]}"
);

// Schema for ".pofx" files
const char* const RDB_SCHEMA_RIEGL_PROJECT_POFX(
    "{\"identifier\":\"project.pofx\",\"attributes\":[\"riegl.id\",\"riegl.pof_times"
    "tamp*\",\"riegl.pof_latitude\",\"riegl.pof_longitude\",\"riegl.pof_height\",\""
    "riegl.pof_roll\",\"riegl.pof_pitch\",\"riegl.pof_yaw\",\"riegl.pof_path_leng"
    "th?\"],\"extension\":\"pofx\",\"metadata\":[\"riegl.device?\",\"riegl.time_base\""
    ",\"riegl.trajectory_info\"]}"
);

// Schema for ".pofx" files
const char* const RDB_SCHEMA_RIEGL_SCAN_POFX(
    "{\"identifier\":\"scan.pofx\",\"attributes\":[\"riegl.id\",\"riegl.pof_timestam"
    "p*\",\"riegl.pof_latitude\",\"riegl.pof_longitude\",\"riegl.pof_height\",\"rie"
    "gl.pof_roll\",\"riegl.pof_pitch\",\"riegl.pof_yaw\",\"riegl.pof_path_length?"
    "\",\"riegl.pof_xyz\",\"riegl.pof_roll_ned\",\"riegl.pof_pitch_ned\",\"riegl.po"
    "f_yaw_ned\"],\"extension\":\"pofx\",\"metadata\":[\"riegl.device?\",\"riegl.time"
    "_base\",\"riegl.geo_tag\",\"riegl.trajectory_info\"]}"
);

// Schema for ".poqx" files
const char* const RDB_SCHEMA_RIEGL_PROJECT_POQX(
    "{\"identifier\":\"project.poqx\",\"attributes\":[\"riegl.id\",\"riegl.pof_times"
    "tamp*\",\"riegl.pof_accuracy_north\",\"riegl.pof_accuracy_east\",\"riegl.pof"
    "_accuracy_down\",\"riegl.pof_accuracy_roll\",\"riegl.pof_accuracy_pitch\",\""
    "riegl.pof_accuracy_yaw\",\"riegl.pof_path_length?\",\"riegl.pof_pdop\",\"rie"
    "gl.pof_satellites_gnss?\",\"riegl.pof_satellites_gps?\",\"riegl.pof_satell"
    "ites_glonass?\",\"riegl.pof_satellites_beidou?\",\"riegl.pof_satellites_ga"
    "lileo?\",\"riegl.pof_satellites_qzss?\"],\"extension\":\"poqx\",\"metadata\":[\""
    "riegl.time_base\",\"riegl.trajectory_info\"]}"
);

// Schema for ".poqx" files
const char* const RDB_SCHEMA_RIEGL_SCAN_POQX(
    "{\"identifier\":\"scan.poqx\",\"attributes\":[\"riegl.id\",\"riegl.pof_timestam"
    "p*\",\"riegl.pof_accuracy_north\",\"riegl.pof_accuracy_east\",\"riegl.pof_ac"
    "curacy_down\",\"riegl.pof_accuracy_roll\",\"riegl.pof_accuracy_pitch\",\"rie"
    "gl.pof_accuracy_yaw\",\"riegl.pof_path_length?\",\"riegl.pof_pdop\",\"riegl."
    "pof_satellites_gnss?\",\"riegl.pof_satellites_gps?\",\"riegl.pof_satellite"
    "s_glonass?\",\"riegl.pof_satellites_beidou?\",\"riegl.pof_satellites_galil"
    "eo?\",\"riegl.pof_satellites_qzss?\"],\"extension\":\"poqx\",\"metadata\":[\"rie"
    "gl.time_base\",\"riegl.trajectory_info\"]}"
);

// Schema for ".ppx" files
const char* const RDB_SCHEMA_RIEGL_PPX(
    "{\"identifier\":\"ppx\",\"attributes\":[\"riegl.id\",\"riegl.pps_timestamp_inte"
    "rn*\",\"riegl.pps_timestamp_extern\"],\"extension\":\"ppx\",\"metadata\":[\"rieg"
    "l.device\",\"riegl.time_base\"]}"
);

// Schema for ".ptch" files
const char* const RDB_SCHEMA_RIEGL_PROJECT_PTCH(
    "{\"identifier\":\"project.ptch\",\"attributes\":[\"riegl.xyz*\",\"riegl.surface"
    "_normal\",\"riegl.plane_up\",\"riegl.reflectance?\",\"riegl.point_count\",\"ri"
    "egl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_cou"
    "nt\",\"riegl.covariances\",\"riegl.id\"],\"extension\":\"ptch\",\"metadata\":[\"ri"
    "egl.device\",\"riegl.geo_tag?\",\"riegl.scan_pattern?\",\"riegl.time_base?\","
    "\"riegl.plane_patch_statistics?\"]}"
);

// Schema for ".ptch" files
const char* const RDB_SCHEMA_RIEGL_SCAN_PTCH(
    "{\"identifier\":\"scan.ptch\",\"attributes\":[\"riegl.xyz*\",\"riegl.xyz_socs\","
    "\"riegl.direction?\",\"riegl.direction_medium?\",\"riegl.direction_coarse?\""
    ",\"riegl.surface_normal\",\"riegl.plane_up\",\"riegl.timestamp\",\"riegl.refl"
    "ectance?\",\"riegl.point_count\",\"riegl.std_dev\",\"riegl.plane_width\",\"rie"
    "gl.plane_height\",\"riegl.plane_count\",\"riegl.mirror_facet\",\"riegl.covar"
    "iances\",\"riegl.id\",\"riegl.plane_slope_class?\",\"riegl.plane_occupancy\","
    "\"riegl.plane_confidence_normal\",\"riegl.plane_cog_link\",\"riegl.match_co"
    "unt\",\"riegl.platform_rpy_ROCS_NED\",\"riegl.platform_xyz_ROCS_ENU\",\"rieg"
    "l.platform_drpy_ROCS_NED\",\"riegl.platform_dxyz_ROCS_ENU\",\"riegl.sda.sh"
    "ift_vector\",\"riegl.raw_range\",\"riegl.raw_frame_angle\",\"riegl.raw_line_"
    "angle\"],\"extension\":\"ptch\",\"metadata\":[\"riegl.device\",\"riegl.device_ge"
    "ometry\",\"riegl.geo_tag\",\"riegl.georeferencing_parameters\",\"riegl.scan_"
    "pattern?\",\"riegl.time_base\",\"riegl.plane_patch_statistics?\",\"riegl.pla"
    "ne_slope_class_info?\"]}"
);

// Schema for ".ptch" files
const char* const RDB_SCHEMA_RIEGL_SCANPOS_PTCH(
    "{\"identifier\":\"scanpos.ptch\",\"attributes\":[\"riegl.xyz*\",\"riegl.surface"
    "_normal\",\"riegl.plane_up\",\"riegl.reflectance?\",\"riegl.point_count\",\"ri"
    "egl.std_dev\",\"riegl.plane_width\",\"riegl.plane_height\",\"riegl.plane_cou"
    "nt\",\"riegl.covariances\",\"riegl.id\"],\"extension\":\"ptch\",\"metadata\":[\"ri"
    "egl.device\",\"riegl.geo_tag?\",\"riegl.scan_pattern?\",\"riegl.time_base?\","
    "\"riegl.plane_patch_statistics?\"]}"
);

// Schema for ".rdbx" files
const char* const RDB_SCHEMA_RIEGL_RDBX(
    "{\"identifier\":\"rdbx\",\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl"
    ".xyz*\",\"riegl.xyz_socs\",\"riegl.direction_medium?\",\"riegl.direction?\",\""
    "riegl.amplitude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_"
    "width?\",\"riegl.target_index\",\"riegl.target_count\",\"riegl.mirror_facet?"
    "\",\"riegl.scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"rie"
    "gl.window_echo_impact_corrected?\",\"riegl.rgba?\",\"riegl.class?\",\"riegl."
    "start_of_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator"
    "?\",\"riegl.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl"
    ".wfm_echo_time_offset?\",\"riegl.scan_angle\",\"riegl.scan_direction\",\"rie"
    "gl.source_index?\",\"riegl.hydro_intersection_point?\",\"riegl.hydro_inter"
    "section_normal?\"],\"extension\":\"rdbx\",\"metadata\":[\"riegl.atmosphere\",\"r"
    "iegl.beam_geometry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaus"
    "sian_decomposition?\",\"riegl.exponential_decomposition?\",\"riegl.geo_tag"
    "\",\"riegl.georeferencing_parameters\",\"riegl.mta_settings?\",\"riegl.near_"
    "range_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filte"
    "r?\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_positi"
    "on_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internals?\","
    "\"riegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\"rieg"
    "l.scan_pattern\",\"riegl.time_base\",\"riegl.waveform_settings?\",\"riegl.wi"
    "ndow_analysis?\",\"riegl.window_echo_correction?\"]}"
);

// Schema for ".rmvx" files
const char* const RDB_SCHEMA_RIEGL_RMVX(
    "{\"identifier\":\"rmvx\",\"attributes\":[\"riegl.id\",\"riegl.voxel_index*\",\"ri"
    "egl.amplitude\",\"riegl.reflectance\",\"riegl.deviation\",\"riegl.direction_"
    "medium\",\"riegl.point_count\",\"riegl.voxel_linear_sums\",\"riegl.voxel_squ"
    "are_sums\",\"riegl.timestamp_min?\",\"riegl.timestamp_max?\"],\"extension\":\""
    "rmvx\",\"metadata\":[\"riegl.geo_tag\",\"riegl.voxel_info\",\"riegl.time_base?"
    "\"]}"
);

// Schema for ".s10x" files
const char* const RDB_SCHEMA_RIEGL_S10X(
    "{\"identifier\":\"s10x\",\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"rieg"
    "l.frame_angle_coarse\",\"riegl.gyroscope_raw\",\"riegl.accelerometer_raw\","
    "\"riegl.magnetic_field_sensor_raw\",\"riegl.gyroscope\",\"riegl.acceleromet"
    "er\",\"riegl.magnetic_field_sensor\",\"riegl.barometric_height_amsl\",\"rieg"
    "l.temperature\",\"riegl.line_scan_active\",\"riegl.frame_scan_active\",\"rie"
    "gl.data_acquisition_active\"],\"extension\":\"s10x\",\"metadata\":[\"riegl.tim"
    "e_base\",\"riegl.device?\",\"riegl.pose_sensors\"]}"
);

// Schema for ".sbx" files
const char* const RDB_SCHEMA_RIEGL_SBX(
    "{\"identifier\":\"sbx\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sbl_channel\","
    "\"riegl.wfm_sbl_mean\",\"riegl.wfm_sbl_std_dev\",\"riegl.wfm_sbl_time_offse"
    "t\",\"riegl.wfm_sda_first\",\"riegl.wfm_sda_count\"],\"extension\":\"sbx\",\"met"
    "adata\":[]}"
);

// Schema for ".sdcx" files
const char* const RDB_SCHEMA_RIEGL_SDCX(
    "{\"identifier\":\"sdcx\",\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"rieg"
    "l.xyz\",\"riegl.amplitude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"rieg"
    "l.pulse_width?\",\"riegl.target_index\",\"riegl.target_count\",\"riegl.mirro"
    "r_facet?\",\"riegl.scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zon"
    "e?\",\"riegl.window_echo_impact_corrected?\",\"riegl.class?\",\"riegl.start_"
    "of_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator?\",\"ri"
    "egl.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl.wfm_e"
    "cho_time_offset?\"],\"extension\":\"sdcx\",\"metadata\":[\"riegl.atmosphere\",\""
    "riegl.beam_geometry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gau"
    "ssian_decomposition?\",\"riegl.exponential_decomposition?\",\"riegl.mta_se"
    "ttings?\",\"riegl.near_range_correction?\",\"riegl.noise_estimates?\",\"rieg"
    "l.angular_notch_filter?\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?"
    "\",\"riegl.pulse_position_modulation?\",\"riegl.range_statistics?\",\"riegl."
    "receiver_internals?\",\"riegl.reflectance_calculation?\",\"riegl.reflectan"
    "ce_correction?\",\"riegl.scan_pattern\",\"riegl.time_base\",\"riegl.window_a"
    "nalysis?\",\"riegl.window_echo_correction?\"]}"
);

// Schema for ".sidx" files
const char* const RDB_SCHEMA_RIEGL_SIDX(
    "{\"identifier\":\"sidx\",\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr"
    "*\",\"riegl.echo_first\",\"riegl.echo_count\"],\"extension\":\"sidx\",\"metadata"
    "\":[\"riegl.shot_info\",\"riegl.echo_info\"]}"
);

// Schema for ".sodx" files
const char* const RDB_SCHEMA_RIEGL_SODX(
    "{\"identifier\":\"sodx\",\"attributes\":[\"riegl.id\",\"riegl.shot_timestamp_hr"
    "*\",\"riegl.mirror_facet\",\"riegl.scan_segment\",\"riegl.start_of_scan_line"
    "\",\"riegl.line_angle_coarse\",\"riegl.shot_origin\",\"riegl.shot_biaxial_sh"
    "ift?\",\"riegl.shot_direction\",\"riegl.shot_direction_levelled?\",\"riegl.w"
    "fm_sbl_first?\",\"riegl.wfm_sbl_count?\",\"riegl.echo_first?\",\"riegl.echo_"
    "count?\"],\"extension\":\"sodx\",\"metadata\":[\"riegl.atmosphere\",\"riegl.devi"
    "ce\",\"riegl.device_geometry\",\"riegl.device_output_limits\",\"riegl.beam_g"
    "eometry\",\"riegl.near_range_correction?\",\"riegl.window_echo_correction?"
    "\",\"riegl.receiver_internals?\",\"riegl.gaussian_decomposition?\",\"riegl.e"
    "xponential_decomposition?\",\"riegl.mta_settings?\",\"riegl.pulse_position"
    "_modulation?\",\"riegl.notch_filter?\",\"riegl.reflectance_calculation?\",\""
    "riegl.scan_pattern\",\"riegl.time_base\",\"riegl.waveform_info?\",\"riegl.ec"
    "ho_info?\"]}"
);

// Schema for ".sp{C}" files
const char* const RDB_SCHEMA_RIEGL_SPC(
    "{\"identifier\":\"sp{C}\",\"attributes\":[\"riegl.id*\",\"riegl.wfm_sample_valu"
    "e\"],\"extension\":\"sp{C}\",\"metadata\":[]}"
);

// Schema for ".vtx" files
const char* const RDB_SCHEMA_RIEGL_VTX(
    "{\"identifier\":\"vtx\",\"attributes\":[\"riegl.id*\",\"riegl.xyz\",\"riegl.xyz_a"
    "ccuracies?\"],\"extension\":\"vtx\",\"metadata\":[\"riegl.geo_tag\"]}"
);

// Schema for ".vxls" files
const char* const RDB_SCHEMA_RIEGL_VXLS(
    "{\"identifier\":\"vxls\",\"attributes\":[\"riegl.id\",\"riegl.xyz*\",\"riegl.cova"
    "riances\",\"riegl.pca_axis_max\",\"riegl.pca_axis_min\",\"riegl.pca_extents\""
    ",\"riegl.point_count\",\"riegl.reflectance\",\"riegl.shape_id\",\"riegl.voxel"
    "_collapsed\",\"riegl.std_dev?\"],\"extension\":\"vxls\",\"metadata\":[\"riegl.vo"
    "xel_info\",\"riegl.geo_tag?\"]}"
);

// Schema for ".wdcx" files
const char* const RDB_SCHEMA_RIEGL_WDCX(
    "{\"identifier\":\"wdcx\",\"attributes\":[\"riegl.id\",\"riegl.timestamp\",\"riegl"
    ".xyz*\",\"riegl.xyz_socs\",\"riegl.direction_medium?\",\"riegl.direction?\",\""
    "riegl.amplitude\",\"riegl.reflectance?\",\"riegl.deviation?\",\"riegl.pulse_"
    "width?\",\"riegl.target_index\",\"riegl.target_count\",\"riegl.mirror_facet?"
    "\",\"riegl.scan_segment?\",\"riegl.mta_unresolved?\",\"riegl.mta_zone?\",\"rie"
    "gl.window_echo_impact_corrected?\",\"riegl.rgba?\",\"riegl.class?\",\"riegl."
    "start_of_scan_line?\",\"riegl.end_of_scan_line?\",\"riegl.source_indicator"
    "?\",\"riegl.fwa?\",\"riegl.waveform_available?\",\"riegl.wfm_sbl_id?\",\"riegl"
    ".wfm_echo_time_offset?\",\"riegl.scan_angle\",\"riegl.scan_direction\",\"rie"
    "gl.source_index?\",\"riegl.hydro_intersection_point?\",\"riegl.hydro_inter"
    "section_normal?\"],\"extension\":\"wdcx\",\"metadata\":[\"riegl.atmosphere\",\"r"
    "iegl.beam_geometry\",\"riegl.device_geometry\",\"riegl.device\",\"riegl.gaus"
    "sian_decomposition?\",\"riegl.exponential_decomposition?\",\"riegl.geo_tag"
    "\",\"riegl.georeferencing_parameters\",\"riegl.mta_settings?\",\"riegl.near_"
    "range_correction?\",\"riegl.noise_estimates?\",\"riegl.angular_notch_filte"
    "r?\",\"riegl.notch_filter?\",\"riegl.pointcloud_info?\",\"riegl.pulse_positi"
    "on_modulation?\",\"riegl.range_statistics?\",\"riegl.receiver_internals?\","
    "\"riegl.reflectance_calculation?\",\"riegl.reflectance_correction?\",\"rieg"
    "l.scan_pattern\",\"riegl.time_base\",\"riegl.waveform_settings?\",\"riegl.wi"
    "ndow_analysis?\",\"riegl.window_echo_correction?\"]}"
);

// Schema for ".wex" files
const char* const RDB_SCHEMA_RIEGL_WEX(
    "{\"identifier\":\"wex\",\"attributes\":[\"riegl.id\",\"riegl.timestamp*\",\"riegl"
    ".wex_filter_valid\",\"riegl.wex_point_count\",\"riegl.wex_amplitude\",\"rieg"
    "l.wex_amplitude_std_dev\",\"riegl.wex_amplitude_min\",\"riegl.wex_amplitud"
    "e_max\",\"riegl.wex_amplitude_offset\",\"riegl.wex_deviation\",\"riegl.wex_d"
    "eviation_std_dev\",\"riegl.wex_deviation_min\",\"riegl.wex_deviation_max\","
    "\"riegl.wex_range\",\"riegl.wex_range_std_dev\",\"riegl.wex_range_min\",\"rie"
    "gl.wex_range_max\",\"riegl.wex_filter_range_min\",\"riegl.wex_filter_range"
    "_max\",\"riegl.wex_filter_amplitude_max\"],\"extension\":\"wex\",\"metadata\":["
    "\"riegl.device\",\"riegl.notch_filter\",\"riegl.window_analysis\"]}"
);

// Table of all RDB file schema strings
const char* const RDB_SCHEMA_ARRAY[] = {
    RDB_SCHEMA_RIEGL_AVG_FWA,
    RDB_SCHEMA_RIEGL_AVG_SBX,
    RDB_SCHEMA_RIEGL_AVG_SIDX,
    RDB_SCHEMA_RIEGL_AVG_SPC,
    RDB_SCHEMA_RIEGL_CPX,
    RDB_SCHEMA_RIEGL_DOIX,
    RDB_SCHEMA_RIEGL_FWA,
    RDB_SCHEMA_RIEGL_MPX,
    RDB_SCHEMA_RIEGL_MTCH,
    RDB_SCHEMA_RIEGL_MVX,
    RDB_SCHEMA_RIEGL_OBSX,
    RDB_SCHEMA_RIEGL_OPEFX,
    RDB_SCHEMA_RIEGL_OPP,
    RDB_SCHEMA_RIEGL_OPX,
    RDB_SCHEMA_RIEGL_OWP,
    RDB_SCHEMA_RIEGL_PEFX,
    RDB_SCHEMA_RIEGL_PROJECT_POFX,
    RDB_SCHEMA_RIEGL_SCAN_POFX,
    RDB_SCHEMA_RIEGL_PROJECT_POQX,
    RDB_SCHEMA_RIEGL_SCAN_POQX,
    RDB_SCHEMA_RIEGL_PPX,
    RDB_SCHEMA_RIEGL_PROJECT_PTCH,
    RDB_SCHEMA_RIEGL_SCAN_PTCH,
    RDB_SCHEMA_RIEGL_SCANPOS_PTCH,
    RDB_SCHEMA_RIEGL_RDBX,
    RDB_SCHEMA_RIEGL_RMVX,
    RDB_SCHEMA_RIEGL_S10X,
    RDB_SCHEMA_RIEGL_SBX,
    RDB_SCHEMA_RIEGL_SDCX,
    RDB_SCHEMA_RIEGL_SIDX,
    RDB_SCHEMA_RIEGL_SODX,
    RDB_SCHEMA_RIEGL_SPC,
    RDB_SCHEMA_RIEGL_VTX,
    RDB_SCHEMA_RIEGL_VXLS,
    RDB_SCHEMA_RIEGL_WDCX,
    RDB_SCHEMA_RIEGL_WEX
};
const size_t RDB_SCHEMA_COUNT(
    sizeof(RDB_SCHEMA_ARRAY) / sizeof(RDB_SCHEMA_ARRAY[0])
);

#endif // RDB_2125FB67_4790_4EE4_BC63_844F2ACC9D90
