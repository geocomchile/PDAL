/*
 *******************************************************************************
 *
 *  Copyright 2022 RIEGL Laser Measurement Systems
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  SPDX-License-Identifier: Apache-2.0
 *
 *******************************************************************************
 */
/*!
 *******************************************************************************
 *
 * \author  RIEGL LMS GmbH, Austria
 * \brief   Description of RIEGL RDB 2 database meta data items.
 * \version 2015-10-27/AW: Initial version
 * \version 2015-11-25/AW: Item "Geo Tag" added
 * \version 2016-10-27/AW: Item "Voxel Information" added
 * \version 2016-11-17/AW: Item "Voxel Information" updated
 * \version 2016-12-12/AW: Item "Range Statistics" added
 * \version 2017-03-08/AW: Item "Plane Patch Statistics" added
 * \version 2017-04-05/AW: Items "Atmosphere" and "Geometric Scale Factor" added
 * \version 2017-08-22/AW: Items for waveform sample block and value files added
 * \version 2017-10-24/AW: Item "Gaussian Decomposition" added
 * \version 2017-11-13/AW: Item "riegl.scan_pattern" updated
 * \version 2017-11-21/AW: Item "riegl.trajectory_info" added
 * \version 2018-01-11/AW: Item "riegl.beam_geometry" added
 * \version 2018-01-15/AW: Item "riegl.reflectance_calculation" added
 * \version 2018-01-15/AW: Item "riegl.near_range_correction" added
 * \version 2018-01-15/AW: Item "riegl.device_geometry" added
 * \version 2018-02-13/AW: Item "riegl.notch_filter" added
 * \version 2018-03-08/AW: Item "riegl.window_echo_correction" added
 * \version 2018-03-15/AW: Item "riegl.pulse_position_modulation" added
 * \version 2018-05-24/AW: Item "riegl.pixel_info" added
 * \version 2018-06-08/AW: Item "riegl.shot_info" added
 * \version 2018-06-08/AW: Item "riegl.echo_info" added
 * \version 2018-06-14/AW: Item "riegl.mta_settings" added
 * \version 2018-06-14/AW: Item "riegl.receiver_internals" added
 * \version 2018-06-14/AW: Item "riegl.device_output_limits" added
 * \version 2018-06-26/AW: Schema: replace "number" with "integer" if applicable
 * \version 2018-07-09/AW: Item "riegl.pose_estimation" added
 * \version 2018-07-09/AW: Item "riegl.pose_sensors" added
 * \version 2018-09-20/AW: Item "riegl.pointcloud_info" added
 * \version 2018-11-08/AW: Item "riegl.scan_pattern" updated
 * \version 2018-11-13/AW: Item "riegl.receiver_internals" updated
 * \version 2019-03-06/AW: Item "riegl.receiver_internals" updated
 * \version 2019-03-21/AW: Item "riegl.device_geometry" updated
 * \version 2019-04-15/AW: Item "riegl.point_attribute_groups" added
 * \version 2019-04-30/AW: Item "riegl.waveform_settings" added
 * \version 2019-10-03/AW: Item "riegl.angular_notch_filter" added
 * \version 2019-10-03/AW: Item "riegl.noise_estimates" added
 * \version 2019-10-25/AW: Item "riegl.window_analysis" added
 * \version 2019-11-06/AW: Item "riegl.georeferencing_parameters" added
 * \version 2019-11-27/AW: Item "riegl.plane_patch_matching" added
 * \version 2019-12-13/AW: Items for tie-/control objects added
 * \version 2019-12-19/AW: Items for tie-/control objects added
 * \version 2020-02-04/AW: Item "riegl.detection_probability" added
 * \version 2020-02-04/AW: Item "riegl.licenses" added
 * \version 2020-04-27/AW: Item "riegl.waveform_info" updated (schema+example)
 * \version 2020-09-03/AW: Item "riegl.reflectance_correction" added
 * \version 2020-09-10/AW: Item "riegl.device_geometry_passive_channel" added
 * \version 2020-09-25/AW: Item "riegl.georeferencing_parameters" updated
 * \version 2020-09-25/AW: Item "riegl.trajectory_info" updated
 * \version 2020-09-29/AW: Item "riegl.temperature_calculation" added
 * \version 2020-10-23/AW: Item "riegl.exponential_decomposition" added (#3709)
 * \version 2020-11-30/AW: Item "riegl.notch_filter" updated (schema)
 * \version 2020-12-02/AW: Item "riegl.georeferencing_parameters" updated (schema)
 * \version 2021-02-02/AW: Item "riegl.plane_slope_class_info" added (rdbplanes/#7)
 * \version 2021-02-16/AW: Item "riegl.device_output_limits" updated (schema, #3811)
 * \version 2021-03-03/AW: Item "riegl.exponential_decomposition" updated (schema, #3822)
 * \version 2021-03-03/AW: Item "riegl.waveform_averaging_settings" added (#3821)
 * \version 2021-04-01/AW: Item "riegl.voxel_info" updated (schema, #3854)
 * \version 2021-04-16/AW: Item "riegl.voxel_info" updated (schema, #3866)
 * \version 2021-09-30/AW: Item "riegl.waveform_info" updated (schema+example, #4016)
 * \version 2021-10-04/AW: Improved spelling of the descriptions of some items
 * \version 2021-11-04/AW: Rename "riegl.record_names" to "riegl.item_names" (#4034)
 * \version 2022-03-11/AW: Item "riegl.devices" added (#4162)
 * \version 2022-03-14/AW: Item "riegl.stored_filters" added (#4164)
 * \version 2022-09-20/AW: Fix typos in schema of "riegl.georeferencing_parameters"
 * \version 2022-09-30/AW: Item "riegl.system_description" added (#4368)
 * \version 2022-10-10/AW: Correction of typos in the titles of some entries
 * \version 2022-10-20/AW: Item "riegl.stored_filters" updated (example, #4164)
 *
 *******************************************************************************
 */

#ifndef RDB_354CFFB3_BDAA_4E38_98C8_9C09D0C0AD87
#define RDB_354CFFB3_BDAA_4E38_98C8_9C09D0C0AD87

#include <vector>
#include <string>
#include <cstdlib>
#include <cstdint>

namespace riegl {
namespace rdb {
namespace pointcloud {

// Meta data item definition version
const std::string RDB_META_DATA_ITEMS_VERSION = "1.1.53";
const std::string RDB_META_DATA_ITEMS_DATE = "2022-10-20";

// Meta data item states
const unsigned char RDB_STATUS_REQUIRED = 1; // mandatory item
const unsigned char RDB_STATUS_OPTIONAL = 2; // optional item

// Container record for meta data item details
struct MetaDataItemInfo
{
    std::string   name;
    std::string   title;
    std::string   description;
    unsigned char status;
    std::string   schema;
    std::string   example;

    operator const std::string&() const { return name; }
};

// Angular notch filter parameters for window glass echoes
const MetaDataItemInfo RDB_RIEGL_ANGULAR_NOTCH_FILTER = {
    /* name        */ "riegl.angular_notch_filter",
    /* title       */ "Angular Notch Filter",
    /* description */ "Angular notch filter parameters for window glass echoes",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Angular Notch Filter\",\"required\":[\"angle\",\"range_mean\",\"amplit"
    "ude_mean\"],\"description\":\"Angular notch filter parameters for window "
    "glass echoes\",\"properties\":{\"angle\":{\"type\":\"array\",\"items\":{\"type\":\"n"
    "umber\"},\"description\":\"Angle [deg]\"},\"range_mean\":{\"type\":\"array\",\"ite"
    "ms\":{\"type\":\"number\"},\"description\":\"Mean range [m]\"},\"amplitude_mean\""
    ":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"Mean "
    "amplitude [dB]\"}}}"
    ,
    /* example: */
    "{\"angle\":[14.0,15.0,16.0,17.0,18.0,19.0,20.0,21.0,22.0,23.0,24.0],\"ran"
    "ge_mean\":[0.094,0.094,0.09075,0.08675,0.0815,0.0775,0.074,0.071,0.068,"
    "0.0675,0.06475],\"amplitude_mean\":[3.780913,3.780913,3.480913,3.120913,"
    "2.850913,2.720913,2.680913,2.610913,2.530913,2.570913,2.570913]}"
};

// Atmospheric parameters
const MetaDataItemInfo RDB_RIEGL_ATMOSPHERE = {
    /* name        */ "riegl.atmosphere",
    /* title       */ "Atmosphere",
    /* description */ "Atmospheric parameters",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Atmospheric Parameters\",\"required\":[\"temperature\",\"pressure\",\""
    "rel_humidity\",\"pressure_sl\",\"amsl\",\"group_velocity\",\"attenuation\",\"wav"
    "elength\"],\"description\":\"Atmospheric parameters\",\"properties\":{\"wavele"
    "ngth\":{\"type\":\"number\",\"description\":\"Laser wavelength "
    "[nm]\"},\"amsl\":{\"type\":\"number\",\"description\":\"Height above mean sea "
    "level (AMSL) "
    "[m]\"},\"pressure_sl\":{\"type\":\"number\",\"description\":\"Atmospheric "
    "pressure at sea level "
    "[mbar]\"},\"pressure\":{\"type\":\"number\",\"description\":\"Pressure along "
    "measurment path "
    "[mbar]\"},\"group_velocity\":{\"type\":\"number\",\"description\":\"Group "
    "velocity of laser beam "
    "[m/s]\"},\"temperature\":{\"type\":\"number\",\"description\":\"Temperature "
    "along measurement path "
    "[\\u00b0C]\"},\"rel_humidity\":{\"type\":\"number\",\"description\":\"Relative "
    "humidity along measurement path "
    "[%]\"},\"attenuation\":{\"type\":\"number\",\"description\":\"Atmospheric "
    "attenuation [1/km]\"}}}"
    ,
    /* example: */
    "{\"wavelength\":1550,\"amsl\":0,\"pressure_sl\":970,\"pressure\":970,\"group_ve"
    "locity\":299711000.0,\"temperature\":7,\"rel_humidity\":63,\"attenuation\":0."
    "028125}"
};

// Laser beam geometry details
const MetaDataItemInfo RDB_RIEGL_BEAM_GEOMETRY = {
    /* name        */ "riegl.beam_geometry",
    /* title       */ "Beam Geometry",
    /* description */ "Laser beam geometry details",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Beam Geometry\",\"required\":[\"beam_exit_diameter\",\"beam_divergen"
    "ce\"],\"description\":\"Laser beam geometry details\",\"properties\":{\"beam_d"
    "ivergence\":{\"type\":\"number\",\"exclusiveMinimum\":false,\"minimum\":0,\"desc"
    "ription\":\"Beam divergence in far field [rad]\"},\"beam_exit_diameter\":{\""
    "type\":\"number\",\"exclusiveMinimum\":false,\"minimum\":0,\"description\":\"Bea"
    "m width at exit aperture [m]\"}}}"
    ,
    /* example: */
    "{\"beam_divergence\":0.0003,\"beam_exit_diameter\":0.0072}"
};

// List of control object type definitions
const MetaDataItemInfo RDB_RIEGL_CONTROL_OBJECT_CATALOG = {
    /* name        */ "riegl.control_object_catalog",
    /* title       */ "Control Object Catalog",
    /* description */ "List of control object type definitions",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"s"
    "phere\":{\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"typ"
    "e\":\"object\",\"description\":\"sphere specific properties\",\"properties\":{\""
    "shape\":{\"type\":\"string\",\"enum\":[\"sphere\"],\"description\":\"shape identif"
    "ier\"},\"diameter\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,"
    "\"description\":\"diameter in meters\"}},\"required\":[\"shape\",\"diameter\"]}]"
    ",\"description\":\"sphere\"},\"chevron\":{\"type\":\"object\",\"allOf\":[{\"$ref\":\""
    "#/definitions/common\"},{\"type\":\"object\",\"description\":\"chevron "
    "specific properties\",\"properties\":{\"thickness\":{\"type\":\"number\",\"exclu"
    "siveMinimum\":true,\"minimum\":0,\"description\":\"thickness in meters\"},\"sh"
    "ape\":{\"type\":\"string\",\"enum\":[\"chevron\"],\"description\":\"shape identifi"
    "er\"},\"outside_edge_length\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"m"
    "inimum\":0,\"description\":\"length of the two outer edges in meters\"}},\"r"
    "equired\":[\"shape\",\"outside_edge_length\",\"thickness\"]}],\"description\":\""
    "chevron\"},\"rectangle\":{\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions"
    "/common\"},{\"type\":\"object\",\"description\":\"rectangle specific propertie"
    "s\",\"properties\":{\"shape\":{\"type\":\"string\",\"enum\":[\"rectangle\"]},\"lengt"
    "h\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":"
    "\"length in meters\"},\"width\":{\"type\":\"number\",\"exclusiveMinimum\":true,\""
    "minimum\":0,\"description\":\"width in meters\"}},\"required\":[\"shape\",\"leng"
    "th\",\"width\"]}],\"description\":\"rectangle\"},\"common\":{\"type\":\"object\",\"d"
    "escription\":\"common object properties\",\"properties\":{\"surface_type\":{\""
    "type\":\"string\",\"enum\":[\"retro_reflective_foil\",\"diffuse\"],\"description"
    "\":\"surface material type\"},\"shape\":{\"type\":\"string\",\"enum\":[\"rectangle"
    "\",\"checkerboard2x2\",\"chevron\",\"circular_disk\",\"cylinder\",\"sphere\",\"rou"
    "nd_corner_cube_prism\"],\"description\":\"shape "
    "identifier\"},\"description\":{\"type\":\"string\",\"description\":\"string "
    "describing the object\"},\"name\":{\"type\":\"string\",\"description\":\"unique "
    "type identifier\",\"minLength\":3}},\"required\":[\"name\",\"shape\"]},\"round_c"
    "orner_cube_prism\":{\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/com"
    "mon\"},{\"type\":\"object\",\"description\":\"round corner cube prism specific"
    " properties\",\"properties\":{\"shape\":{\"type\":\"string\",\"enum\":[\"round_cor"
    "ner_cube_prism\"],\"description\":\"shape "
    "identifier\"},\"offset\":{\"type\":\"number\",\"description\":\"offset in "
    "meters, e.g. reflector constant (optional)\"},\"diameter\":{\"type\":\"numbe"
    "r\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":\"diameter in "
    "meters\"}},\"required\":[\"shape\",\"diameter\"]}],\"description\":\"round "
    "corner cube prism\"},\"checkerboard2x2\":{\"type\":\"object\",\"allOf\":[{\"$ref"
    "\":\"#/definitions/common\"},{\"type\":\"object\",\"description\":\"checkerboard"
    " specific properties\",\"properties\":{\"shape\":{\"type\":\"string\",\"enum\":[\""
    "checkerboard2x2\"],\"description\":\"shape identifier\"},\"square_length\":{\""
    "type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":\"leng"
    "th of a square of the checkerboard in meters\"}},\"required\":[\"shape\",\"s"
    "quare_length\"]}],\"description\":\"checkerboard 2 by 2\"},\"cylinder\":{\"typ"
    "e\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"type\":\"object\","
    "\"description\":\"cylinder specific properties\",\"properties\":{\"height\":{\""
    "type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":\"heig"
    "ht in meters\"},\"shape\":{\"type\":\"string\",\"enum\":[\"cylinder\"],\"descripti"
    "on\":\"shape identifier\"},\"diameter\":{\"type\":\"number\",\"exclusiveMinimum\""
    ":true,\"minimum\":0,\"description\":\"diameter in meters\"}},\"required\":[\"sh"
    "ape\",\"diameter\",\"height\"]}],\"description\":\"cylinder\"},\"circular_disk\":"
    "{\"type\":\"object\",\"allOf\":[{\"$ref\":\"#/definitions/common\"},{\"type\":\"obj"
    "ect\",\"description\":\"circular disk specific properties\",\"properties\":{\""
    "shape\":{\"type\":\"string\",\"enum\":[\"circular_disk\"],\"description\":\"shape "
    "identifier\"},\"offset\":{\"type\":\"number\",\"description\":\"offset in "
    "meters, e.g. reflector constant (optional)\"},\"diameter\":{\"type\":\"numbe"
    "r\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":\"diameter in "
    "meters\"}},\"required\":[\"shape\",\"diameter\"]}],\"description\":\"circular di"
    "sk\"}},\"properties\":{\"types\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\""
    "oneOf\":[{\"$ref\":\"#/definitions/rectangle\"},{\"$ref\":\"#/definitions/chec"
    "kerboard2x2\"},{\"$ref\":\"#/definitions/chevron\"},{\"$ref\":\"#/definitions/"
    "circular_disk\"},{\"$ref\":\"#/definitions/cylinder\"},{\"$ref\":\"#/definitio"
    "ns/sphere\"},{\"$ref\":\"#/definitions/round_corner_cube_prism\"}]},\"unique"
    "Items\":true}},\"required\":[\"types\"],\"description\":\"List of control "
    "object type definitions\",\"title\":\"Control Object "
    "Catalog\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"comments\":[\"This file contains a list of control object types (aka. "
    "'catalog').\",\"Each type is described by an object,\",\"which must "
    "contain at least the following parameters:\",\"  - name: unique "
    "identifier of the type\",\"  - shape: one of the following supported "
    "shapes:\",\"      - rectangle\",\"      - checkerboard2x2\",\"      - "
    "chevron\",\"      - circular_disk\",\"      - cylinder\",\"      - sphere\",\""
    "      - round_corner_cube_prism\",\"Depending on 'shape', the following "
    "parameters must/may be specified:\",\"  - rectangle:\",\"      - length: "
    "length in meters\",\"      - width: width in meters\",\"  - "
    "checkerboard2x2:\",\"      - square_length: length of a square of the "
    "checkerboard in meters\",\"  - circular_disk:\",\"      - diameter: "
    "diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
    "constant (optional)\",\"  - chevron:\",\"      - outside_edge_length: "
    "length of the two outer edges in meters\",\"      - thickness: thickness"
    " in meters\",\"  - cylinder:\",\"      - diameter: diameter in meters\",\""
    "      - height:  height in meters\",\"  - sphere:\",\"      - diameter: "
    "diameter in meters\",\"  - round_corner_cube_prism:\",\"      - diameter: "
    "diameter in meters\",\"      - offset: offset in meters, e.g. reflector "
    "constant (optional)\",\"Optional parameters:\",\"    - description: string"
    " describing the object\",\"    - surface_type: surface material type "
    "(either 'retro_reflective_foil' or 'diffuse')\"],\"types\":[{\"length\":0.6"
    ",\"shape\":\"rectangle\",\"description\":\"Rectangle (60cm x "
    "30cm)\",\"width\":0.3,\"name\":\"Rectangle "
    "60x30\"},{\"length\":0.8,\"shape\":\"rectangle\",\"description\":\"Rectangle "
    "(80cm x 40cm)\",\"width\":0.4,\"name\":\"Rectangle 80x40\"},{\"shape\":\"checker"
    "board2x2\",\"square_length\":0.3,\"description\":\"Checkerboard (square "
    "length: 30cm)\",\"name\":\"Checkerboard2x2 30\"},{\"shape\":\"checkerboard2x2\""
    ",\"square_length\":0.5,\"description\":\"Checkerboard (square length: "
    "50cm)\",\"name\":\"Checkerboard2x2 "
    "50\"},{\"thickness\":0.1016,\"shape\":\"chevron\",\"description\":\"Chevron "
    "(a=24''; b=4'')\",\"outside_edge_length\":0.6096,\"name\":\"Chevron 24''/4''"
    "\"},{\"surface_type\":\"diffuse\",\"shape\":\"circular_disk\",\"diameter\":0.5,\"d"
    "escription\":\" Circular Disk (diameter: 50cm)\",\"name\":\"Circular Disk 50"
    "\"},{\"shape\":\"circular_disk\",\"diameter\":0.05,\"surface_type\":\"retro_refl"
    "ective_foil\",\"name\":\"RIEGL flat reflector 50 mm\",\"description\":\"flat "
    "circular reflector from retro-reflective foil\",\"offset\":0.0},{\"shape\":"
    "\"circular_disk\",\"diameter\":0.1,\"surface_type\":\"retro_reflective_foil\","
    "\"name\":\"RIEGL flat reflector 100 mm\",\"description\":\"flat circular "
    "reflector from retro-reflective foil\",\"offset\":0.0},{\"shape\":\"circular"
    "_disk\",\"diameter\":0.15,\"surface_type\":\"retro_reflective_foil\",\"name\":\""
    "RIEGL flat reflector 150 mm\",\"description\":\"flat circular reflector "
    "from retro-reflective foil\",\"offset\":0.0},{\"height\":0.05,\"shape\":\"cyli"
    "nder\",\"diameter\":0.05,\"surface_type\":\"retro_reflective_foil\",\"name\":\"R"
    "IEGL cylindrical reflector 50 mm\",\"description\":\"cylindrical reflector"
    " from retro-reflective foil\"},{\"height\":0.1,\"shape\":\"cylinder\",\"diamet"
    "er\":0.1,\"surface_type\":\"retro_reflective_foil\",\"name\":\"RIEGL "
    "cylindrical reflector 100 mm\",\"description\":\"cylindrical reflector "
    "from retro-reflective "
    "foil\"},{\"shape\":\"sphere\",\"diameter\":0.2,\"description\":\"Sphere "
    "(diameter: 200 mm)\",\"name\":\"Sphere 200 mm\"},{\"shape\":\"round_corner_cub"
    "e_prism\",\"diameter\":0.05,\"description\":\"round corner cube "
    "prism\",\"offset\":0.0,\"name\":\"Corner Cube Prism 50 mm\"}]}"
};

// Details about the control object reference file
const MetaDataItemInfo RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE = {
    /* name        */ "riegl.control_object_reference_file",
    /* title       */ "Control Object Reference file",
    /* description */ "Details about the control object reference file",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Details about the control object reference file\",\"proper"
    "ties\":{\"reference_file\":{\"type\":\"object\",\"description\":\"Reference to a"
    " control object "
    "file\",\"properties\":{\"file_path\":{\"type\":\"string\",\"description\":\"Path "
    "of the control object file relative to referring "
    "file\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"Control object "
    "file's Universally Unique Identifier (RFC "
    "4122)\"}},\"required\":[\"file_uuid\",\"file_path\"]}},\"title\":\"Control "
    "Object Reference file\"}"
    ,
    /* example: */
    "{\"reference_file\":{\"file_path\":\"../../../10_CONTROL_OBJECTS/ControlPoi"
    "nts.cpx\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"}}"
};

// Detection probability as a function of amplitude
const MetaDataItemInfo RDB_RIEGL_DETECTION_PROBABILITY = {
    /* name        */ "riegl.detection_probability",
    /* title       */ "Detection Probability",
    /* description */ "Detection probability as a function of amplitude",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Detection Probability\",\"required\":[\"amplitude\",\"detection_prob"
    "ability\"],\"description\":\"Detection probability as a function of amplit"
    "ude\",\"properties\":{\"amplitude\":{\"type\":\"array\",\"items\":{\"type\":\"number"
    "\"},\"description\":\"Amplitude [dB]\"},\"detection_probability\":{\"type\":\"ar"
    "ray\",\"items\":{\"type\":\"number\"},\"description\":\"Detection probability "
    "[0..1]\"}}}"
    ,
    /* example: */
    "{\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],\"detection"
    "_probability\":[0.0,0.5,0.8,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0]}"
};

// Details about the device used to acquire the point cloud
const MetaDataItemInfo RDB_RIEGL_DEVICE = {
    /* name        */ "riegl.device",
    /* title       */ "Device Information",
    /* description */ "Details about the device used to acquire the point cloud",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Device Information\",\"required\":[\"device_type\",\"serial_number\"]"
    ",\"description\":\"Details about the device used to acquire the point clo"
    "ud\",\"properties\":{\"device_type\":{\"type\":\"string\",\"description\":\"Device"
    " type identifier (e.g. "
    "VZ-400i)\"},\"channel_text\":{\"type\":\"string\",\"description\":\"Optional "
    "channel description (e.g. 'Green Channel' for multi-channel "
    "devices)\"},\"device_build\":{\"type\":\"string\",\"description\":\"Device build"
    " variant\"},\"device_name\":{\"type\":\"string\",\"description\":\"Optional "
    "device name (e.g. 'Scanner 1' for multi-scanner "
    "systems)\"},\"serial_number\":{\"type\":\"string\",\"description\":\"Device "
    "serial number (e.g. S2221234)\"},\"channel_number\":{\"type\":\"integer\",\"ex"
    "clusiveMinimum\":false,\"minimum\":0,\"description\":\"Laser channel number "
    "(not defined or 0: single channel device)\"}}}"
    ,
    /* example: */
    "{\"device_type\":\"VZ-400i\",\"channel_text\":\"\",\"device_build\":\"\",\"device_n"
    "ame\":\"Scanner 1\",\"serial_number\":\"S2221234\",\"channel_number\":0}"
};

// Scanner device geometry details
const MetaDataItemInfo RDB_RIEGL_DEVICE_GEOMETRY = {
    /* name        */ "riegl.device_geometry",
    /* title       */ "Device Geometry",
    /* description */ "Scanner device geometry details",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Device Geometry\",\"required\":[\"primary\"],\"description\":\"Scanner"
    " device geometry details\",\"properties\":{\"primary\":{\"type\":\"object\",\"de"
    "scription\":\"Primary device geometry structure (mandatory)\",\"properties"
    "\":{\"content\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\""
    "Internal calibration values\"},\"ID\":{\"type\":\"array\",\"items\":{\"type\":\"in"
    "teger\"},\"maxItems\":2,\"description\":\"Structure identifier\",\"minItems\":2"
    "}},\"required\":[\"ID\",\"content\"]},\"amu\":{\"type\":\"object\",\"description\":\""
    "Angle Measurement Unit\",\"properties\":{\"lineCC\":{\"type\":\"number\",\"exclu"
    "siveMinimum\":false,\"minimum\":0,\"description\":\"Line Circle Count "
    "(number of LSBs per full rotation about line axis)\"},\"frameCC\":{\"type\""
    ":\"number\",\"exclusiveMinimum\":false,\"minimum\":0,\"description\":\"Frame "
    "Circle Count (number of LSBs per full rotation about frame "
    "axis)\"}}},\"secondary\":{\"type\":\"object\",\"description\":\"Additional "
    "device geometry structure (optional)\",\"properties\":{\"content\":{\"type\":"
    "\"array\",\"items\":{\"type\":\"number\"},\"description\":\"Internal calibration "
    "values\"},\"ID\":{\"type\":\"array\",\"items\":{\"type\":\"integer\"},\"maxItems\":2,"
    "\"description\":\"Structure "
    "identifier\",\"minItems\":2}},\"required\":[\"ID\",\"content\"]}}}"
    ,
    /* example: */
    "{\"primary\":{\"content\":[0],\"ID\":[4,0]},\"amu\":{\"lineCC\":124000,\"frameCC\""
    ":124000},\"secondary\":{\"content\":[0],\"ID\":[91,0]}}"
};

// Scanner passive channel device geometry details
const MetaDataItemInfo RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL = {
    /* name        */ "riegl.device_geometry_passive_channel",
    /* title       */ "Device Geometry Passive Channel",
    /* description */ "Scanner passive channel device geometry details",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Device Geometry Passive "
    "Channel\",\"required\":[\"primary\"],\"description\":\"Scanner passive channel"
    " device geometry details\",\"properties\":{\"primary\":{\"type\":\"object\",\"de"
    "scription\":\"Primary device geometry structure (mandatory)\",\"properties"
    "\":{\"content\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\""
    "Internal calibration values\"},\"ID\":{\"type\":\"array\",\"items\":{\"type\":\"in"
    "teger\"},\"maxItems\":2,\"description\":\"Structure "
    "identifier\",\"minItems\":2}},\"required\":[\"ID\",\"content\"]}}}"
    ,
    /* example: */
    "{\"primary\":{\"content\":[0],\"ID\":[143,0]}}"
};

// Limits of the measured values output by the device
const MetaDataItemInfo RDB_RIEGL_DEVICE_OUTPUT_LIMITS = {
    /* name        */ "riegl.device_output_limits",
    /* title       */ "Device Output Limits",
    /* description */ "Limits of the measured values output by the device",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Limits of the measured values output by the device. The "
    "limits depend on the device type, measurement program and/or scan patt"
    "ern.\",\"properties\":{\"reflectance_maximum\":{\"type\":\"number\",\"descriptio"
    "n\":\"Maximum possible reflectance in "
    "dB.\"},\"mta_zone_count_maximum\":{\"type\":\"number\",\"description\":\"Maximum"
    " number of MTA "
    "zones.\"},\"amplitude_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
    "possible amplitude in "
    "dB.\"},\"deviation_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
    "possible pulse shape deviation.\"},\"echo_count_maximum\":{\"type\":\"number"
    "\",\"description\":\"Maximum number of echoes a laser shot can "
    "have.\"},\"deviation_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
    "possible pulse shape "
    "deviation.\"},\"range_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
    "possible range in "
    "meters.\"},\"range_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
    "possible range in meters.\"},\"background_radiation_minimum\":{\"type\":\"nu"
    "mber\",\"description\":\"Minimum possible background radiation.\"},\"backgro"
    "und_radiation_maximum\":{\"type\":\"number\",\"description\":\"Maximum "
    "possible background radiation.\"},\"reflectance_minimum\":{\"type\":\"number"
    "\",\"description\":\"Minimum possible reflectance in "
    "dB.\"},\"amplitude_minimum\":{\"type\":\"number\",\"description\":\"Minimum "
    "possible amplitude in dB.\"}},\"title\":\"Device Output Limits\"}"
    ,
    /* example: */
    "{\"range_maximum\":10000.0,\"reflectance_maximum\":100.0,\"amplitude_maximu"
    "m\":100.0,\"deviation_minimum\":-1,\"range_minimum\":2.9,\"background_radiat"
    "ion_minimum\":0,\"mta_zone_count_maximum\":7,\"background_radiation_maximu"
    "m\":0,\"deviation_maximum\":32767,\"reflectance_minimum\":-100.0,\"amplitude"
    "_minimum\":0.0}"
};

// Details about the devices used to acquire the point cloud
const MetaDataItemInfo RDB_RIEGL_DEVICES = {
    /* name        */ "riegl.devices",
    /* title       */ "Devices Information",
    /* description */ "Details about the devices used to acquire the point cloud",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"array\",\"d"
    "escription\":\"Details about the devices used to acquire the point cloud"
    " (e.g. when merging point clouds of different "
    "devices)\",\"title\":\"Devices Information\",\"items\":{\"type\":\"object\",\"prop"
    "erties\":{\"device_type\":{\"type\":\"string\",\"description\":\"Device type "
    "identifier (e.g. "
    "VZ-400i)\"},\"channel_text\":{\"type\":\"string\",\"description\":\"Optional "
    "channel description (e.g. 'Green Channel' for multi-channel "
    "devices)\"},\"device_build\":{\"type\":\"string\",\"description\":\"Device build"
    " variant\"},\"signed\":{\"type\":\"boolean\",\"description\":\"Flag that is set "
    "when the original 'riegl.device' entry in the source file was "
    "correctly "
    "signed.\"},\"device_name\":{\"type\":\"string\",\"description\":\"Optional "
    "device name (e.g. 'Scanner 1' for multi-scanner "
    "systems)\"},\"serial_number\":{\"type\":\"string\",\"description\":\"Device "
    "serial number (e.g. S2221234)\"},\"channel_number\":{\"type\":\"integer\",\"ex"
    "clusiveMinimum\":false,\"minimum\":0,\"description\":\"Laser channel number "
    "(not defined or 0: single channel "
    "device)\"}},\"required\":[\"device_type\",\"serial_number\"]}}"
    ,
    /* example: */
    "[{\"device_type\":\"VZ-400i\",\"channel_text\":\"\",\"device_build\":\"\",\"signed\""
    ":false,\"device_name\":\"Scanner 1\",\"serial_number\":\"S2221234\",\"channel_n"
    "umber\":0},{\"device_type\":\"VQ-1560i-DW\",\"channel_text\":\"\",\"device_build"
    "\":\"\",\"signed\":true,\"device_name\":\"Scanner 2\",\"serial_number\":\"S2222680"
    "\",\"channel_number\":1},{\"device_type\":\"VQ-1560i-DW\",\"channel_text\":\"\",\""
    "device_build\":\"\",\"signed\":true,\"device_name\":\"Scanner "
    "3\",\"serial_number\":\"S2222680\",\"channel_number\":2}]"
};

// Details about echo files
const MetaDataItemInfo RDB_RIEGL_ECHO_INFO = {
    /* name        */ "riegl.echo_info",
    /* title       */ "Echo Information",
    /* description */ "Details about echo files",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Echo "
    "Information\",\"required\":[\"echo_file\"],\"description\":\"Details about "
    "echo files\",\"properties\":{\"echo_file\":{\"type\":\"object\",\"properties\":{\""
    "file_uuid\":{\"type\":\"string\",\"description\":\"File's Universally Unique "
    "Identifier (RFC "
    "4122)\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Echo file "
    "extension, without the leading dot\"}},\"required\":[\"file_extension\"]}}}"
    ,
    /* example: */
    "{\"echo_file\":{\"file_uuid\":\"26a03615-67c0-4bea-8fe8-c577378fe661\",\"file"
    "_extension\":\"owp\"}}"
};

// Details for exponential decomposition of full waveform data
const MetaDataItemInfo RDB_RIEGL_EXPONENTIAL_DECOMPOSITION = {
    /* name        */ "riegl.exponential_decomposition",
    /* title       */ "Exponential Decomposition",
    /* description */ "Details for exponential decomposition of full waveform data",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"c"
    "hannel\":{\"type\":\"object\",\"properties\":{\"scale\":{\"type\":\"number\",\"descr"
    "iption\":\"amplitude calibration\"},\"a_lin\":{\"type\":\"number\",\"minimum\":0,"
    "\"exclusiveMinimum\":false,\"exclusiveMaximum\":false,\"maximum\":1,\"descrip"
    "tion\":\"relative linear amplitude range "
    "[0..1]\"},\"delay\":{\"type\":\"number\",\"description\":\"delay calibration in "
    "seconds\"},\"parameter\":{\"type\":\"object\",\"description\":\"parameters of "
    "the syswave exponential sum\",\"properties\":{\"gamma\":{\"type\":\"array\",\"it"
    "ems\":{\"type\":\"number\"},\"description\":\"decay in 1/second\"},\"A\":{\"type\":"
    "\"array\",\"items\":{\"type\":\"number\"},\"description\":\"real part of "
    "amplitude factor in units of full-scale\"},\"B\":{\"type\":\"array\",\"items\":"
    "{\"type\":\"number\"},\"description\":\"imaginary part of amplitude factor in"
    " units of full-scale\"},\"omega\":{\"type\":\"array\",\"items\":{\"type\":\"number"
    "\"},\"description\":\"angular frequency in Hz\"}},\"required\":[\"A\",\"B\",\"gamm"
    "a\",\"omega\"]}},\"required\":[\"delay\",\"scale\",\"parameter\"]}},\"additionalPr"
    "operties\":false,\"patternProperties\":{\"^[0-9]+$\":{\"$ref\":\"#/definitions"
    "/channel\",\"description\":\"one field per channel, field name is channel "
    "index\"}},\"description\":\"Details for exponential decomposition of full "
    "waveform data\",\"title\":\"Exponential Decomposition\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"1\":{\"scale\":1.0,\"a_lin\":0.9,\"delay\":3.5e-09,\"parameter\":{\"gamma\":[-1"
    "094726528.0,-769562752.0,-848000064.0],\"A\":[0.9,0.3,-1.3],\"B\":[-3.9,0."
    "0,-0.3],\"omega\":[352020896.0,3647927552.0,-1977987072.0]}},\"0\":{\"scale"
    "\":1.0,\"a_lin\":0.27,\"delay\":3.783458418887631e-09,\"parameter\":{\"gamma\":"
    "[-1094726528.0,-769562752.0,-848000064.0],\"A\":[0.9772450923919678,0.33"
    "54335129261017,-1.312678575515747],\"B\":[-3.9813032150268555,0.08622030"
    "913829803,-0.3152860999107361],\"omega\":[352020896.0,3647927552.0,-1977"
    "987072.0]}}}"
};

// Details for Gaussian decomposition of full waveform data
const MetaDataItemInfo RDB_RIEGL_GAUSSIAN_DECOMPOSITION = {
    /* name        */ "riegl.gaussian_decomposition",
    /* title       */ "Gaussian Decomposition",
    /* description */ "Details for Gaussian decomposition of full waveform data",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Gaussian Decomposition\",\"required\":[\"amplitude_lsb_low_power\","
    "\"amplitude_lsb_high_power\",\"amplitude_db\",\"range_offset_sec_low_power\""
    ",\"range_offset_sec_high_power\"],\"description\":\"riegl.gaussian_decompos"
    "ition contains information relevant for extracting calibrated "
    "amplitudes and calibrated ranges from a Gaussian decomposition of full"
    " waveform data. This information is contained in a table with five "
    "columns. Two columns are to be used as input: amplitude_lsb_low_power "
    "and amplitude_lsb_high_power. The other three columns provide the "
    "outputs. Amplitude_db gives the calibrated amplitude in the optical "
    "regime in decibels. The range offset columns provide additive range "
    "offsets, given in units of seconds, for each channel.\",\"properties\":{\""
    "range_offset_sec_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}"
    "},\"amplitude_db\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"range_off"
    "set_sec_low_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitu"
    "de_lsb_low_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}},\"amplitud"
    "e_lsb_high_power\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}}}}"
    ,
    /* example: */
    "{\"range_offset_sec_high_power\":[],\"amplitude_db\":[],\"range_offset_sec_"
    "low_power\":[],\"amplitude_lsb_low_power\":[],\"amplitude_lsb_high_power\":"
    "[]}"
};

// Point cloud georeferencing information
const MetaDataItemInfo RDB_RIEGL_GEO_TAG = {
    /* name        */ "riegl.geo_tag",
    /* title       */ "Geo Tag",
    /* description */ "Point cloud georeferencing information",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Point cloud georeferencing information\",\"properties\":{\"c"
    "rs\":{\"type\":\"object\",\"description\":\"Global Coordinate Reference "
    "System. Please note that only 3D Cartesian Coordinate Systems are allo"
    "wed.\",\"properties\":{\"epsg\":{\"type\":\"integer\",\"minimum\":0,\"description\""
    ":\"EPSG code\"},\"wkt\":{\"type\":\"string\",\"description\":\"\\\"Well-Known "
    "Text\\\" string, OGC WKT dialect (see http://www.opengeospatial.org/stan"
    "dards/wkt-crs)\"},\"name\":{\"type\":\"string\",\"description\":\"Coordinate "
    "reference system name\"}}},\"pose\":{\"type\":\"array\",\"items\":{\"type\":\"arra"
    "y\",\"items\":{\"type\":\"number\",\"description\":\"columns\"},\"maxItems\":4,\"des"
    "cription\":\"rows\",\"minItems\":4},\"maxItems\":4,\"description\":\"Coordinate "
    "Transformation Matrix to transform from File Coordinate System to "
    "Global Coordinate Reference System. 4x4 matrix stored as two "
    "dimensional array, row major order.\",\"minItems\":4}},\"title\":\"Geo Tag\"}"
    ,
    /* example: */
    "{\"crs\":{\"epsg\":4978,\"wkt\":\"GEOCCS[\\\"WGS84 Geocentric\\\",DATUM[\\\"WGS84\\\""
    ",SPHEROID[\\\"WGS84\\\",6378137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"703"
    "0\\\"]],AUTHORITY[\\\"EPSG\\\",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.00000000000"
    "00000,AUTHORITY[\\\"EPSG\\\",\\\"8901\\\"]],UNIT[\\\"Meter\\\",1.00000000000000000"
    "000,AUTHORITY[\\\"EPSG\\\",\\\"9001\\\"]],AXIS[\\\"X\\\",OTHER],AXIS[\\\"Y\\\",EAST],A"
    "XIS[\\\"Z\\\",NORTH],AUTHORITY[\\\"EPSG\\\",\\\"4978\\\"]]\",\"name\":\"WGS84 Geocentr"
    "ic\"},\"pose\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
    "4063882.500831],[0.962908599449764,-0.20260517250352,0.178208229833847"
    ",1138787.607461],[0.0,0.660451759194338,0.7508684796801,4766084.550196"
    "],[0.0,0.0,0.0,1.0]]}"
};

// Geometric scale factor applied to point coordinates
const MetaDataItemInfo RDB_RIEGL_GEOMETRIC_SCALE_FACTOR = {
    /* name        */ "riegl.geometric_scale_factor",
    /* title       */ "Geometric Scale Factor",
    /* description */ "Geometric scale factor applied to point coordinates",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"number\",\""
    "minimum\":0,\"description\":\"Geometric scale factor applied to point "
    "coordinates\",\"exclusiveMinimum\":true}"
    ,
    /* example: */
    "1.0"
};

// Parameters used for georeferencing of the point cloud
const MetaDataItemInfo RDB_RIEGL_GEOREFERENCING_PARAMETERS = {
    /* name        */ "riegl.georeferencing_parameters",
    /* title       */ "Georeferencing Parameters",
    /* description */ "Parameters used for georeferencing of the point cloud",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Parameters used for georeferencing of the point cloud\",\""
    "properties\":{\"trajectory_offsets\":{\"type\":\"object\",\"description\":\"Corr"
    "ection offsets applied to the trajectory "
    "data\",\"properties\":{\"version\":{\"type\":\"integer\",\"description\":\"Meaning"
    " of offset values and how to apply them; version 0: "
    "Rz(yaw+offset_yaw)*Ry(pitch+offset_pitch)*Rx(roll+offset_roll), "
    "version 1: Rz(yaw)*Ry(pitch)*Rx(roll) * Rz(offset_yaw)*Ry(offset_pitch"
    ")*Rx(offset_roll)\"},\"offset_height\":{\"type\":\"number\",\"description\":\"[m"
    "]\"},\"offset_time\":{\"type\":\"number\",\"description\":\"[s]\"},\"offset_yaw\":{"
    "\"type\":\"number\",\"description\":\"[deg]\"},\"offset_roll\":{\"type\":\"number\","
    "\"description\":\"[deg]\"},\"offset_pitch\":{\"type\":\"number\",\"description\":\""
    "[deg]\"},\"offset_north\":{\"type\":\"number\",\"description\":\"[m]\"},\"offset_e"
    "ast\":{\"type\":\"number\",\"description\":\"[m]\"}}},\"trajectory_file\":{\"type\""
    ":\"object\",\"description\":\"Trajectory data used for georeferencing of "
    "the point cloud\",\"properties\":{\"file_uuid\":{\"type\":\"string\",\"descripti"
    "on\":\"File's Universally Unique Identifier (RFC "
    "4122)\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Trajectory "
    "file extension, without the leading dot\"}},\"required\":[\"file_extension"
    "\"]},\"socs_to_body_matrix\":{\"type\":\"array\",\"items\":{\"type\":\"array\",\"ite"
    "ms\":{\"type\":\"number\",\"description\":\"columns\"},\"maxItems\":4,\"descriptio"
    "n\":\"rows\",\"minItems\":4},\"maxItems\":4,\"description\":\"Coordinate "
    "Transformation Matrix to transform from Scanner's Own Coordinate "
    "System to Body Coordinate System. 4x4 matrix stored as two dimensional"
    " array, row major order.\",\"minItems\":4},\"body_coordinate_system_type\":"
    "{\"type\":\"string\",\"enum\":[\"NED\",\"ENU\"],\"description\":\"BODY coordinate "
    "frame (NED: North-East-Down, ENU: East-North-Up), default: NED\"},\"socs"
    "_to_rocs_matrix\":{\"type\":\"array\",\"items\":{\"type\":\"array\",\"items\":{\"typ"
    "e\":\"number\",\"description\":\"columns\"},\"maxItems\":4,\"description\":\"rows\""
    ",\"minItems\":4},\"maxItems\":4,\"description\":\"Coordinate Transformation "
    "Matrix to transform from Scanner's Own Coordinate System to Record "
    "Coordinate System. 4x4 matrix stored as two dimensional array, row "
    "major order.\",\"minItems\":4}},\"title\":\"Georeferencing Parameters\"}"
    ,
    /* example: */
    "{\"trajectory_offsets\":{\"version\":0,\"offset_height\":-0.2,\"offset_time\":"
    "18.007,\"offset_yaw\":-0.45,\"offset_roll\":0.03,\"offset_pitch\":0.01,\"offs"
    "et_north\":0.07,\"offset_east\":0.15},\"trajectory_file\":{\"file_uuid\":\"93a"
    "03615-66c0-4bea-8ff8-c577378fe660\",\"file_extension\":\"pofx\"},\"socs_to_b"
    "ody_matrix\":[[-0.269827776749716,-0.723017716139738,0.635954678449952,"
    "0.0],[0.962908599449764,-0.20260517250352,0.178208229833847,0.0],[0.0,"
    "0.660451759194338,0.7508684796801,0.0],[0.0,0.0,0.0,1.0]],\"body_coordi"
    "nate_system_type\":\"NED\"}"
};

// Map of item names
const MetaDataItemInfo RDB_RIEGL_ITEM_NAMES = {
    /* name        */ "riegl.item_names",
    /* title       */ "Item Names",
    /* description */ "Map of item names",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "additionalProperties\":false,\"patternProperties\":{\"^-?[0-9]+$\":{\"type\":"
    "\"string\",\"description\":\"One field per item, field name is item id, "
    "field value is item name\"}},\"description\":\"Map of item "
    "names\",\"title\":\"Item Names\"}"
    ,
    /* example: */
    "{\"-1\":\"Name of item with id -1\",\"1\":\"Name of item with id 1\",\"2\":\"Name"
    " of item with id 2\",\"47\":\"Name of item with id 47\"}"
};

// License keys for software features
const MetaDataItemInfo RDB_RIEGL_LICENSES = {
    /* name        */ "riegl.licenses",
    /* title       */ "Software License Keys",
    /* description */ "License keys for software features",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "additionalProperties\":false,\"patternProperties\":{\"^.*$\":{\"type\":\"array"
    "\",\"items\":{\"type\":\"string\",\"description\":\"License key (example: "
    "'46AE032A - 39882AC4 - 9EC0A184 - 6F163D73')\"},\"description\":\"Each "
    "field of the object represents a feature and holds a list of license "
    "keys, where the field name is the feature "
    "name.\",\"minItems\":1}},\"description\":\"License keys for software "
    "features\",\"title\":\"Software License Keys\"}"
    ,
    /* example: */
    "{\"MTA resolution\":[\"468E020A - 39A922E4 - B681A184 - "
    "673E3D72\"],\"Georeferencing\":[\"46AE032A - 39882AC4 - 9EC0A184 - "
    "6F163D73\"],\"Full Waveform Analysis Topography\":[\"0FD5FF07 - 011A1255 -"
    " 9F76CACA - 8D2ED557\"],\"Full Waveform Analysis Topography with GPU "
    "support\":[\"8AB44126 - 23B92250 - 16E2689F - 34EF7E7B\"]}"
};

// Parameters for MTA processing
const MetaDataItemInfo RDB_RIEGL_MTA_SETTINGS = {
    /* name        */ "riegl.mta_settings",
    /* title       */ "MTA Settings",
    /* description */ "Parameters for MTA processing",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Parameters for MTA processing\",\"properties\":{\"modulation"
    "_depth\":{\"type\":\"number\",\"minimum\":0,\"description\":\"Depth of pulse "
    "position modulation in meter.\"},\"zone_count\":{\"type\":\"integer\",\"minimu"
    "m\":0,\"description\":\"Maximum number of MTA zones.\",\"maximum\":255},\"zone"
    "_width\":{\"type\":\"number\",\"minimum\":0,\"description\":\"Width of a MTA "
    "zone in meter.\"}},\"title\":\"MTA Settings\"}"
    ,
    /* example: */
    "{\"modulation_depth\":9.368514,\"zone_count\":23,\"zone_width\":149.896225}"
};

// Lookup table for range correction based on raw range
const MetaDataItemInfo RDB_RIEGL_NEAR_RANGE_CORRECTION = {
    /* name        */ "riegl.near_range_correction",
    /* title       */ "Near Range Correction Table",
    /* description */ "Lookup table for range correction based on raw range",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Near Range Correction "
    "Table\",\"required\":[\"delta\",\"content\"],\"description\":\"Lookup table for "
    "range correction based on raw range\",\"properties\":{\"content\":{\"type\":\""
    "array\",\"items\":{\"type\":\"number\"},\"maxItems\":2000,\"description\":\"Correc"
    "tion value [m] to be added to the raw "
    "range\",\"minItems\":1},\"delta\":{\"type\":\"number\",\"description\":\"Delta "
    "between table entries [m], first entry is at range = 0 m\"}}}"
    ,
    /* example: */
    "{\"content\":[0.0],\"delta\":0.512}"
};

// Standard deviation for range and amplitude as a function of amplitude
const MetaDataItemInfo RDB_RIEGL_NOISE_ESTIMATES = {
    /* name        */ "riegl.noise_estimates",
    /* title       */ "Noise Estimates",
    /* description */ "Standard deviation for range and amplitude as a function of amplitude",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Noise Estimates\",\"required\":[\"amplitude\",\"range_sigma\",\"amplit"
    "ude_sigma\"],\"description\":\"Standard deviation for range and amplitude "
    "as a function of amplitude\",\"properties\":{\"amplitude_sigma\":{\"type\":\"a"
    "rray\",\"items\":{\"type\":\"number\"},\"description\":\"Sigma amplitude [dB]\"},"
    "\"amplitude\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"A"
    "mplitude [dB]\"},\"range_sigma\":{\"type\":\"array\",\"items\":{\"type\":\"number\""
    "},\"description\":\"Sigma range [m]\"}}}"
    ,
    /* example: */
    "{\"amplitude_sigma\":[0.988,0.988,0.875,0.774,0.686,0.608,0.54,0.482,0.4"
    "32,0.39,0.354],\"amplitude\":[0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10"
    ".0],\"range_sigma\":[0.065,0.056,0.046,0.038,0.032,0.027,0.024,0.021,0.0"
    "18,0.016,0.014]}"
};

// Notch filter parameters for window glass echoes
const MetaDataItemInfo RDB_RIEGL_NOTCH_FILTER = {
    /* name        */ "riegl.notch_filter",
    /* title       */ "Notch Filter",
    /* description */ "Notch filter parameters for window glass echoes",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Notch Filter\",\"required\":[\"range_minimum\",\"range_maximum\",\"amp"
    "litude_maximum\"],\"description\":\"Notch filter parameters for window "
    "glass echoes\",\"properties\":{\"range_maximum\":{\"type\":\"number\",\"descript"
    "ion\":\"Maximum range [m]\"},\"amplitude_maximum\":{\"type\":\"number\",\"minimu"
    "m\":0,\"description\":\"Maximum amplitude "
    "[dB]\"},\"range_minimum\":{\"type\":\"number\",\"description\":\"Minimum range "
    "[m]\"}}}"
    ,
    /* example: */
    "{\"range_maximum\":0.2,\"amplitude_maximum\":18.0,\"range_minimum\":-0.5}"
};

// Details about the pixels contained in the file
const MetaDataItemInfo RDB_RIEGL_PIXEL_INFO = {
    /* name        */ "riegl.pixel_info",
    /* title       */ "Pixel Information",
    /* description */ "Details about the pixels contained in the file",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"p"
    "ixel_size\":{\"type\":\"array\",\"items\":{\"type\":\"number\",\"minimum\":0,\"descr"
    "iption\":\"Length of pixel edge [m].\"},\"maxItems\":2,\"description\":\"Size "
    "of pixels.\",\"minItems\":2}},\"properties\":{\"size_llcs\":{\"$ref\":\"#/defini"
    "tions/pixel_size\",\"description\":\"Size of pixels in a locally levelled "
    "cartesian coordinate system (xy). This is only used for pixels based "
    "on a map projection.\"},\"size\":{\"$ref\":\"#/definitions/pixel_size\",\"desc"
    "ription\":\"Size of pixels in file coordinate "
    "system.\"}},\"required\":[\"size\"],\"description\":\"Details about the pixels"
    " contained in the file\",\"title\":\"Pixel Information\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"size_llcs\":[0.5156575252891171,0.5130835356683303],\"size\":[0.5971642"
    "834779395,0.5971642834779395]}"
};

// Details about the plane patch matching process
const MetaDataItemInfo RDB_RIEGL_PLANE_PATCH_MATCHING = {
    /* name        */ "riegl.plane_patch_matching",
    /* title       */ "Plane Patch Matching",
    /* description */ "Details about the plane patch matching process",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"f"
    "ile_reference\":{\"type\":\"object\",\"description\":\"Reference to a plane "
    "patch "
    "file\",\"properties\":{\"file_path\":{\"type\":\"string\",\"description\":\"Path "
    "of the plane patch file relative to the match "
    "file\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"Plane patch file's "
    "Universally Unique Identifier (RFC 4122)\"}},\"required\":[\"file_uuid\",\"f"
    "ile_path\"]}},\"properties\":{\"plane_patch_file_one\":{\"$ref\":\"#/definitio"
    "ns/file_reference\",\"description\":\"Reference to the plane patch file on"
    "e\"},\"plane_patch_file_two\":{\"$ref\":\"#/definitions/file_reference\",\"des"
    "cription\":\"Reference to the plane patch file two\"}},\"required\":[\"plane"
    "_patch_file_one\",\"plane_patch_file_two\"],\"description\":\"Details about "
    "the plane patch matching process\",\"title\":\"Plane Patch "
    "Matching\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"plane_patch_file_one\":{\"file_path\":\"Record009_Line001/191025_121410_"
    "Scanner_1.ptch\",\"file_uuid\":\"810f5d57-eccf-49ed-b07a-0cdd109b4213\"},\"p"
    "lane_patch_file_two\":{\"file_path\":\"project.ptch\",\"file_uuid\":\"fa47d509"
    "-a64e-49ce-8b14-ff3130fbefa9\"}}"
};

// Statistics about plane patches found by plane patch extractor
const MetaDataItemInfo RDB_RIEGL_PLANE_PATCH_STATISTICS = {
    /* name        */ "riegl.plane_patch_statistics",
    /* title       */ "Plane Patch Statistics",
    /* description */ "Statistics about plane patches found by plane patch extractor",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Statistics about plane patches found by plane patch extr"
    "actor\",\"properties\":{\"total_horizontal_area\":{\"type\":\"number\",\"descrip"
    "tion\":\"sum of all plane patch areas projected to horizontal plane "
    "[m\\u00b2]\"},\"total_area\":{\"type\":\"number\",\"description\":\"sum of all "
    "plane patch areas [m\\u00b2]\"}},\"title\":\"Plane Patch Statistics\"}"
    ,
    /* example: */
    "{\"total_horizontal_area\":13954.601,\"total_area\":14007.965}"
};

// Settings and classes for plane slope classification
const MetaDataItemInfo RDB_RIEGL_PLANE_SLOPE_CLASS_INFO = {
    /* name        */ "riegl.plane_slope_class_info",
    /* title       */ "Plane Slope Class Info",
    /* description */ "Settings and classes for plane slope classification",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "definitions\":{\"method-1\":{\"type\":\"object\",\"description\":\"Classificatio"
    "n method 1\",\"properties\":{\"maximum_inclination_angle_horizontal\":{\"typ"
    "e\":\"number\",\"minimum\":-360.0,\"description\":\"maximum inclination angle "
    "of horizontal plane patches [deg]\",\"maximum\":360.0},\"plane_classificat"
    "ion_method\":{\"type\":\"integer\",\"minimum\":1,\"description\":\"method ID (=1"
    ")\",\"maximum\":1}},\"required\":[\"plane_classification_method\",\"maximum_in"
    "clination_angle_horizontal\"]},\"method-2\":{\"type\":\"object\",\"description"
    "\":\"Classification method 2\",\"properties\":{\"sloping_plane_classes_maxim"
    "um_angle\":{\"type\":\"number\",\"minimum\":-360.0,\"description\":\"maximum "
    "inclination angle of sloping plane patches [deg]\",\"maximum\":360.0},\"sl"
    "oping_plane_classes_minimum_angle\":{\"type\":\"number\",\"minimum\":-360.0,\""
    "description\":\"minimum inclination angle of sloping plane patches [deg]"
    "\",\"maximum\":360.0},\"plane_classification_method\":{\"type\":\"integer\",\"mi"
    "nimum\":2,\"description\":\"method ID (=2)\",\"maximum\":2}},\"required\":[\"pla"
    "ne_classification_method\",\"sloping_plane_classes_minimum_angle\",\"slopi"
    "ng_plane_classes_maximum_angle\"]}},\"required\":[\"settings\",\"classes\"],\""
    "properties\":{\"settings\":{\"type\":\"object\",\"description\":\"Classification"
    " settings, details see documentation of rdbplanes\",\"oneOf\":[{\"$ref\":\"#"
    "/definitions/method-1\"},{\"$ref\":\"#/definitions/method-2\"}]},\"classes\":"
    "{\"type\":\"object\",\"patternProperties\":{\"^[0-9]+$\":{\"type\":\"string\",\"des"
    "cription\":\"one field per class, field name is class number, field "
    "value is class name\"}},\"description\":\"Class definition "
    "table\",\"additionalProperties\":false}},\"description\":\"Settings and "
    "classes for plane slope classification\",\"title\":\"Plane Slope Class "
    "Info\"}"
    ,
    /* example: */
    "{\"settings\":{\"sloping_plane_classes_maximum_angle\":70.0,\"sloping_plane"
    "_classes_minimum_angle\":10.0,\"plane_classification_method\":2},\"classes"
    "\":{\"3\":\"sloping, pointing up and south\",\"12\":\"sloping, pointing down "
    "and north\",\"11\":\"sloping, pointing down and south\",\"9\":\"vertical, "
    "pointing west\",\"13\":\"sloping, pointing down and "
    "west\",\"14\":\"horizontal, pointing down\",\"10\":\"sloping, pointing down "
    "and east\",\"1\":\"horizontal, pointing up\",\"8\":\"vertical, pointing "
    "north\",\"2\":\"sloping, pointing up and east\",\"6\":\"vertical, pointing "
    "east\",\"5\":\"sloping, pointing up and west\",\"4\":\"sloping, pointing up "
    "and north\",\"7\":\"vertical, pointing south\"}}"
};

// Grouping and sorting of point attributes for visualization purposes
const MetaDataItemInfo RDB_RIEGL_POINT_ATTRIBUTE_GROUPS = {
    /* name        */ "riegl.point_attribute_groups",
    /* title       */ "Point Attribute Groups",
    /* description */ "Grouping and sorting of point attributes for visualization purposes",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "additionalProperties\":false,\"patternProperties\":{\"^.*$\":{\"type\":\"array"
    "\",\"items\":{\"type\":\"string\",\"description\":\"Point attribute full name or"
    " name pattern (perl regular expression syntax)\"},\"description\":\"Each "
    "field of the object represents a point attribute group and holds a "
    "list of point attributes, where the field name is the group "
    "name.\",\"minItems\":1}},\"description\":\"Grouping and sorting of point "
    "attributes for visualization purposes\",\"title\":\"Point Attribute "
    "Groups\"}"
    ,
    /* example: */
    "{\"Coordinates/Vectors\":[\"riegl.xyz\",\"riegl.range\",\"riegl.theta\",\"riegl"
    ".phi\"],\"Primary Attributes\":[\"riegl.reflectance\",\"riegl.amplitude\",\"ri"
    "egl.deviation\"],\"Secondary Attributes\":[\"riegl.mirror_facet\",\"riegl.wa"
    "veform_available\"],\"Time\":[\"riegl.timestamp\"],\"Other "
    "Attributes\":[\"riegl.selected\",\"riegl.visible\"]}"
};

// Details about point cloud files
const MetaDataItemInfo RDB_RIEGL_POINTCLOUD_INFO = {
    /* name        */ "riegl.pointcloud_info",
    /* title       */ "Point Cloud Information",
    /* description */ "Details about point cloud files",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Details about point cloud files\",\"properties\":{\"field_of"
    "_application\":{\"type\":\"string\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"ML"
    "S\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"],\"description\":\"Field of application\"},\"com"
    "ments\":{\"type\":\"string\",\"description\":\"Comments\"},\"project\":{\"type\":\"s"
    "tring\",\"description\":\"Project name\"}},\"title\":\"Point Cloud "
    "Information\"}"
    ,
    /* example: */
    "{\"field_of_application\":\"ALS\",\"comments\":\"Line 3\",\"project\":\"Campaign "
    "4\"}"
};

// Estimated position and orientation information
const MetaDataItemInfo RDB_RIEGL_POSE_ESTIMATION = {
    /* name        */ "riegl.pose_estimation",
    /* title       */ "Pose Estimation",
    /* description */ "Estimated position and orientation information",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Pose "
    "Estimation\",\"required\":[\"orientation\"],\"description\":\"Estimated "
    "position and orientation information as measured by GNSS, IMU or "
    "inclination sensors\",\"properties\":{\"orientation\":{\"type\":\"object\",\"des"
    "cription\":\"Orientation values and orientation accuracies, measured "
    "with IMU or inclination sensors.\",\"properties\":{\"roll\":{\"type\":\"number"
    "\",\"minimum\":-360,\"description\":\"Roll angle about scanner X-axis [deg]\""
    ",\"maximum\":360},\"yaw_accuracy\":{\"type\":\"number\",\"exclusiveMinimum\":tru"
    "e,\"minimum\":0,\"description\":\"Yaw angle accuracy [deg]\"},\"pitch_accurac"
    "y\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":"
    "\"Pitch angle accuracy "
    "[deg]\"},\"pitch\":{\"type\":\"number\",\"minimum\":-360,\"description\":\"Pitch "
    "angle about scanner Y-axis [deg]\",\"maximum\":360},\"roll_accuracy\":{\"typ"
    "e\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":\"Roll "
    "angle accuracy "
    "[deg]\"},\"yaw\":{\"type\":\"number\",\"minimum\":-360,\"description\":\"Yaw angle"
    " about scanner Z-axis [deg]\",\"maximum\":360}},\"required\":[\"roll\",\"pitch"
    "\",\"yaw\",\"roll_accuracy\",\"pitch_accuracy\",\"yaw_accuracy\"]},\"position\":{"
    "\"type\":\"object\",\"description\":\"Position coordinates and position "
    "accuracy values as measured by GNSS in the specified Coordinate "
    "Reference System (CRS)\",\"properties\":{\"vertical_accuracy\":{\"type\":\"num"
    "ber\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":\"Vertical "
    "accuracy "
    "[m]\"},\"coordinate_3\":{\"type\":\"number\",\"description\":\"Coordinate 3 as "
    "defined by axis 3 of the specified CRS (e.g., Z, Altitude)\"},\"horizont"
    "al_accuracy\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"des"
    "cription\":\"Horizontal accuracy "
    "[m]\"},\"crs\":{\"type\":\"object\",\"description\":\"Global Coordinate "
    "Reference System\",\"properties\":{\"epsg\":{\"type\":\"integer\",\"minimum\":0,\""
    "description\":\"EPSG "
    "code\"},\"wkt\":{\"type\":\"string\",\"description\":\"\\\"Well-Known Text\\\" "
    "string, OGC WKT dialect (see http://www.opengeospatial.org/standards/w"
    "kt-crs)\"}},\"required\":[\"epsg\"]},\"coordinate_1\":{\"type\":\"number\",\"descr"
    "iption\":\"Coordinate 1 as defined by axis 1 of the specified CRS (e.g.,"
    " X, "
    "Latitude)\"},\"coordinate_2\":{\"type\":\"number\",\"description\":\"Coordinate "
    "2 as defined by axis 2 of the specified CRS (e.g., Y, Longitude)\"}},\"r"
    "equired\":[\"coordinate_1\",\"coordinate_2\",\"coordinate_3\",\"horizontal_acc"
    "uracy\",\"vertical_accuracy\",\"crs\"]},\"barometric_height_amsl\":{\"type\":\"n"
    "umber\",\"description\":\"Altitude determined based on the atmospheric "
    "pressure according to the standard atmosphere laws [m].\"}}}"
    ,
    /* example: */
    "{\"orientation\":{\"roll\":3.14743073066123,\"yaw_accuracy\":1.0094337839368"
    "757,\"pitch_accuracy\":0.009433783936875745,\"pitch\":1.509153024827064,\"r"
    "oll_accuracy\":0.009433783936875745,\"yaw\":101.87293630292045},\"position"
    "\":{\"vertical_accuracy\":1.3314999341964722,\"coordinate_3\":362.712493896"
    "4844,\"horizontal_accuracy\":0.810699999332428,\"crs\":{\"epsg\":4979,\"wkt\":"
    "\"GEOGCS[\\\"WGS84 / Geographic\\\",DATUM[\\\"WGS84\\\",SPHEROID[\\\"WGS84\\\",6378"
    "137.000,298.257223563,AUTHORITY[\\\"EPSG\\\",\\\"7030\\\"]],AUTHORITY[\\\"EPSG\\\""
    ",\\\"6326\\\"]],PRIMEM[\\\"Greenwich\\\",0.0000000000000000,AUTHORITY[\\\"EPSG\\\""
    ",\\\"8901\\\"]],UNIT[\\\"Degree\\\",0.01745329251994329547,AUTHORITY[\\\"EPSG\\\","
    "\\\"9102\\\"]],AXIS[\\\"Latitude\\\",NORTH],AXIS[\\\"Longitude\\\",EAST],AUTHORITY"
    "[\\\"EPSG\\\",\\\"4979\\\"]]\"},\"coordinate_1\":48.655799473,\"coordinate_2\":15.6"
    "45033406},\"barometric_height_amsl\":386.7457796227932}"
};

// Details on position and orientation sensors
const MetaDataItemInfo RDB_RIEGL_POSE_SENSORS = {
    /* name        */ "riegl.pose_sensors",
    /* title       */ "Pose Sensors",
    /* description */ "Details on position and orientation sensors",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"v"
    "ector\":{\"type\":\"array\",\"items\":{\"type\":\"number\",\"description\":\"Index "
    "0=X, 1=Y, 2=Z component\"},\"maxItems\":3,\"minItems\":3}},\"properties\":{\"m"
    "agnetic_field_sensor\":{\"type\":\"object\",\"description\":\"Magnetic Field "
    "Sensor details\",\"properties\":{\"relative_nonlinearity\":{\"$ref\":\"#/defin"
    "itions/vector\",\"description\":\"Relative nonlinearity, dimensionless\"},\""
    "fixed\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Distortion of "
    "magnetic field caused by non-rotating scanner part\"},\"z_axis\":{\"$ref\":"
    "\"#/definitions/vector\",\"description\":\"Sensitive Z axis of sensor at "
    "frame angle = 0\"},\"unit\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"min"
    "imum\":0,\"description\":\"Unit of raw data and calibration values, 1 LSB "
    "in "
    "nT\"},\"y_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive "
    "Y axis of sensor at frame angle = "
    "0\"},\"offset\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Value to be"
    " subtracted from raw measurement values\"},\"x_axis\":{\"$ref\":\"#/definiti"
    "ons/vector\",\"description\":\"Sensitive X axis of sensor at frame angle ="
    " 0\"}},\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"fixed\",\""
    "relative_nonlinearity\"]},\"accelerometer\":{\"type\":\"object\",\"description"
    "\":\"Accelerometer details\",\"properties\":{\"relative_nonlinearity\":{\"$ref"
    "\":\"#/definitions/vector\",\"description\":\"Relative nonlinearity, dimensi"
    "onless\"},\"origin\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensor"
    " origin in SOCS [m] at frame angle = "
    "0\"},\"z_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Z"
    " axis of sensor at frame angle = 0\"},\"unit\":{\"type\":\"number\",\"exclusiv"
    "eMinimum\":true,\"minimum\":0,\"description\":\"Unit of raw data and "
    "calibration values, 1 LSB in 9.81 m/s\\u00b2\"},\"y_axis\":{\"$ref\":\"#/defi"
    "nitions/vector\",\"description\":\"Sensitive Y axis of sensor at frame "
    "angle = "
    "0\"},\"offset\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Value to be"
    " subtracted from raw measurement values\"},\"x_axis\":{\"$ref\":\"#/definiti"
    "ons/vector\",\"description\":\"Sensitive X axis of sensor at frame angle ="
    " 0\"}},\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\","
    "\"relative_nonlinearity\"]},\"gyroscope\":{\"type\":\"object\",\"description\":\""
    "Gyroscope details\",\"properties\":{\"relative_nonlinearity\":{\"$ref\":\"#/de"
    "finitions/vector\",\"description\":\"Relative nonlinearity, dimensionless\""
    "},\"origin\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensor origin"
    " in SOCS [m] at frame angle = "
    "0\"},\"z_axis\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Sensitive Z"
    " axis of sensor at frame angle = 0\"},\"unit\":{\"type\":\"number\",\"exclusiv"
    "eMinimum\":true,\"minimum\":0,\"description\":\"Unit of raw data and "
    "calibration values, 1 LSB in rad/s\"},\"y_axis\":{\"$ref\":\"#/definitions/v"
    "ector\",\"description\":\"Sensitive Y axis of sensor at frame angle = "
    "0\"},\"offset\":{\"$ref\":\"#/definitions/vector\",\"description\":\"Value to be"
    " subtracted from raw measurement values\"},\"x_axis\":{\"$ref\":\"#/definiti"
    "ons/vector\",\"description\":\"Sensitive X axis of sensor at frame angle ="
    " 0\"}},\"required\":[\"unit\",\"x_axis\",\"y_axis\",\"z_axis\",\"offset\",\"origin\","
    "\"relative_nonlinearity\"]}},\"required\":[\"gyroscope\",\"accelerometer\",\"ma"
    "gnetic_field_sensor\"],\"description\":\"Details on position and "
    "orientation sensors\",\"title\":\"Pose Sensors\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"magnetic_field_sensor\":{\"relative_nonlinearity\":[0.0,0.0,0.0],\"fixed"
    "\":[-1576.010498046875,1596.081787109375,0.0],\"z_axis\":[0.0004198786627"
    "9669106,7.876977906562388e-05,0.011407104320824146],\"unit\":91.74311828"
    "613281,\"y_axis\":[0.00027888521435670555,-0.011427424848079681,-5.20482"
    "9722060822e-05],\"offset\":[-23812.052734375,5606.57666015625,2493.28125"
    "],\"x_axis\":[-0.011162743903696537,-2.315962774446234e-05,0.00016818844"
    "596855342]},\"accelerometer\":{\"relative_nonlinearity\":[0.0,0.0,0.0],\"or"
    "igin\":[0.026900000870227814,-0.03999999910593033,-0.08950000256299973]"
    ",\"z_axis\":[1.639882206916809,15166.744140625,-116.99742889404297],\"uni"
    "t\":6.666666740784422e-05,\"y_axis\":[-7.027288913726807,-44.123336791992"
    "19,14952.3701171875],\"offset\":[-733.3636474609375,58.969032287597656,1"
    "060.2550048828125],\"x_axis\":[-15008.123046875,56.956390380859375,-60.5"
    "175666809082]},\"gyroscope\":{\"relative_nonlinearity\":[2.888176311444113"
    "e-07,1.06274164579645e-07,-1.7186295080634935e-39],\"origin\":[0.0269000"
    "00870227814,-0.03999999910593033,-0.08950000256299973],\"z_axis\":[0.555"
    "869996547699,119.22135162353516,0.467585027217865],\"unit\":0.0001454441"
    "0805683583,\"y_axis\":[-0.440765917301178,-0.7897399663925171,119.589477"
    "5390625],\"offset\":[-50.92609786987305,146.15643310546875,62.4327278137"
    "207],\"x_axis\":[-121.195556640625,0.8219714164733887,0.2313031703233719"
    "]}}"
};

// Laser pulse position modulation used for MTA resolution
const MetaDataItemInfo RDB_RIEGL_PULSE_POSITION_MODULATION = {
    /* name        */ "riegl.pulse_position_modulation",
    /* title       */ "Pulse Position Modulation",
    /* description */ "Laser pulse position modulation used for MTA resolution",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Pulse Position Modulation\",\"required\":[\"length\",\"num_mod_ampl\""
    ",\"pulse_interval\"],\"description\":\"Laser pulse position modulation used"
    " for MTA resolution\",\"properties\":{\"num_mod_ampl\":{\"type\":\"integer\",\"m"
    "inimum\":0,\"description\":\"Number of different modulation amplitudes (2:"
    " binary modulation)\",\"maximum\":255},\"pulse_interval\":{\"type\":\"array\",\""
    "items\":{\"type\":\"number\",\"minimum\":0},\"description\":\"Explicit table of "
    "the pulse position modulation used for MTA resolution. Table gives "
    "times between successive laser pulses in seconds.\"},\"length\":{\"type\":\""
    "integer\",\"minimum\":0,\"description\":\"Length of code\",\"maximum\":255},\"co"
    "de_phase_mode\":{\"type\":\"integer\",\"minimum\":0,\"description\":\"0: no "
    "synchronization, 1: toggle between 2 phases, 2: increment with phase_i"
    "ncrement\",\"maximum\":255},\"phase_step\":{\"type\":\"integer\",\"minimum\":0,\"d"
    "escription\":\"Step width in phase of modulation code from line to "
    "line\",\"maximum\":255}}}"
    ,
    /* example: */
    "{\"num_mod_ampl\":2,\"pulse_interval\":[2.759375e-06,2.759375e-06,2.759375"
    "e-06,2.759375e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.821875e-06,"
    "2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.759375e-06,2.821"
    "875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.821875e-06,2.759375e-"
    "06,2.759375e-06,2.759375e-06,2.821875e-06,2.821875e-06,2.759375e-06,2."
    "821875e-06,2.821875e-06,2.821875e-06,2.759375e-06,2.821875e-06,2.75937"
    "5e-06,2.821875e-06],\"length\":31,\"code_phase_mode\":2,\"phase_step\":5}"
};

// Statistics about target distance wrt. SOCS origin
const MetaDataItemInfo RDB_RIEGL_RANGE_STATISTICS = {
    /* name        */ "riegl.range_statistics",
    /* title       */ "Range Statistics",
    /* description */ "Statistics about target distance wrt. SOCS origin",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Range Statistics\",\"required\":[\"minimum\",\"average\",\"maximum\",\"s"
    "td_dev\"],\"description\":\"Statistics about target distance wrt. SOCS ori"
    "gin\",\"properties\":{\"average\":{\"type\":\"number\",\"description\":\"Average "
    "value\"},\"minimum\":{\"type\":\"number\",\"description\":\"Minimum "
    "value\"},\"std_dev\":{\"type\":\"number\",\"description\":\"Standard "
    "deviation\"},\"maximum\":{\"type\":\"number\",\"description\":\"Maximum "
    "value\"}}}"
    ,
    /* example: */
    "{\"average\":15.49738,\"minimum\":0.919,\"std_dev\":24.349,\"maximum\":574.35}"
};

// Receiver Internals
const MetaDataItemInfo RDB_RIEGL_RECEIVER_INTERNALS = {
    /* name        */ "riegl.receiver_internals",
    /* title       */ "Receiver Internals",
    /* description */ "Receiver Internals",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"f"
    "p_table_row\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"maxItems\":2048"
    ",\"minItems\":1},\"fp\":{\"type\":\"object\",\"description\":\"Fingerprint values"
    "\",\"properties\":{\"s\":{\"type\":\"array\",\"items\":{\"type\":\"array\",\"items\":{\""
    "type\":\"number\"},\"maxItems\":4096,\"minItems\":1},\"maxItems\":256,\"minItems"
    "\":1},\"w\":{\"type\":\"array\",\"items\":{\"type\":\"array\",\"items\":{\"type\":\"numb"
    "er\"},\"maxItems\":5,\"minItems\":5},\"maxItems\":256,\"minItems\":1}},\"require"
    "d\":[\"s\",\"w\"]},\"fp_table\":{\"type\":\"object\",\"desription\":\"scanner "
    "internal "
    "data\",\"properties\":{\"tc\":{\"type\":\"integer\",\"description\":\"table data "
    "type code\",\"max\":255,\"min\":0},\"tv\":{\"type\":\"array\",\"items\":{\"oneOf\":[{"
    "\"$ref\":\"#/definitions/fp_table_row\"},{\"type\":\"number\"}]},\"maxItems\":20"
    "48,\"minItems\":1},\"ny\":{\"type\":\"integer\",\"description\":\"number of y ent"
    "ries\",\"max\":2048,\"min\":1},\"ch\":{\"type\":\"integer\",\"description\":\"channe"
    "l number\",\"max\":255,\"min\":0},\"nx\":{\"type\":\"integer\",\"description\":\"num"
    "ber of x entries\",\"max\":2048,\"min\":1}},\"required\":[\"ch\",\"tc\",\"nx\",\"ny\""
    ",\"tv\"]}},\"properties\":{\"t\":{\"type\":\"object\",\"patternProperties\":{\"^[0-"
    "9]+$\":{\"$ref\":\"#/definitions/fp\",\"description\":\"one field per channel,"
    " field name is channel index\"}},\"additionalProperties\":false},\"a\":{\"ty"
    "pe\":\"array\",\"items\":{\"type\":\"number\"},\"maxItems\":256,\"description\":\"Am"
    "plitude [dB]\",\"minItems\":1},\"si\":{\"type\":\"number\",\"minimum\":0,\"descrip"
    "tion\":\"Start index (hw_start)\",\"maximum\":255},\"ex\":{\"type\":\"object\",\"d"
    "escription\":\"DEPRECATED, use 'riegl.exponential_decomposition' "
    "instead\"},\"ns\":{\"type\":\"integer\",\"minimum\":0,\"description\":\"Number of "
    "samples\",\"maximum\":4095},\"sr\":{\"type\":\"number\",\"description\":\"Sample "
    "rate [Hz]\",\"minimum\":0,\"exclusiveMinimum\":true},\"mw\":{\"type\":\"number\","
    "\"description\":\"Maximum weight\",\"minimum\":0,\"exclusiveMinimum\":true,\"ma"
    "ximum\":4095},\"nt\":{\"type\":\"integer\",\"minimum\":0,\"description\":\"Number "
    "of traces\",\"maximum\":255},\"tbl\":{\"type\":\"array\",\"items\":{\"$ref\":\"#/def"
    "initions/fp_table\"},\"description\":\"various internal "
    "data\",\"minItems\":1}},\"description\":\"Receiver "
    "Internals\",\"title\":\"Receiver Internals\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"t\":{\"1\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\":[[78,86,126,134,31],[78,8"
    "6,126,134,31]]},\"0\":{\"s\":[[1.23,4.56],[7.89,0.12]],\"w\":[[78,86,126,134"
    ",31],[78,86,126,134,31]]}},\"a\":[-1.55],\"si\":48,\"ns\":400,\"sr\":795999700"
    "0.0,\"mw\":31,\"nt\":128,\"tbl\":[{\"tc\":1,\"tv\":[[1,2,3,4,5],[1.1,2.2,3.3,4.4"
    ",5.5]],\"ny\":2,\"ch\":0,\"nx\":5}]}"
};

// Lookup table for reflectance calculation based on amplitude and range
const MetaDataItemInfo RDB_RIEGL_REFLECTANCE_CALCULATION = {
    /* name        */ "riegl.reflectance_calculation",
    /* title       */ "Reflectance Calculation Table",
    /* description */ "Lookup table for reflectance calculation based on amplitude and range",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Reflectance Calculation "
    "Table\",\"required\":[\"delta\",\"content\"],\"description\":\"Lookup table for "
    "reflectance calculation based on amplitude and range\",\"properties\":{\"c"
    "ontent\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"maxItems\":2000,\"des"
    "cription\":\"Correction value [dB] to be added to the "
    "amplitude\",\"minItems\":1},\"delta\":{\"type\":\"number\",\"description\":\"Delta"
    " between table entries [m], first entry is at range = 0 m\"}}}"
    ,
    /* example: */
    "{\"content\":[-33.01],\"delta\":0.150918}"
};

// Range-dependent and scan-angle-dependent correction of reflectance reading
const MetaDataItemInfo RDB_RIEGL_REFLECTANCE_CORRECTION = {
    /* name        */ "riegl.reflectance_correction",
    /* title       */ "Near-Range Reflectance Correction",
    /* description */ "Range-dependent and scan-angle-dependent correction of reflectance reading",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Near-range reflectance correction\",\"required\":[\"ranges_m\",\"lin"
    "e_angles_deg\",\"reflectance_correction_db\"],\"description\":\"Range-depend"
    "ent and scan-angle-dependent correction of reflectance reading\",\"prope"
    "rties\":{\"ranges_m\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"descript"
    "ion\":\"Range [m]\"},\"line_angles_deg\":{\"type\":\"array\",\"items\":{\"type\":\"n"
    "umber\"},\"description\":\"Angle [deg]\"},\"reflectance_correction_db\":{\"typ"
    "e\":\"array\",\"items\":{\"type\":\"array\",\"items\":{\"type\":\"number\",\"descripti"
    "on\":\"columns (each value corresponds to an "
    "angle)\"},\"description\":\"rows (each array corresponds to a "
    "range)\"},\"description\":\"Near range reflectance correction in dB as a "
    "function of range over angle\"}}}"
    ,
    /* example: */
    "{\"ranges_m\":[0.0,1.0,2.0,3.0],\"line_angles_deg\":[0.0,0.5,1.0,1.5,1.0,2"
    ".0,2.5,3.0,3.5,4.0],\"reflectance_correction_db\":[[0.8,0.7,0.6,0.5,0.4,"
    "0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0."
    "8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05,0.01],[0.8,0.7,0.6,0.5,0.4,0.3,0.2,"
    "0.1,0.05,0.01]]}"
};

// Scan pattern description
const MetaDataItemInfo RDB_RIEGL_SCAN_PATTERN = {
    /* name        */ "riegl.scan_pattern",
    /* title       */ "Scan Pattern",
    /* description */ "Scan pattern description",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"p"
    "rogram\":{\"type\":\"object\",\"description\":\"Measurement program\",\"properti"
    "es\":{\"laser_prr\":{\"type\":\"number\",\"exclusiveMinimum\":false,\"minimum\":0"
    ",\"description\":\"Laser Pulse Repetition Rate "
    "[Hz]\"},\"name\":{\"type\":\"string\",\"description\":\"Name of measurement "
    "program\"}},\"required\":[\"name\"]}},\"description\":\"Scan pattern "
    "description\",\"properties\":{\"line\":{\"type\":\"object\",\"description\":\"Line"
    " Scan Pattern\",\"properties\":{\"stop\":{\"type\":\"number\",\"minimum\":0.0,\"de"
    "scription\":\"Stop angle in SOCS [deg]\",\"maximum\":720.0},\"program\":{\"$re"
    "f\":\"#/definitions/program\"},\"start\":{\"type\":\"number\",\"minimum\":0.0,\"de"
    "scription\":\"Start angle in SOCS [deg]\",\"maximum\":360.0},\"increment\":{\""
    "type\":\"number\",\"minimum\":0.0,\"description\":\"Increment of angle in SOCS"
    " [deg]\",\"maximum\":90.0}},\"required\":[\"start\",\"stop\",\"increment\"]},\"rec"
    "tangular\":{\"type\":\"object\",\"description\":\"Rectangular Field Of View "
    "Scan Pattern\",\"properties\":{\"theta_increment\":{\"type\":\"number\",\"minimu"
    "m\":0.0,\"description\":\"Increment of theta angle in SOCS [deg]\",\"maximum"
    "\":90.0},\"theta_stop\":{\"type\":\"number\",\"minimum\":0.0,\"description\":\"Sto"
    "p theta angle in SOCS [deg]\",\"maximum\":180.0},\"program\":{\"$ref\":\"#/def"
    "initions/program\"},\"theta_start\":{\"type\":\"number\",\"minimum\":0.0,\"descr"
    "iption\":\"Start theta angle in SOCS [deg]\",\"maximum\":180.0},\"phi_increm"
    "ent\":{\"type\":\"number\",\"minimum\":0.0,\"description\":\"Increment of phi "
    "angle in SOCS [deg]\",\"maximum\":90.0},\"phi_start\":{\"type\":\"number\",\"min"
    "imum\":0.0,\"description\":\"Start phi angle in SOCS [deg]\",\"maximum\":360."
    "0},\"phi_stop\":{\"type\":\"number\",\"minimum\":0.0,\"description\":\"Stop phi "
    "angle in SOCS [deg]\",\"maximum\":720.0}},\"required\":[\"phi_start\",\"phi_st"
    "op\",\"phi_increment\",\"theta_start\",\"theta_stop\",\"theta_increment\"]},\"se"
    "gments\":{\"type\":\"object\",\"description\":\"Segmented Line Scan Pattern\",\""
    "properties\":{\"program\":{\"$ref\":\"#/definitions/program\"},\"list\":{\"type\""
    ":\"array\",\"items\":{\"type\":\"object\",\"description\":\"Line Scan Segment\",\"p"
    "roperties\":{\"stop\":{\"type\":\"number\",\"minimum\":0.0,\"description\":\"Stop "
    "angle in SOCS [deg]\",\"maximum\":720.0},\"start\":{\"type\":\"number\",\"minimu"
    "m\":0.0,\"description\":\"Start angle in SOCS [deg]\",\"maximum\":360.0},\"inc"
    "rement\":{\"type\":\"number\",\"minimum\":0.0,\"description\":\"Increment of "
    "angle in SOCS [deg]\",\"maximum\":90.0}},\"required\":[\"start\",\"stop\",\"incr"
    "ement\"]}}},\"required\":[\"list\"]}},\"title\":\"Scan Pattern\"}"
    ,
    /* example: */
    "{\"rectangular\":{\"theta_increment\":0.04,\"theta_stop\":130.0,\"program\":{\""
    "laser_prr\":100000.0,\"name\":\"High Speed\"},\"theta_start\":30.0,\"phi_incre"
    "ment\":0.04,\"phi_start\":45.0,\"phi_stop\":270.0}}"
};

// Details about laser shot files
const MetaDataItemInfo RDB_RIEGL_SHOT_INFO = {
    /* name        */ "riegl.shot_info",
    /* title       */ "Shot Information",
    /* description */ "Details about laser shot files",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Details about laser shot files\",\"properties\":{\"shot_file"
    "\":{\"type\":\"object\",\"properties\":{\"file_uuid\":{\"type\":\"string\",\"descrip"
    "tion\":\"File's Universally Unique Identifier (RFC "
    "4122)\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Shot file "
    "extension, without the leading "
    "dot\"}},\"required\":[\"file_extension\"]}},\"title\":\"Shot Information\"}"
    ,
    /* example: */
    "{\"shot_file\":{\"file_uuid\":\"26a00815-67c0-4bff-8fe8-c577378fe663\",\"file"
    "_extension\":\"sodx\"}}"
};

// Point filters applied in addition to the application-defined filters
const MetaDataItemInfo RDB_RIEGL_STORED_FILTERS = {
    /* name        */ "riegl.stored_filters",
    /* title       */ "Stored Filters",
    /* description */ "Point filters applied in addition to the application-defined filters",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Stored "
    "filters\",\"required\":[\"activated\",\"filters\"],\"description\":\"Point "
    "filters applied in addition to the application-defined filters\",\"prope"
    "rties\":{\"filters\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"descriptio"
    "n\":\"Point filter "
    "definition\",\"properties\":{\"filter\":{\"type\":\"string\",\"description\":\"The"
    " RDB filter string to apply (e.g. when reading points or index), "
    "details see documentation of function "
    "select()\"},\"description\":{\"type\":\"string\",\"description\":\"A brief "
    "description of the filter (e.g. for display in a "
    "tooltip)\"},\"title\":{\"type\":\"string\",\"description\":\"A short filter "
    "title (e.g. for display in a selection "
    "list)\"},\"activated\":{\"type\":\"boolean\",\"description\":\"Apply ('true') or"
    " ignore ('false') this filter\"}},\"required\":[\"activated\",\"title\",\"desc"
    "ription\",\"filter\"]},\"description\":\"List of point "
    "filters\"},\"activated\":{\"type\":\"boolean\",\"description\":\"Apply ('true') "
    "or ignore ('false') all filters\"}}}"
    ,
    /* example: */
    "{\"filters\":[{\"filter\":\"riegl.mta_uncertain_point == "
    "0\",\"description\":\"Ignore points with uncertain MTA zone "
    "assignment\",\"title\":\"Ignore uncertain points from MTA resolution\",\"act"
    "ivated\":false},{\"filter\":\"riegl.dyntrig_uncertain_point == "
    "0\",\"description\":\"Ignore points with an echo signal amplitude below "
    "the dynamic trigger\",\"title\":\"Ignore points below dynamic trigger "
    "level\",\"activated\":false}],\"activated\":true}"
};

// Details of major system components like lidar sensors, cameras and navigation devices
const MetaDataItemInfo RDB_RIEGL_SYSTEM_DESCRIPTION = {
    /* name        */ "riegl.system_description",
    /* title       */ "System Description",
    /* description */ "Details of major system components like lidar sensors, cameras and navigation devices",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"System Description\",\"required\":[\"$class\",\"version\",\"author\",\"t"
    "imestamp\",\"system\"],\"description\":\"Details of major system components "
    "like lidar sensors, cameras and navigation "
    "devices\",\"properties\":{\"system\":{\"type\":\"object\",\"description\":\"The "
    "actual system description, details see documentation of RIEGL System "
    "Description\"},\"author\":{\"type\":\"string\",\"description\":\"Name of the "
    "author that created the "
    "document\"},\"timestamp\":{\"type\":\"string\",\"description\":\"Date and time "
    "of creation (e.g. 2019-06-19T13:32:10+02:00)\"},\"version\":{\"type\":\"stri"
    "ng\",\"description\":\"Document format version\"},\"$class\":{\"type\":\"string\""
    ",\"enum\":[\"Document\"],\"description\":\"Object class name\"}}}"
    ,
    /* example: */
    "{\"system\":{\"details\":\"see documentation of RIEGL System "
    "Description\"},\"author\":\"RIEGL LMS GmbH, Austria\",\"timestamp\":\"2022-09-"
    "30T11:56:26+00:00\",\"version\":\"1.2.1\",\"$class\":\"Document\"}"
};

// Conversion of background radiation raw values to temperatures in °C
const MetaDataItemInfo RDB_RIEGL_TEMPERATURE_CALCULATION = {
    /* name        */ "riegl.temperature_calculation",
    /* title       */ "Temperature Calculation Table",
    /* description */ "Conversion of background radiation raw values to temperatures in °C",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"definitions\":{\"c"
    "onversion_table\":{\"type\":\"object\",\"properties\":{\"temperature\":{\"type\":"
    "\"array\",\"items\":{\"type\":\"number\"},\"description\":\"Temperature [\\u00b0C]"
    "\"},\"value\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"LS"
    "B [1]\"}},\"required\":[\"value\",\"temperature\"]}},\"properties\":{\"InGaAs_Si"
    "_Difference\":{\"$ref\":\"#/definitions/conversion_table\",\"description\":\"C"
    "onversion table for InGaAs - Si difference\"},\"InGaAs\":{\"$ref\":\"#/defin"
    "itions/conversion_table\",\"description\":\"Conversion table for InGaAs ch"
    "annel\"},\"Si\":{\"$ref\":\"#/definitions/conversion_table\",\"description\":\"C"
    "onversion table for Si channel\"}},\"description\":\"Conversion of "
    "background radiation raw values to temperatures in "
    "\\u00b0C\",\"title\":\"Temperature Calculation Table\",\"type\":\"object\"}"
    ,
    /* example: */
    "{\"InGaAs_Si_Difference\":{\"temperature\":[1749.977111117893,1749.9771111"
    "17893,1749.977111117893,1749.977111117893,1749.977111117893,1749.97711"
    "1117893,1744.7813348796044,1681.9971312601092,1622.3944822534868],\"val"
    "ue\":[1000.0,1100.090029602954,1200.04425183874,1300.1342814416948,1400"
    ".0885036774805,1500.0427259132668,1600.1327555162209,1700.086977752006"
    "5,1800.0411999877924]},\"InGaAs\":{\"temperature\":[307.22196722535614,309"
    ".1153478247277,311.1188086915047,313.10025350480055,315.2137946389828,"
    "317.2172555057597,319.2207163725366,321.2021611858325,323.315702320014"
    "8],\"value\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,"
    "256.0039063692129,320.00488296151616,384.0058595538194,448.00683614612"
    "26,512.0078127384259]},\"Si\":{\"temperature\":[546.300048828125,548.81640"
    "51212026,551.3143938500972,554.0144257850053,556.604252334815,559.2124"
    "464488079,561.8022729986177,564.4104671126105,567.0002936624203],\"valu"
    "e\":[0.0,64.00097659230323,128.0019531846065,192.0029297769097,256.0039"
    "063692129,320.00488296151616,384.0058595538194,448.0068361461226,512.0"
    "078127384259]}}"
};

// Base of timestamps (epoch)
const MetaDataItemInfo RDB_RIEGL_TIME_BASE = {
    /* name        */ "riegl.time_base",
    /* title       */ "Time Base",
    /* description */ "Base of timestamps (epoch)",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Time Base\",\"required\":[\"epoch\",\"source\"],\"description\":\"Base "
    "of timestamps "
    "(epoch)\",\"properties\":{\"epoch\":{\"type\":\"string\",\"description\":\"Date "
    "and time of timestamp '0' as proposed by RFC 3339 (e.g. 2015-10-27T00:"
    "00:00+01:00).\"},\"system\":{\"type\":\"string\",\"enum\":[\"unknown\",\"UTC\",\"GPS"
    "\"],\"description\":\"Time system (time standard)\"},\"source\":{\"type\":\"stri"
    "ng\",\"enum\":[\"unknown\",\"RTC\",\"GNSS\"],\"description\":\"Timestamp "
    "source\"}}}"
    ,
    /* example: */
    "{\"epoch\":\"2015-10-27T00:00:00+00:00\",\"system\":\"UTC\",\"source\":\"GNSS\"}"
};

// Details about position+orientation files
const MetaDataItemInfo RDB_RIEGL_TRAJECTORY_INFO = {
    /* name        */ "riegl.trajectory_info",
    /* title       */ "Trajectory Information",
    /* description */ "Details about position+orientation files",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Trajectory Information\",\"required\":[\"time_interval\",\"navigatio"
    "n_frame\"],\"description\":\"Details about position+orientation files\",\"pr"
    "operties\":{\"device\":{\"type\":\"string\",\"description\":\"Navigation device,"
    " e.g. name/type/serial\"},\"time_interval\":{\"type\":\"object\",\"description"
    "\":\"Time interval statistics\",\"properties\":{\"average\":{\"type\":\"number\","
    "\"description\":\"Average time interval "
    "[s]\"},\"minimum\":{\"type\":\"number\",\"description\":\"Minimum time interval "
    "[s]\"},\"std_dev\":{\"type\":\"number\",\"description\":\"Standard deviation of "
    "intervals [s]\"},\"maximum\":{\"type\":\"number\",\"description\":\"Maximum time"
    " interval [s]\"}},\"required\":[\"minimum\",\"average\",\"maximum\",\"std_dev\"]}"
    ",\"project\":{\"type\":\"string\",\"description\":\"Project name\"},\"navigation_"
    "frame\":{\"type\":\"string\",\"enum\":[\"unknown\",\"NED\",\"ENU\"],\"description\":\""
    "Navigation frame (NED: North-East-Down, ENU: East-North-Up)\"},\"field_o"
    "f_application\":{\"type\":\"string\",\"enum\":[\"unknown\",\"SLS\",\"TLS\",\"KLS\",\"M"
    "LS\",\"ULS\",\"ALS\",\"BLS\",\"ILS\"],\"description\":\"Field of "
    "application\"},\"company\":{\"type\":\"string\",\"description\":\"Company "
    "name\"},\"location\":{\"type\":\"string\",\"description\":\"Project location, "
    "e.g. city/state/country\"},\"settings\":{\"type\":\"string\",\"description\":\"S"
    "ettings used to calculate the trajectory (descriptive "
    "text)\"},\"software\":{\"type\":\"string\",\"description\":\"Software that "
    "calculated the trajectory (this may be the same or different software "
    "than the one that created the file)\"}}}"
    ,
    /* example: */
    "{\"device\":\"IMU Model 12/1, Serial# 12345\",\"time_interval\":{\"average\":0"
    ".00500053,\"minimum\":0.00500032,\"std_dev\":5.51e-07,\"maximum\":0.00500488"
    "3},\"project\":\"Campaign 3\",\"navigation_frame\":\"NED\",\"field_of_applicati"
    "on\":\"MLS\",\"company\":\"RIEGL "
    "LMS\",\"location\":\"Horn\",\"settings\":\"default\",\"software\":\"Navigation "
    "Software XYZ\"}"
};

// Details about vertex file
const MetaDataItemInfo RDB_RIEGL_VERTEX_INFO = {
    /* name        */ "riegl.vertex_info",
    /* title       */ "Vertex Information",
    /* description */ "Details about vertex file",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "description\":\"Details about vertex file\",\"properties\":{\"vertex_file\":{"
    "\"type\":\"object\",\"properties\":{\"file_uuid\":{\"type\":\"string\",\"descriptio"
    "n\":\"File's Universally Unique Identifier (RFC "
    "4122)\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Vertex file "
    "extension, without the leading "
    "dot\"}},\"required\":[\"file_extension\"]}},\"title\":\"Vertex Information\"}"
    ,
    /* example: */
    "{\"vertex_file\":{\"file_uuid\":\"51534d95-d71f-4f36-ae1a-3e63a21fd1c7\",\"fi"
    "le_extension\":\"vtx\"}}"
};

// Details about the voxels contained in the file
const MetaDataItemInfo RDB_RIEGL_VOXEL_INFO = {
    /* name        */ "riegl.voxel_info",
    /* title       */ "Voxel Information",
    /* description */ "Details about the voxels contained in the file",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "definitions\":{\"voxel_size_cubic\":{\"$ref\":\"#/definitions/edge_length\",\""
    "type\":\"number\"},\"voxel_type\":{\"enum\":[\"center\",\"centroid\",\"index\"],\"de"
    "scription\":\"Whether a point in a voxel represents its center or its "
    "centroid. If type is <tt>index</tt> there is no point but only an "
    "integer voxel index.\",\"default\":\"centroid\"},\"voxel_origin_point\":{\"typ"
    "e\":\"array\",\"items\":{\"type\":\"number\"},\"maxItems\":3,\"description\":\"Origi"
    "n point for all voxel indices in voxel CRS.\",\"minItems\":3},\"edge_lengt"
    "h\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":0,\"description\":"
    "\"Length of voxel edge [m].\"},\"voxel_size\":{\"type\":\"array\",\"items\":{\"$r"
    "ef\":\"#/definitions/edge_length\"},\"maxItems\":3,\"description\":\"Size of v"
    "oxels.\",\"minItems\":3},\"shape_thresholds\":{\"type\":\"object\",\"description"
    "\":\"Thresholds used to compute the voxel's shape_id value.\",\"properties"
    "\":{\"line\":{\"type\":\"number\",\"exclusiveMinimum\":true,\"minimum\":1,\"descri"
    "ption\":\"If the biggest eigenvalue is bigger than the median eigenvalue"
    " * line_threshold, the voxel is considered a line.\"},\"plane\":{\"type\":\""
    "number\",\"minimum\":0,\"exclusiveMinimum\":true,\"exclusiveMaximum\":true,\"m"
    "aximum\":1,\"description\":\"If the smallest eigenvalue is smaller than "
    "the median eigenvalue * plane_threshold, the voxel is considered a pla"
    "ne.\"}},\"required\":[\"plane\",\"line\"]},\"voxel_origin_enum\":{\"enum\":[\"cent"
    "er\",\"corner\"],\"description\":\"Defines whether the voxel's center or a "
    "corner is placed on CRS origin "
    "<tt>(0/0/0)</tt>.\",\"default\":\"corner\"}},\"description\":\"Details about "
    "the voxels contained in the file\",\"oneOf\":[{\"additionalProperties\":fal"
    "se,\"properties\":{\"voxel_type\":{\"$ref\":\"#/definitions/voxel_type\"},\"sha"
    "pe_thresholds\":{\"$ref\":\"#/definitions/shape_thresholds\"},\"voxel_origin"
    "\":{\"$ref\":\"#/definitions/voxel_origin_enum\"},\"size\":{\"description\":\"Si"
    "ze of voxels in file coordinate system.\",\"oneOf\":[{\"$ref\":\"#/definitio"
    "ns/voxel_size\"},{\"$ref\":\"#/definitions/voxel_size_cubic\"}]}},\"required"
    "\":[\"size\",\"voxel_origin\",\"voxel_type\"]},{\"additionalProperties\":false,"
    "\"properties\":{\"reference_point\":{\"type\":\"array\",\"items\":{\"type\":\"numbe"
    "r\",\"minimum\":-180,\"maximum\":180},\"maxItems\":2,\"description\":\"Point in "
    "WGS84 geodetic decimal degree (EPSG:4326) that was used to compute the"
    " projection distortion parameters. The coefficient order is latitude, "
    "longitude. Only voxels with corresponding geo_tag, voxel_size and "
    "reference_point can be reliably processed together. This entry is "
    "available for voxel files in projected CRS only.\",\"minItems\":2},\"voxel"
    "_type\":{\"$ref\":\"#/definitions/voxel_type\"},\"voxel_origin\":{\"oneOf\":[{\""
    "$ref\":\"#/definitions/voxel_origin_enum\"},{\"$ref\":\"#/definitions/voxel_"
    "origin_point\",\"description\":\"The base point of the voxel grid. Used "
    "together with <tt>voxel_size</tt> and <tt>voxel_index</tt> to compute "
    "actual point coordinates.\"}]},\"size_llcs\":{\"$ref\":\"#/definitions/voxel"
    "_size\",\"description\":\"Size of voxels in a locally levelled cartesian "
    "coordinate system (xyz). This is only used for voxels based on a map p"
    "rojection.\"},\"size\":{\"$ref\":\"#/definitions/voxel_size\",\"description\":\""
    "Size of voxels in file coordinate system.\"},\"shape_thresholds\":{\"$ref\""
    ":\"#/definitions/shape_thresholds\"}},\"required\":[\"reference_point\",\"siz"
    "e_llcs\",\"size\",\"voxel_origin\",\"voxel_type\"]}],\"title\":\"Voxel "
    "Information\"}"
    ,
    /* example: */
    "{\"reference_point\":[48,16],\"voxel_type\":\"centroid\",\"voxel_origin\":\"cor"
    "ner\",\"size_llcs\":[0.5156575252891171,0.5130835356683303,0.514370530478"
    "7237],\"size\":[0.5971642834779395,0.5971642834779395,0.5143705304787237"
    "],\"shape_thresholds\":{\"line\":6,\"plane\":0.16}}"
};

// Settings for waveform averaging
const MetaDataItemInfo RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS = {
    /* name        */ "riegl.waveform_averaging_settings",
    /* title       */ "Waveform Averaging Settings",
    /* description */ "Settings for waveform averaging",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Waveform Averaging "
    "Settings\",\"required\":[\"num_shots\",\"mta_zone\"],\"description\":\"Settings "
    "for waveform averaging\",\"properties\":{\"trim\":{\"type\":\"number\",\"minimum"
    "\":0,\"description\":\"Percentage for robust averaging.\",\"default\":0,\"maxi"
    "mum\":0.5},\"mta_zone\":{\"type\":\"integer\",\"minimum\":1,\"description\":\"Fixe"
    "d MTA zone for averaging.\"},\"num_shots\":{\"type\":\"integer\",\"minimum\":1,"
    "\"description\":\"Number of consecutive shots to be used for "
    "averaging.\"}}}"
    ,
    /* example: */
    "{\"trim\":0.05,\"mta_zone\":1,\"num_shots\":7}"
};

// Details about waveform files
const MetaDataItemInfo RDB_RIEGL_WAVEFORM_INFO = {
    /* name        */ "riegl.waveform_info",
    /* title       */ "Waveform Information",
    /* description */ "Details about waveform files",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "properties\":{\"sample_data_files\":{\"type\":\"array\",\"items\":{\"type\":\"obje"
    "ct\",\"properties\":{\"delta_st\":{\"type\":\"number\",\"description\":\"reserved\""
    "},\"channel_name\":{\"type\":\"string\",\"description\":\"Sample block channel "
    "name\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Sample data "
    "file extension, without the leading dot\"},\"laser_wavelength\":{\"type\":\""
    "number\",\"exclusiveMinimum\":false,\"minimum\":0,\"description\":\"Laser "
    "wavelength in meters (0 = unknown)\"},\"sample_interval\":{\"type\":\"number"
    "\",\"exclusiveMinimum\":false,\"minimum\":0,\"description\":\"Sampling "
    "interval in seconds\"},\"channel\":{\"type\":\"integer\",\"minimum\":0,\"exclusi"
    "veMinimum\":false,\"exclusiveMaximum\":false,\"maximum\":255,\"description\":"
    "\"Sample block channel number (255 = "
    "invalid)\"},\"file_uuid\":{\"type\":\"string\",\"description\":\"File's "
    "Universally Unique Identifier (RFC 4122)\"},\"sample_bits\":{\"type\":\"inte"
    "ger\",\"minimum\":0,\"exclusiveMinimum\":false,\"exclusiveMaximum\":false,\"ma"
    "ximum\":32,\"description\":\"Bitwidth of samples (e.g. 10 bit, 12 bit)\"}},"
    "\"required\":[\"channel\",\"channel_name\",\"sample_interval\",\"sample_bits\",\""
    "laser_wavelength\",\"delta_st\",\"file_extension\"]}},\"range_offset_wavefor"
    "m_samples_m\":{\"type\":\"number\",\"description\":\"Calibrated device "
    "specific range offset for waveform samples in meters.\"},\"sample_block_"
    "file\":{\"type\":\"object\",\"properties\":{\"file_uuid\":{\"type\":\"string\",\"des"
    "cription\":\"File's Universally Unique Identifier (RFC "
    "4122)\"},\"file_extension\":{\"type\":\"string\",\"description\":\"Sample block "
    "file extension, without the leading dot\"}},\"required\":[\"file_extension"
    "\"]},\"range_offset_m\":{\"type\":\"number\",\"description\":\"Calibrated device"
    " specific range offset for waveform analysis by system response "
    "fitting in meters.\"}},\"required\":[\"sample_block_file\",\"sample_data_fil"
    "es\"],\"description\":\"Details about waveform files\",\"title\":\"Waveform "
    "Information\"}"
    ,
    /* example: */
    "{\"sample_data_files\":[{\"delta_st\":0,\"channel_name\":\"high_power\",\"sampl"
    "e_bits\":12,\"laser_wavelength\":0,\"sample_interval\":1.00503e-09,\"channel"
    "\":0,\"file_uuid\":\"da084413-e3e8-4655-a122-071de8490d8e\",\"file_extension"
    "\":\"sp0\"},{\"delta_st\":0,\"channel_name\":\"low_power\",\"sample_bits\":12,\"la"
    "ser_wavelength\":0,\"sample_interval\":1.00503e-09,\"channel\":1,\"file_uuid"
    "\":\"93585b5e-5ea9-43a1-947b-e7ba3be642d2\",\"file_extension\":\"sp1\"},{\"del"
    "ta_st\":0,\"channel_name\":\"wwf\",\"sample_bits\":12,\"laser_wavelength\":0,\"s"
    "ample_interval\":1.00503e-09,\"channel\":5,\"file_uuid\":\"9d2298c4-1036-464"
    "f-b5cb-1cf8e517f3a0\",\"file_extension\":\"sp5\"}],\"sample_block_file\":{\"fi"
    "le_uuid\":\"93a03615-66c0-4bea-8ff8-c577378fe660\",\"file_extension\":\"sbx\""
    "},\"range_offset_waveform_samples_m \":7.283,\"range_offset_m\":3.1415}"
};

// Scanner settings for waveform output
const MetaDataItemInfo RDB_RIEGL_WAVEFORM_SETTINGS = {
    /* name        */ "riegl.waveform_settings",
    /* title       */ "Waveform Settings",
    /* description */ "Scanner settings for waveform output",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"array\",\"d"
    "escription\":\"Scanner settings for waveform output\",\"title\":\"Waveform S"
    "ettings\",\"items\":{\"type\":\"object\",\"properties\":{\"logic_expression\":{\"t"
    "ype\":\"string\",\"description\":\"Logic expression of smart waveforms "
    "filter\"},\"pass_dev_greater\":{\"type\":\"integer\",\"description\":\"Threshold"
    " for deviation greater than "
    "[1]\"},\"pass_dev_less\":{\"type\":\"integer\",\"description\":\"Threshold for "
    "deviation less than "
    "[1]\"},\"pass_rng_less\":{\"type\":\"number\",\"description\":\"Threshold for "
    "range less than "
    "[m]\"},\"pass_rng_greater\":{\"type\":\"number\",\"description\":\"Threshold for"
    " range greater than "
    "[m]\"},\"smart_enabled\":{\"type\":\"boolean\",\"description\":\"Smart waveform "
    "output "
    "enabled\"},\"channel_idx_mask\":{\"type\":\"integer\",\"description\":\"Bit mask"
    " for channels which belong to sbl_name: Channel 0 = Bit0, Channel 1 = "
    "Bit1, ...\"},\"pass_ampl_less\":{\"type\":\"number\",\"description\":\"Threshold"
    " for amplitude less than "
    "[dB]\"},\"sbl_name\":{\"type\":\"string\",\"description\":\"Name of sample "
    "block, e.g.: wfm, "
    "wwf\"},\"enabled\":{\"type\":\"boolean\",\"description\":\"Waveform output enabl"
    "ed\"},\"pass_ampl_greater\":{\"type\":\"number\",\"description\":\"Threshold for"
    " amplitude greater than "
    "[dB]\"}},\"required\":[\"sbl_name\",\"enabled\",\"channel_idx_mask\"]}}"
    ,
    /* example: */
    "[{\"pass_rng_less\":13.11,\"pass_rng_greater\":9.27,\"smart_enabled\":true,\""
    "channel_idx_mask\":11,\"pass_ampl_less\":5.0,\"sbl_name\":\"wfm\",\"enabled\":t"
    "rue,\"pass_ampl_greater\":1.0},{\"channel_idx_mask\":32,\"sbl_name\":\"wwf\",\""
    "enabled\":false}]"
};

// Window analysis data estimated from scandata and resulting filter parameters
const MetaDataItemInfo RDB_RIEGL_WINDOW_ANALYSIS = {
    /* name        */ "riegl.window_analysis",
    /* title       */ "Window Analysis",
    /* description */ "Window analysis data estimated from scandata and resulting filter parameters",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Window Analysis\",\"required\":[\"result\",\"filter\",\"settings\"],\"de"
    "scription\":\"Window analysis data estimated from scandata and resulting"
    " filter parameters\",\"properties\":{\"result\":{\"type\":\"object\",\"propertie"
    "s\":{\"amplitude_offset\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"desc"
    "ription\":\"[dB]\"},\"timestamp\":{\"type\":\"array\",\"items\":{\"type\":\"number\"}"
    ",\"description\":\"[s]\"},\"range_mean\":{\"type\":\"array\",\"items\":{\"type\":\"nu"
    "mber\"},\"description\":\"[m]\"},\"amplitude_mean\":{\"type\":\"array\",\"items\":{"
    "\"type\":\"number\"},\"description\":\"[dB]\"},\"amplitude_sigma\":{\"type\":\"arra"
    "y\",\"items\":{\"type\":\"number\"},\"description\":\"[dB]\"},\"angle\":{\"type\":\"ar"
    "ray\",\"items\":{\"type\":\"number\"},\"description\":\"[deg]\"},\"range_sigma\":{\""
    "type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"[m]\"}},\"require"
    "d\":[\"angle\",\"range_mean\",\"range_sigma\",\"amplitude_mean\",\"amplitude_sig"
    "ma\",\"amplitude_offset\"]},\"filter\":{\"type\":\"object\",\"properties\":{\"angl"
    "e\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"[deg]\"},\"r"
    "ange_min\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\":\"[m]"
    "\"},\"range_max\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"description\""
    ":\"[m]\"},\"amplitude_max\":{\"type\":\"array\",\"items\":{\"type\":\"number\"},\"des"
    "cription\":\"[dB]\"}},\"required\":[\"angle\",\"range_min\",\"range_max\",\"amplit"
    "ude_max\"]},\"settings\":{\"type\":\"object\",\"properties\":{\"amplitude\":{\"typ"
    "e\":\"object\",\"properties\":{\"additive_value\":{\"type\":\"number\"},\"sigma_fa"
    "ctor\":{\"type\":\"number\"}},\"required\":[\"sigma_factor\",\"additive_value\"]}"
    ",\"range\":{\"type\":\"object\",\"properties\":{\"additive_value\":{\"type\":\"numb"
    "er\"},\"sigma_factor\":{\"type\":\"number\"}},\"required\":[\"sigma_factor\",\"add"
    "itive_value\"]}},\"required\":[\"range\",\"amplitude\"]}}}"
    ,
    /* example: */
    "{\"result\":{\"amplitude_offset\":[1.9,1.9],\"timestamp\":[408.4441,411.4443"
    "],\"range_mean\":[0.1105621,0.1079564,0.1087088,0.1067261,0.1054582,0.10"
    "90412,0.102871,0.1019044,0.1051523,0.1058445,0.1031261],\"amplitude_mea"
    "n\":[5.347396,5.263155,5.224655,5.179926,5.097782,5.116479,5.051756,4.9"
    "83473,5.007885,5.002441,4.982],\"amplitude_sigma\":[0.4272844,0.4298479,"
    "0.4236816,0.4283583,0.4362353,0.4315141,0.4373984,0.4472798,0.4346001,"
    "0.4345487,0.4540681],\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15.6,"
    "15.7,15.8,15.9],\"range_sigma\":[0.01869652,0.02151435,0.01747969,0.0191"
    "8765,0.01945776,0.01934862,0.01955329,0.02225589,0.02229977,0.01899122"
    ",0.02009433]},\"filter\":{\"angle\":[14.9,15.0,15.1,15.2,15.3,15.4,15.5,15"
    ".6,15.7,15.8,15.9],\"range_min\":[-0.208,-0.21,-0.212,-0.214,-0.216,-0.2"
    "18,-0.219,-0.221,-0.223,-0.225,-0.227],\"range_max\":[0.424,0.425,0.426,"
    "0.427,0.428,0.428,0.429,0.43,0.431,0.431,0.432],\"amplitude_max\":[8.04,"
    "8.01,7.99,7.96,7.93,7.9,7.88,7.85,7.83,7.8,7.78]},\"settings\":{\"amplitu"
    "de\":{\"additive_value\":1.0,\"sigma_factor\":4},\"range\":{\"additive_value\":"
    "0.1,\"sigma_factor\":8}}}"
};

// Correction parameters for window glass echoes
const MetaDataItemInfo RDB_RIEGL_WINDOW_ECHO_CORRECTION = {
    /* name        */ "riegl.window_echo_correction",
    /* title       */ "Window Echo Correction",
    /* description */ "Correction parameters for window glass echoes",
    /* status      */ RDB_STATUS_OPTIONAL,

    /* schema: */
    "{\"$schema\":\"http://json-schema.org/draft-04/schema#\",\"type\":\"object\",\""
    "title\":\"Window Echo Correction\",\"required\":[\"amplitude\",\"range\",\"slice"
    "s\"],\"description\":\"Correction parameters for window glass echoes\",\"pro"
    "perties\":{\"amplitude\":{\"type\":\"object\",\"description\":\"Amplitude axis "
    "of correction table\",\"properties\":{\"entries\":{\"type\":\"integer\",\"minimu"
    "m\":1,\"description\":\"Number of amplitude entries\"},\"minimum\":{\"type\":\"n"
    "umber\",\"minimum\":0.0,\"description\":\"Minimum amplitude in "
    "dB\"},\"maximum\":{\"type\":\"number\",\"minimum\":0.0,\"description\":\"Maximum "
    "amplitude in dB\"}},\"required\":[\"minimum\",\"maximum\",\"entries\"]},\"slices"
    "\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"description\":\"Window echo "
    "correction parameter slice\",\"properties\":{\"amplitude\":{\"type\":\"number\""
    ",\"description\":\"Window echo amplitude of slice in dB\"},\"table\":{\"type\""
    ":\"array\",\"items\":{\"type\":\"array\",\"items\":{\"type\":\"array\",\"items\":{\"typ"
    "e\":\"number\",\"description\":\"Table cell (item 0: amplitude in dB, 1: "
    "range in m, 2: flags)\"},\"maxItems\":3,\"description\":\"Table column (= "
    "range axis)\",\"minItems\":3},\"description\":\"Table row (= amplitude "
    "axis)\",\"minItems\":1},\"description\":\"Correction table (dimension "
    "defined by the 'amplitude' and 'range' objects)\",\"minItems\":1}},\"requi"
    "red\":[\"amplitude\",\"table\"]}},\"range\":{\"type\":\"object\",\"description\":\"R"
    "ange axis of correction table\",\"properties\":{\"entries\":{\"type\":\"intege"
    "r\",\"minimum\":1,\"description\":\"Number of range entries\"},\"minimum\":{\"ty"
    "pe\":\"number\",\"minimum\":-2.0,\"description\":\"Minimum range in m\",\"maximu"
    "m\":2.0},\"maximum\":{\"type\":\"number\",\"minimum\":-2.0,\"description\":\"Maxim"
    "um range in "
    "m\",\"maximum\":2.0}},\"required\":[\"minimum\",\"maximum\",\"entries\"]}}}"
    ,
    /* example: */
    "{\"amplitude\":{\"entries\":128,\"minimum\":2,\"maximum\":20},\"slices\":[{\"ampl"
    "itude\":1.5,\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]]},{\"amplitude"
    "\":2.0,\"table\":[[[6.23,0.3535,1]],[[5.54,0.72375,1]]]}],\"range\":{\"entri"
    "es\":128,\"minimum\":-1.5060822940732335,\"maximum\":1.5060822940732335}}"
};

// Table of all meta data item details records
const MetaDataItemInfo* const RDB_META_DATA_ITEMS[] = {
    &RDB_RIEGL_ANGULAR_NOTCH_FILTER,
    &RDB_RIEGL_ATMOSPHERE,
    &RDB_RIEGL_BEAM_GEOMETRY,
    &RDB_RIEGL_CONTROL_OBJECT_CATALOG,
    &RDB_RIEGL_CONTROL_OBJECT_REFERENCE_FILE,
    &RDB_RIEGL_DETECTION_PROBABILITY,
    &RDB_RIEGL_DEVICE,
    &RDB_RIEGL_DEVICE_GEOMETRY,
    &RDB_RIEGL_DEVICE_GEOMETRY_PASSIVE_CHANNEL,
    &RDB_RIEGL_DEVICE_OUTPUT_LIMITS,
    &RDB_RIEGL_DEVICES,
    &RDB_RIEGL_ECHO_INFO,
    &RDB_RIEGL_EXPONENTIAL_DECOMPOSITION,
    &RDB_RIEGL_GAUSSIAN_DECOMPOSITION,
    &RDB_RIEGL_GEO_TAG,
    &RDB_RIEGL_GEOMETRIC_SCALE_FACTOR,
    &RDB_RIEGL_GEOREFERENCING_PARAMETERS,
    &RDB_RIEGL_ITEM_NAMES,
    &RDB_RIEGL_LICENSES,
    &RDB_RIEGL_MTA_SETTINGS,
    &RDB_RIEGL_NEAR_RANGE_CORRECTION,
    &RDB_RIEGL_NOISE_ESTIMATES,
    &RDB_RIEGL_NOTCH_FILTER,
    &RDB_RIEGL_PIXEL_INFO,
    &RDB_RIEGL_PLANE_PATCH_MATCHING,
    &RDB_RIEGL_PLANE_PATCH_STATISTICS,
    &RDB_RIEGL_PLANE_SLOPE_CLASS_INFO,
    &RDB_RIEGL_POINT_ATTRIBUTE_GROUPS,
    &RDB_RIEGL_POINTCLOUD_INFO,
    &RDB_RIEGL_POSE_ESTIMATION,
    &RDB_RIEGL_POSE_SENSORS,
    &RDB_RIEGL_PULSE_POSITION_MODULATION,
    &RDB_RIEGL_RANGE_STATISTICS,
    &RDB_RIEGL_RECEIVER_INTERNALS,
    &RDB_RIEGL_REFLECTANCE_CALCULATION,
    &RDB_RIEGL_REFLECTANCE_CORRECTION,
    &RDB_RIEGL_SCAN_PATTERN,
    &RDB_RIEGL_SHOT_INFO,
    &RDB_RIEGL_STORED_FILTERS,
    &RDB_RIEGL_SYSTEM_DESCRIPTION,
    &RDB_RIEGL_TEMPERATURE_CALCULATION,
    &RDB_RIEGL_TIME_BASE,
    &RDB_RIEGL_TRAJECTORY_INFO,
    &RDB_RIEGL_VERTEX_INFO,
    &RDB_RIEGL_VOXEL_INFO,
    &RDB_RIEGL_WAVEFORM_AVERAGING_SETTINGS,
    &RDB_RIEGL_WAVEFORM_INFO,
    &RDB_RIEGL_WAVEFORM_SETTINGS,
    &RDB_RIEGL_WINDOW_ANALYSIS,
    &RDB_RIEGL_WINDOW_ECHO_CORRECTION
};
const std::size_t RDB_META_DATA_ITEM_COUNT(
    sizeof(RDB_META_DATA_ITEMS) / sizeof(RDB_META_DATA_ITEMS[0])
);
const std::vector<const MetaDataItemInfo*> RDB_META_DATA_ITEMS_VECTOR(
    RDB_META_DATA_ITEMS, RDB_META_DATA_ITEMS + RDB_META_DATA_ITEM_COUNT
);

}}} // namespace riegl::rdb::pointcloud

#endif // RDB_354CFFB3_BDAA_4E38_98C8_9C09D0C0AD87
