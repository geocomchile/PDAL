/*
 *******************************************************************************
 *
 *  Copyright 2022 RIEGL Laser Measurement Systems
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  SPDX-License-Identifier: Apache-2.0
 *
 *******************************************************************************
 */
/*!
 *******************************************************************************
 *
 * \file    pointcloudData.hpp
 * \author  RIEGL LMS GmbH, Austria
 * \brief   Pointcloud class implementation details
 * \version 2015-10-14/AW: Initial version
 *
 *******************************************************************************
 */

#ifndef RIEGL_RDB_POINTCLOUDDATA_HPP
#define RIEGL_RDB_POINTCLOUDDATA_HPP

//---< NAMESPACE >--------------------------------------------------------------

namespace riegl {
namespace rdb {

//---< CLASS Pointcloud >-------------------------------------------------------

/*!
 * \internal
 * \brief Implementation details
 *
 * forward declaration of point cloud implementation details
 */
struct PointcloudData;

}} // namespace riegl::rdb

#endif // RIEGL_RDB_POINTCLOUDDATA_HPP
