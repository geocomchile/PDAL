/*
 *******************************************************************************
 *
 *  Copyright 2022 RIEGL Laser Measurement Systems
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  SPDX-License-Identifier: Apache-2.0
 *
 *******************************************************************************
 */
/*!
 *******************************************************************************
 *
 * \author  RIEGL LMS GmbH, Austria
 * \brief   Description of RIEGL point attributes in RDB 2 database files
 * \version 2015-11-05/AW: Initial version
 * \version 2015-11-20/AW: Minimum value of "riegl.pulse_width" fixed
 * \version 2016-09-30/AW: New attributes for voxel and plane patch datasets
 * \version 2016-10-25/AW: Point coordinates correction vector attribute added
 * \version 2016-11-17/AW: Attributes for voxel datasets updated
 * \version 2016-11-23/AW: Added constants for named point attribute values
 * \version 2016-12-05/AW: Compression options added
 * \version 2016-12-20/AW: JSON: switched names from camel case to underscores
 * \version 2017-01-20/AW: Maximum value of "riegl.pulse_width" fixed
 * \version 2017-01-23/AW: New attributes for laser shots added: riegl.shot_...
 * \version 2017-01-31/AW: New attributes for FWA and MTA tools added
 * \version 2017-02-24/AW: Definition of riegl.covariances fixed
 * \version 2017-03-02/AW: New point attribute riegl.plane_count added
 * \version 2017-03-22/AW: Optional attribute scale factor added
 * \version 2017-05-10/AW: Definition of riegl.plane_count fixed
 * \version 2017-06-27/AW: Description of target_index and target_count fixed
 * \version 2017-08-22/AW: New attributes for waveform sample blocks and values
 * \version 2017-10-03/AW: Description of wfm_sbl_first and wfm_sda_first fixed
 * \version 2017-10-09/AW: Definition of riegl.amplitude modified
 * \version 2017-10-24/AW: New attribute riegl.line_angle_coarse added
 * \version 2017-11-10/AW: Definition of riegl.timestamp modified (#2588)
 * \version 2017-11-20/AW: Resolution of riegl.pca_extents increased
 * \version 2017-11-21/AW: Attributes for trajectory (position+orientation) files
 * \version 2017-11-22/AW: New attribute riegl.voxel_collapsed added
 * \version 2017-11-22/AW: Resolution of riegl.std_dev increased
 * \version 2018-01-10/AW: New attribute riegl.direction_coarse added
 * \version 2018-01-15/AW: Comments of riegl.fwa updated
 * \version 2018-02-14/AW: Definition of riegl.timestamp fixed (#2588)
 * \version 2018-02-22/AW: Description of target_index and target_count fixed
 * \version 2018-03-09/AW: New attribute property "invalid value" added (#3047)
 * \version 2018-03-26/AW: Definition of riegl.temperature modified
 * \version 2018-04-20/AW: Definition of riegl.[pof_]timestamp fixed (#2588)
 * \version 2018-05-24/AW: Attributes for voxel and pixel datasets added
 * \version 2018-06-08/AW: Attributes for waveform and echo datasets added
 * \version 2018-06-25/AW: Definition of riegl.wfm_sbl_std_dev fixed
 * \version 2018-06-28/AW: New attributes riegl.pps_timestamp_[ex|in]tern added
 * \version 2018-07-04/AW: Invalid value for "riegl.pulse_width" added
 * \version 2018-11-19/AW: New attribute riegl.direction_medium added
 * \version 2018-11-28/AW: Definition of riegl.scan_angle modified
 * \version 2018-12-04/AW: Definition of riegl.plane_spread removed
 * \version 2019-02-25/AW: New attribute riegl.xyz_socs added
 * \version 2019-03-14/AW: New attribute riegl.voxel_index added
 * \version 2019-03-14/AW: New attribute riegl.voxel_linear_sums added
 * \version 2019-03-14/AW: New attribute riegl.voxel_square_sums added
 * \version 2019-03-14/AW: New attribute riegl.pixel_linear_sums added
 * \version 2019-03-14/AW: New attribute riegl.pixel_square_sums added
 * \version 2019-03-14/AW: New attribute riegl.hydro_refraction_corrected added
 * \version 2019-03-14/AW: New attribute riegl.hydro_intersection_point added
 * \version 2019-03-14/AW: New attribute riegl.hydro_intersection_normal added
 * \version 2019-04-10/AW: Definition of riegl.xy_map and riegl.xyz_map fixed
 * \version 2019-04-15/AW: Attributes were separated into groups
 * \version 2019-05-16/AW: New attribute riegl.hydro_wsm_uncertainty added
 * \version 2019-05-22/AW: New attribute riegl.plane_patch_distance added
 * \version 2019-05-22/AW: New attribute riegl.plane_patch_angular_distance added
 * \version 2019-05-22/AW: Titles of riegl.pof_satellites_* attributes fixed
 * \version 2019-06-25/AW: New attribute riegl.pof_satellites_qzss added
 * \version 2019-11-07/AW: Attributes riegl.pof_xyz and riegl.pof_*_ned added
 * \version 2019-11-11/AW: Attribute riegl.plane_patch_lateral_distance added
 * \version 2019-11-15/AW: Attribute riegl.plane_patch_link_vector added
 * \version 2019-11-22/AW: Attribute riegl.plane_occupancy added
 * \version 2019-11-22/AW: Attributes riegl.raw_(line|frame)_angle added
 * \version 2019-11-25/AW: Attribute riegl.plane_cog_link added
 * \version 2019-11-25/AW: Attribute riegl.plane_confidence_normal added
 * \version 2019-12-02/AW: Attribute riegl.match_count added
 * \version 2019-12-13/AW: Attributes for tie-/control objects added
 * \version 2019-12-19/AW: Attributes for tie-/control objects added
 * \version 2019-12-19/AW: Title and description of riegl.mta_unresolved updated
 * \version 2020-01-08/AW: Move riegl.height_center/mean/min/max before riegl.point_count
 * \version 2020-04-15/AW: Attribute riegl.reference_object_id updated
 * \version 2020-06-12/AW: Attribute riegl.scanner_position added
 * \version 2020-09-10/AW: Attribute riegl.line_angle_reduced added
 * \version 2020-09-17/AW: Attribute riegl.background_radiation updated
 * \version 2020-09-24/AW: Attribute riegl.background_radiation_si added
 * \version 2020-09-24/AW: Attribute riegl.background_radiation_ingaas added
 * \version 2020-09-24/AW: Attribute riegl.temperature_estimated_si added
 * \version 2020-09-24/AW: Attribute riegl.temperature_estimated_ingaas added
 * \version 2020-09-25/AW: Attribute riegl.temperature_estimated_ingaas_si added
 * \version 2020-10-08/AW: Attribute riegl.window_echo_impact_corrected added
 * \version 2020-11-16/AW: Attribute riegl.point_count_grid_cell added (#3720)
 * \version 2020-11-26/AW: Resolution of riegl.pof_accuracy_* attributes updated (#3761)
 * \version 2020-12-02/AW: Move riegl.pof_xyz after riegl.pof_yaw (#3760)
 * \version 2020-12-03/AW: Add riegl.scan_line_index and riegl.shot_index_line (#3759)
 * \version 2021-02-02/AW: Attribute riegl.mirror_facet updated (storage "variable")
 * \version 2021-02-02/AW: Attribute riegl.plane_slope_class added (rdbplanes/#7)
 * \version 2021-02-16/AW: Attribute riegl.source_cloud_count added (#3810)
 * \version 2021-03-03/AW: Attribute riegl.shot_direction_levelled added (#3820)
 * \version 2021-04-14/AW: Attribute riegl.obs_confidence_xy added (#3861)
 * \version 2021-04-14/AW: Attribute riegl.obs_confidence_z added (#3861)
 * \version 2021-04-14/AW: Attribute riegl.obs_signal_confidence_rot added (#3861)
 * \version 2021-06-30/AW: Attributes riegl.pca_axis_min and _max updated (#3930)
 * \version 2021-07-09/AW: Attribute riegl.extinction added (#3935)
 * \version 2021-07-14/AW: Attributes riegl.svb_* added (#3945)
 * \version 2021-09-08/AW: Attribute riegl.dynamic_object_point added (#3979)
 * \version 2021-09-08/AW: Attribute riegl.single_source_point added (#3975)
 * \version 2021-09-08/AW: Attribute riegl.mirror_object_point added (#3978)
 * \version 2021-09-20/AW: Attribute riegl.plane_cluster_id added (#3997)
 * \version 2021-11-04/AW: Attribute riegl.nir added (#4042)
 * \version 2021-12-07/AW: Add riegl.obs_confidence_range/_theta/_phi (#4075)
 * \version 2022-01-26/AW: Add optional point attribute tags (#4128)
 * \version 2022-03-11/AW: Add "boolean" and "enumeration" tags (#4128)
 * \version 2022-03-18/AW: Add named values for enumeration attributes (#4128)
 * \version 2022-03-31/AW: Attribute riegl.source_indicator updated (#4128/17)
 * \version 2022-04-13/AW: Attribute riegl.target_type added (#4188)
 * \version 2022-04-20/AW: Attribute riegl.shot_biaxial_shift added (#4195)
 * \version 2022-05-20/AW: Attribute riegl.cp_search_radius added (#4236)
 * \version 2022-05-20/AW: Attribute riegl.cp_maximum_distance added (#4236)
 * \version 2022-05-30/AW: Attribute riegl.dyntrig_uncertain_point added (#4217)
 * \version 2022-08-16/AW: Attribute riegl.segment_id added (#4307)
 * \version 2022-09-06/AW: Attribute renamed to riegl.mta_uncertain_point (#4335)
 * \version 2022-10-06/AW: Attribute riegl.rgba updated (description)
 * \version 2022-10-10/AW: Add "NED" suffix to the titles of "riegl.pof_*_ned"
 * \version 2022-11-09/AW: Attribute riegl.pof_age_of_corrections added (#4412)
 * \version 2022-11-09/AW: Attribute riegl.pof_baseline_length added (#4412)
 * \version 2022-11-09/AW: Attribute riegl.pof_solution_gnss added (#4412)
 *
 *******************************************************************************
 */

#ifndef RDB_354CFFB3_BDAA_4E38_98C8_9C09D0C0AD86
#define RDB_354CFFB3_BDAA_4E38_98C8_9C09D0C0AD86

#include <vector>
#include <limits>
#include <string>
#include <cstdlib>
#include <cstdint>

#include "riegl/rdb.hpp"

namespace riegl {
namespace rdb {
namespace pointcloud {

// Point attribute definition version
const std::string RDB_POINT_ATTRIBUTES_VERSION = "1.4.1";
const std::string RDB_POINT_ATTRIBUTES_DATE = "2022-11-09";

// Invalid value
const double RDB_NO_INVALID_VALUE = std::numeric_limits<double>::quiet_NaN(); // attribute has no invalid value

// Storage classes (for backward compatibility)
const unsigned char RDB_STORAGE_CONSTANT = PointAttribute::CONSTANT; // value cannot be changed
const unsigned char RDB_STORAGE_VARIABLE = PointAttribute::VARIABLE; // value can change from time to time
const unsigned char RDB_STORAGE_DYNAMIC = PointAttribute::DYNAMIC; // value is likely to be changed often

// Compression options (for backward compatibility)
const unsigned char RDB_COMPRESSION_DEFAULT = PointAttribute::DEFAULT; // nothing special, just use default compression algorithm
const unsigned char RDB_COMPRESSION_DELTA = PointAttribute::DELTA; // calculate differences between two consecutive values
const unsigned char RDB_COMPRESSION_SHUFFLE = PointAttribute::SHUFFLE; // shuffle bytes of point attribute values
const unsigned char RDB_COMPRESSION_DELTA_SHUFFLE = PointAttribute::DELTA_SHUFFLE; // calculate differences and shuffle bytes

// Container record for point attribute details (for backward compatibility)
typedef PointAttribute PointAttributeInfo;

//______________________________________________________________________________
//
// POINT ATTRIBUTE GROUP "Coordinates/Vectors"
//______________________________________________________________________________
//

// Cartesian point coordinates wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_XYZ(
    /* name               */ "riegl.xyz",
    /* title              */ "XYZ",
    /* description        */ "Cartesian point coordinates wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -535000.0,
    /* maximumValue       */ 535000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_XYZ_X = 0;
const std::size_t RDB_RIEGL_XYZ_Y = 1;
const std::size_t RDB_RIEGL_XYZ_Z = 2;

// Cartesian point coordinates wrt. scanner's coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_XYZ_SOCS(
    /* name               */ "riegl.xyz_socs",
    /* title              */ "XYZ SOCS",
    /* description        */ "Cartesian point coordinates wrt. scanner's coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -535000.0,
    /* maximumValue       */ 535000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_XYZ_SOCS_X = 0;
const std::size_t RDB_RIEGL_XYZ_SOCS_Y = 1;
const std::size_t RDB_RIEGL_XYZ_SOCS_Z = 2;

// Point coordinates wrt. a projected CRS (e.g. Web Mercator EPSG:3857, 0: Easting, 1: Northing, 2: Height)
const PointAttribute RDB_RIEGL_XYZ_MAP(
    /* name               */ "riegl.xyz_map",
    /* title              */ "XYZ Map",
    /* description        */ "Point coordinates wrt. a projected CRS (e.g. Web Mercator EPSG:3857, 0: Easting, 1: Northing, 2: Height)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -20037508.343,
    /* maximumValue       */ 20037508.343,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_XYZ_MAP_EASTING = 0;
const std::size_t RDB_RIEGL_XYZ_MAP_NORTHING = 1;
const std::size_t RDB_RIEGL_XYZ_MAP_HEIGHT = 2;

// Point coordinates wrt. a projected CRS (e.g. Web Mercator EPSG:3857, 0: Easting, 1: Northing)
const PointAttribute RDB_RIEGL_XY_MAP(
    /* name               */ "riegl.xy_map",
    /* title              */ "XY Map",
    /* description        */ "Point coordinates wrt. a projected CRS (e.g. Web Mercator EPSG:3857, 0: Easting, 1: Northing)",
    /* unitSymbol         */ "m",
    /* length             */ 2,
    /* resolution         */ 0.00933069192934280443318950659659094526432454586029052734375,
    /* minimumValue       */ -20037508.3427892439067363739013671875,
    /* maximumValue       */ 20037508.333458550274372100830078125,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_XY_MAP_EASTING = 0;
const std::size_t RDB_RIEGL_XY_MAP_NORTHING = 1;

// Corrections that were applied (added) to the Cartesian point coordinates (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_XYZ_CORRECTIONS(
    /* name               */ "riegl.xyz_corrections",
    /* title              */ "XYZ Corrections",
    /* description        */ "Corrections that were applied (added) to the Cartesian point coordinates (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -5000.0,
    /* maximumValue       */ 5000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_XYZ_CORRECTIONS_X = 0;
const std::size_t RDB_RIEGL_XYZ_CORRECTIONS_Y = 1;
const std::size_t RDB_RIEGL_XYZ_CORRECTIONS_Z = 2;

// Target distance wrt. SOCS origin
const PointAttribute RDB_RIEGL_RANGE(
    /* name               */ "riegl.range",
    /* title              */ "Range",
    /* description        */ "Target distance wrt. SOCS origin",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 50000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Polar angle (inclination) wrt. SOCS (0..180°)
const PointAttribute RDB_RIEGL_THETA(
    /* name               */ "riegl.theta",
    /* title              */ "Theta",
    /* description        */ "Polar angle (inclination) wrt. SOCS (0..180°)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Azimuthal angle wrt. SOCS (0..360°)
const PointAttribute RDB_RIEGL_PHI(
    /* name               */ "riegl.phi",
    /* title              */ "Phi",
    /* description        */ "Azimuthal angle wrt. SOCS (0..360°)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Cartesian coordinates of the scanner position wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_SCANNER_POSITION(
    /* name               */ "riegl.scanner_position",
    /* title              */ "Scanner Position",
    /* description        */ "Cartesian coordinates of the scanner position wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -535000.0,
    /* maximumValue       */ 535000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position, transform",
    /* namedValues        */ ""
);

// Laser beam direction vector wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_DIRECTION(
    /* name               */ "riegl.direction",
    /* title              */ "Direction",
    /* description        */ "Laser beam direction vector wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.000031,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_DIRECTION_X = 0;
const std::size_t RDB_RIEGL_DIRECTION_Y = 1;
const std::size_t RDB_RIEGL_DIRECTION_Z = 2;

// Laser beam direction vector wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_DIRECTION_MEDIUM(
    /* name               */ "riegl.direction_medium",
    /* title              */ "Direction",
    /* description        */ "Laser beam direction vector wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.0007,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_DIRECTION_MEDIUM_X = 0;
const std::size_t RDB_RIEGL_DIRECTION_MEDIUM_Y = 1;
const std::size_t RDB_RIEGL_DIRECTION_MEDIUM_Z = 2;

// Coarse laser beam direction vector wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_DIRECTION_COARSE(
    /* name               */ "riegl.direction_coarse",
    /* title              */ "Direction",
    /* description        */ "Coarse laser beam direction vector wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.015,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_DIRECTION_COARSE_X = 0;
const std::size_t RDB_RIEGL_DIRECTION_COARSE_Y = 1;
const std::size_t RDB_RIEGL_DIRECTION_COARSE_Z = 2;

// Laser beam origin wrt. SOCS (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_SHOT_ORIGIN(
    /* name               */ "riegl.shot_origin",
    /* title              */ "Laser Shot Origin",
    /* description        */ "Laser beam origin wrt. SOCS (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 250.0e-6,
    /* minimumValue       */ -8.0,
    /* maximumValue       */ 8.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_SHOT_ORIGIN_X = 0;
const std::size_t RDB_RIEGL_SHOT_ORIGIN_Y = 1;
const std::size_t RDB_RIEGL_SHOT_ORIGIN_Z = 2;

// Laser beam biaxial shift vector wrt. SOCS (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_SHOT_BIAXIAL_SHIFT(
    /* name               */ "riegl.shot_biaxial_shift",
    /* title              */ "Laser Shot Biaxial Shift",
    /* description        */ "Laser beam biaxial shift vector wrt. SOCS (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 250.0e-6,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_SHOT_BIAXIAL_SHIFT_X = 0;
const std::size_t RDB_RIEGL_SHOT_BIAXIAL_SHIFT_Y = 1;
const std::size_t RDB_RIEGL_SHOT_BIAXIAL_SHIFT_Z = 2;

// Laser beam direction vector wrt. SOCS (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_SHOT_DIRECTION(
    /* name               */ "riegl.shot_direction",
    /* title              */ "Laser Shot Direction",
    /* description        */ "Laser beam direction vector wrt. SOCS (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 250.0e-9,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_SHOT_DIRECTION_X = 0;
const std::size_t RDB_RIEGL_SHOT_DIRECTION_Y = 1;
const std::size_t RDB_RIEGL_SHOT_DIRECTION_Z = 2;

// Laser beam direction vector wrt. ROCS (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_SHOT_DIRECTION_LEVELLED(
    /* name               */ "riegl.shot_direction_levelled",
    /* title              */ "Laser Shot Direction Levelled",
    /* description        */ "Laser beam direction vector wrt. ROCS (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 250.0e-9,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_SHOT_DIRECTION_LEVELLED_X = 0;
const std::size_t RDB_RIEGL_SHOT_DIRECTION_LEVELLED_Y = 1;
const std::size_t RDB_RIEGL_SHOT_DIRECTION_LEVELLED_Z = 2;

// Target surface normal vector wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_SURFACE_NORMAL(
    /* name               */ "riegl.surface_normal",
    /* title              */ "Surface Normal",
    /* description        */ "Target surface normal vector wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.000031,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_SURFACE_NORMAL_X = 0;
const std::size_t RDB_RIEGL_SURFACE_NORMAL_Y = 1;
const std::size_t RDB_RIEGL_SURFACE_NORMAL_Z = 2;

// Direction vector of shorter edge of plane patch wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_PLANE_UP(
    /* name               */ "riegl.plane_up",
    /* title              */ "Plane Patch Up Vector",
    /* description        */ "Direction vector of shorter edge of plane patch wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.000031,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PLANE_UP_X = 0;
const std::size_t RDB_RIEGL_PLANE_UP_Y = 1;
const std::size_t RDB_RIEGL_PLANE_UP_Z = 2;

// Vector connecting the center point of a plane patch with its center of gravity (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_PLANE_COG_LINK(
    /* name               */ "riegl.plane_cog_link",
    /* title              */ "Plane COG Link Vector",
    /* description        */ "Vector connecting the center point of a plane patch with its center of gravity (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -5000.0,
    /* maximumValue       */ 5000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PLANE_COG_LINK_X = 0;
const std::size_t RDB_RIEGL_PLANE_COG_LINK_Y = 1;
const std::size_t RDB_RIEGL_PLANE_COG_LINK_Z = 2;

// Vector interconnecting the centers (riegl.xyz) of two matched plane patches (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_PLANE_PATCH_LINK_VECTOR(
    /* name               */ "riegl.plane_patch_link_vector",
    /* title              */ "Plane Patch Link Vector",
    /* description        */ "Vector interconnecting the centers (riegl.xyz) of two matched plane patches (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -5000.0,
    /* maximumValue       */ 5000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PLANE_PATCH_LINK_VECTOR_X = 0;
const std::size_t RDB_RIEGL_PLANE_PATCH_LINK_VECTOR_Y = 1;
const std::size_t RDB_RIEGL_PLANE_PATCH_LINK_VECTOR_Z = 2;

// The eigenvector that belongs to the smallest eigenvalue (result of PCA, 0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_PCA_AXIS_MIN(
    /* name               */ "riegl.pca_axis_min",
    /* title              */ "PCA Axis Minimum",
    /* description        */ "The eigenvector that belongs to the smallest eigenvalue (result of PCA, 0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.000031,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PCA_AXIS_MIN_X = 0;
const std::size_t RDB_RIEGL_PCA_AXIS_MIN_Y = 1;
const std::size_t RDB_RIEGL_PCA_AXIS_MIN_Z = 2;

// The eigenvector that belongs to the greatest eigenvalue (result of PCA, 0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_PCA_AXIS_MAX(
    /* name               */ "riegl.pca_axis_max",
    /* title              */ "PCA Axis Maximum",
    /* description        */ "The eigenvector that belongs to the greatest eigenvalue (result of PCA, 0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.000031,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PCA_AXIS_MAX_X = 0;
const std::size_t RDB_RIEGL_PCA_AXIS_MAX_Y = 1;
const std::size_t RDB_RIEGL_PCA_AXIS_MAX_Z = 2;

// Direction of x-axis of model coordinate system wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_MODEL_CS_AXIS_X(
    /* name               */ "riegl.model_cs_axis_x",
    /* title              */ "Model CS X axis",
    /* description        */ "Direction of x-axis of model coordinate system wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 3.125e-05,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_X_X = 0;
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_X_Y = 1;
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_X_Z = 2;

// Direction of y-axis of model coordinate system wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_MODEL_CS_AXIS_Y(
    /* name               */ "riegl.model_cs_axis_y",
    /* title              */ "Model CS Y axis",
    /* description        */ "Direction of y-axis of model coordinate system wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 3.125e-05,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_Y_X = 0;
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_Y_Y = 1;
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_Y_Z = 2;

// Direction of z-axis of model coordinate system wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_MODEL_CS_AXIS_Z(
    /* name               */ "riegl.model_cs_axis_z",
    /* title              */ "Model CS Z axis",
    /* description        */ "Direction of z-axis of model coordinate system wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 3.125e-05,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_Z_X = 0;
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_Z_Y = 1;
const std::size_t RDB_RIEGL_MODEL_CS_AXIS_Z_Z = 2;

// Processed values of an accelerometer
const PointAttribute RDB_RIEGL_ACCELEROMETER(
    /* name               */ "riegl.accelerometer",
    /* title              */ "Accelerometer Values",
    /* description        */ "Processed values of an accelerometer",
    /* unitSymbol         */ "m/s²",
    /* length             */ 3,
    /* resolution         */ 0.0005,
    /* minimumValue       */ -100.0,
    /* maximumValue       */ 100.0,
    /* defaultValue       */ -100.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -100.0,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);

// Processed values of a gyroscope
const PointAttribute RDB_RIEGL_GYROSCOPE(
    /* name               */ "riegl.gyroscope",
    /* title              */ "Gyroscope Values",
    /* description        */ "Processed values of a gyroscope",
    /* unitSymbol         */ "deg/s",
    /* length             */ 3,
    /* resolution         */ 0.001,
    /* minimumValue       */ -5000.0,
    /* maximumValue       */ 5000.0,
    /* defaultValue       */ -5000.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -5000.0,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);

// Processed values of a magnetic field sensor
const PointAttribute RDB_RIEGL_MAGNETIC_FIELD_SENSOR(
    /* name               */ "riegl.magnetic_field_sensor",
    /* title              */ "Magnetic Field Sensor Values",
    /* description        */ "Processed values of a magnetic field sensor",
    /* unitSymbol         */ "µT",
    /* length             */ 3,
    /* resolution         */ 0.01,
    /* minimumValue       */ -100.0,
    /* maximumValue       */ 100.0,
    /* defaultValue       */ -100.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -100.0,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);

// Raw measurement values of an accelerometer (unit see metadata riegl.pose_sensors)
const PointAttribute RDB_RIEGL_ACCELEROMETER_RAW(
    /* name               */ "riegl.accelerometer_raw",
    /* title              */ "Accelerometer Raw Values",
    /* description        */ "Raw measurement values of an accelerometer (unit see metadata riegl.pose_sensors)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 1.0,
    /* minimumValue       */ -32768.0,
    /* maximumValue       */ 32767.0,
    /* defaultValue       */ -32768.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -32768.0,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);

// Raw measurement values of a gyroscope (unit see metadata riegl.pose_sensors)
const PointAttribute RDB_RIEGL_GYROSCOPE_RAW(
    /* name               */ "riegl.gyroscope_raw",
    /* title              */ "Gyroscope Raw Values",
    /* description        */ "Raw measurement values of a gyroscope (unit see metadata riegl.pose_sensors)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 1.0,
    /* minimumValue       */ -32768.0,
    /* maximumValue       */ 32767.0,
    /* defaultValue       */ -32768.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -32768.0,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);

// Raw measurement values of a magnetic field sensor (unit see metadata riegl.pose_sensors)
const PointAttribute RDB_RIEGL_MAGNETIC_FIELD_SENSOR_RAW(
    /* name               */ "riegl.magnetic_field_sensor_raw",
    /* title              */ "Magnetic Field Sensor Raw Values",
    /* description        */ "Raw measurement values of a magnetic field sensor (unit see metadata riegl.pose_sensors)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 1.0,
    /* minimumValue       */ -32768.0,
    /* maximumValue       */ 32767.0,
    /* defaultValue       */ -32768.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -32768.0,
    /* lodSettings        */ "default",
    /* tags               */ "direction",
    /* namedValues        */ ""
);

// Geodetic (Geographic) Latitude
const PointAttribute RDB_RIEGL_POF_LATITUDE(
    /* name               */ "riegl.pof_latitude",
    /* title              */ "Latitude",
    /* description        */ "Geodetic (Geographic) Latitude",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-9,
    /* minimumValue       */ -90.0,
    /* maximumValue       */ 90.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_POF_LATITUDE_NORTH = 90.0;
const double RDB_RIEGL_POF_LATITUDE_SOUTH = -90.0;

// Geodetic (Geographic) Longitude
const PointAttribute RDB_RIEGL_POF_LONGITUDE(
    /* name               */ "riegl.pof_longitude",
    /* title              */ "Longitude",
    /* description        */ "Geodetic (Geographic) Longitude",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-9,
    /* minimumValue       */ -180.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_POF_LONGITUDE_EAST = 180.0;
const double RDB_RIEGL_POF_LONGITUDE_WEST = -180.0;

// Height (vertical distance) wrt. to the ellipsoid of the defined geodetic datum
const PointAttribute RDB_RIEGL_POF_HEIGHT(
    /* name               */ "riegl.pof_height",
    /* title              */ "Ellipsoidal Height",
    /* description        */ "Height (vertical distance) wrt. to the ellipsoid of the defined geodetic datum",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 250.0e-6,
    /* minimumValue       */ -10000.0,
    /* maximumValue       */ 40000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Rotation about the body axis pointing in forward direction (x-axis for NED systems)
const PointAttribute RDB_RIEGL_POF_ROLL(
    /* name               */ "riegl.pof_roll",
    /* title              */ "Roll Angle",
    /* description        */ "Rotation about the body axis pointing in forward direction (x-axis for NED systems)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ -180.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Rotation about the body axis pointing in transverse direction (y-axis for NED systems)
const PointAttribute RDB_RIEGL_POF_PITCH(
    /* name               */ "riegl.pof_pitch",
    /* title              */ "Pitch Angle",
    /* description        */ "Rotation about the body axis pointing in transverse direction (y-axis for NED systems)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ -180.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Rotation about the body axis pointing in vertical direction (z-axis for NED systems)
const PointAttribute RDB_RIEGL_POF_YAW(
    /* name               */ "riegl.pof_yaw",
    /* title              */ "Yaw Angle",
    /* description        */ "Rotation about the body axis pointing in vertical direction (z-axis for NED systems)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Position of the platform in the coordinate system defined by the geo_tag (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_POF_XYZ(
    /* name               */ "riegl.pof_xyz",
    /* title              */ "XYZ",
    /* description        */ "Position of the platform in the coordinate system defined by the geo_tag (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -535000.0,
    /* maximumValue       */ 535000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_POF_XYZ_X = 0;
const std::size_t RDB_RIEGL_POF_XYZ_Y = 1;
const std::size_t RDB_RIEGL_POF_XYZ_Z = 2;

// Rotation about y-axis of the coordinate system defined by the geo_tag
const PointAttribute RDB_RIEGL_POF_ROLL_NED(
    /* name               */ "riegl.pof_roll_ned",
    /* title              */ "Roll Angle NED",
    /* description        */ "Rotation about y-axis of the coordinate system defined by the geo_tag",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ -180.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Rotation about x-axis of the coordinate system defined by the geo_tag
const PointAttribute RDB_RIEGL_POF_PITCH_NED(
    /* name               */ "riegl.pof_pitch_ned",
    /* title              */ "Pitch Angle NED",
    /* description        */ "Rotation about x-axis of the coordinate system defined by the geo_tag",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ -180.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Rotation about inverted z-axis of the coordinate system defined by the geo_tag
const PointAttribute RDB_RIEGL_POF_YAW_NED(
    /* name               */ "riegl.pof_yaw_ned",
    /* title              */ "Yaw Angle NED",
    /* description        */ "Rotation about inverted z-axis of the coordinate system defined by the geo_tag",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Water surface intersection point coordinates wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_HYDRO_INTERSECTION_POINT(
    /* name               */ "riegl.hydro_intersection_point",
    /* title              */ "Water Surface Intersection Point",
    /* description        */ "Water surface intersection point coordinates wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -535000.0,
    /* maximumValue       */ 535000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "position, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_HYDRO_INTERSECTION_POINT_X = 0;
const std::size_t RDB_RIEGL_HYDRO_INTERSECTION_POINT_Y = 1;
const std::size_t RDB_RIEGL_HYDRO_INTERSECTION_POINT_Z = 2;

// Water surface intersection normal vector wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_HYDRO_INTERSECTION_NORMAL(
    /* name               */ "riegl.hydro_intersection_normal",
    /* title              */ "Water Surface Intersection Normal",
    /* description        */ "Water surface intersection normal vector wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.00003125,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_HYDRO_INTERSECTION_NORMAL_X = 0;
const std::size_t RDB_RIEGL_HYDRO_INTERSECTION_NORMAL_Y = 1;
const std::size_t RDB_RIEGL_HYDRO_INTERSECTION_NORMAL_Z = 2;

// Water surface model uncertainty (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_HYDRO_WSM_UNCERTAINTY(
    /* name               */ "riegl.hydro_wsm_uncertainty",
    /* title              */ "Water Surface Model Uncertainty",
    /* description        */ "Water surface model uncertainty (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.0001,
    /* minimumValue       */ -3.2768,
    /* maximumValue       */ 3.2767,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_HYDRO_WSM_UNCERTAINTY_X = 0;
const std::size_t RDB_RIEGL_HYDRO_WSM_UNCERTAINTY_Y = 1;
const std::size_t RDB_RIEGL_HYDRO_WSM_UNCERTAINTY_Z = 2;

// Accuracy of Cartesian coordinates (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_XYZ_ACCURACIES(
    /* name               */ "riegl.xyz_accuracies",
    /* title              */ "XYZ Accuracies",
    /* description        */ "Accuracy of Cartesian coordinates (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);

// Direction of zenith vector wrt. application coordinate system (0: X, 1: Y, 2: Z)
const PointAttribute RDB_RIEGL_ZENITH_VECTOR(
    /* name               */ "riegl.zenith_vector",
    /* title              */ "Zenith Vector",
    /* description        */ "Direction of zenith vector wrt. application coordinate system (0: X, 1: Y, 2: Z)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 0.00003125,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "direction, transform",
    /* namedValues        */ ""
);

//______________________________________________________________________________
//
// POINT ATTRIBUTE GROUP "Time"
//______________________________________________________________________________
//

// Laser shot timestamp (in units of 4 pico seconds = 4e-12 s)
const PointAttribute RDB_RIEGL_SHOT_TIMESTAMP_HR(
    /* name               */ "riegl.shot_timestamp_hr",
    /* title              */ "Laser Shot Timestamp",
    /* description        */ "Laser shot timestamp (in units of 4 pico seconds = 4e-12 s)",
    /* unitSymbol         */ "4ps",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e18,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_SHOT_TIMESTAMP_HR_RESOLUTION = 4.0e-12;

// Laser shot timestamp (100 nano seconds resolution)
const PointAttribute RDB_RIEGL_TIMESTAMP(
    /* name               */ "riegl.timestamp",
    /* title              */ "Timestamp",
    /* description        */ "Laser shot timestamp (100 nano seconds resolution)",
    /* unitSymbol         */ "s",
    /* length             */ 1,
    /* resolution         */ 1.0e-7,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e8,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Start of waveform sample block relative to laser shot timestamp (in units of 4 pico seconds = 4e-12 s)
const PointAttribute RDB_RIEGL_WFM_SBL_TIME_OFFSET(
    /* name               */ "riegl.wfm_sbl_time_offset",
    /* title              */ "Waveform Sample Block Time Offset",
    /* description        */ "Start of waveform sample block relative to laser shot timestamp (in units of 4 pico seconds = 4e-12 s)",
    /* unitSymbol         */ "4ps",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -2.0e9,
    /* maximumValue       */ 2.0e9,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_WFM_SBL_TIME_OFFSET_RESOLUTION = 4.0e-12;

// Position of echo relative to start of waveform sample block (in units of 4 pico seconds = 4e-12 s)
const PointAttribute RDB_RIEGL_WFM_ECHO_TIME_OFFSET(
    /* name               */ "riegl.wfm_echo_time_offset",
    /* title              */ "Echo Time Offset",
    /* description        */ "Position of echo relative to start of waveform sample block (in units of 4 pico seconds = 4e-12 s)",
    /* unitSymbol         */ "4ps",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -2.0e9,
    /* maximumValue       */ 2.0e9,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_WFM_ECHO_TIME_OFFSET_RESOLUTION = 4.0e-12;

// External timestamp (100 nano seconds resolution)
const PointAttribute RDB_RIEGL_PPS_TIMESTAMP_EXTERN(
    /* name               */ "riegl.pps_timestamp_extern",
    /* title              */ "External Timestamp",
    /* description        */ "External timestamp (100 nano seconds resolution)",
    /* unitSymbol         */ "s",
    /* length             */ 1,
    /* resolution         */ 1.0e-7,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e8,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Internal timestamp (in units of 4 pico seconds = 4e-12 s)
const PointAttribute RDB_RIEGL_PPS_TIMESTAMP_INTERN(
    /* name               */ "riegl.pps_timestamp_intern",
    /* title              */ "Internal Timestamp",
    /* description        */ "Internal timestamp (in units of 4 pico seconds = 4e-12 s)",
    /* unitSymbol         */ "4ps",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e18,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_PPS_TIMESTAMP_INTERN_RESOLUTION = 4.0e-12;

// Minimum laser shot timestamp within voxel (100 nano seconds resolution)
const PointAttribute RDB_RIEGL_TIMESTAMP_MIN(
    /* name               */ "riegl.timestamp_min",
    /* title              */ "Timestamp Minimum",
    /* description        */ "Minimum laser shot timestamp within voxel (100 nano seconds resolution)",
    /* unitSymbol         */ "s",
    /* length             */ 1,
    /* resolution         */ 1.0e-7,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e8,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Maximum laser shot timestamp within voxel (100 nano seconds resolution)
const PointAttribute RDB_RIEGL_TIMESTAMP_MAX(
    /* name               */ "riegl.timestamp_max",
    /* title              */ "Timestamp Maximum",
    /* description        */ "Maximum laser shot timestamp within voxel (100 nano seconds resolution)",
    /* unitSymbol         */ "s",
    /* length             */ 1,
    /* resolution         */ 1.0e-7,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e8,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Timestamp (100 nano seconds resolution)
const PointAttribute RDB_RIEGL_POF_TIMESTAMP(
    /* name               */ "riegl.pof_timestamp",
    /* title              */ "Timestamp",
    /* description        */ "Timestamp (100 nano seconds resolution)",
    /* unitSymbol         */ "s",
    /* length             */ 1,
    /* resolution         */ 1.0e-7,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 9.0e8,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Date of acquisition (0: year, 1: month [1-12], 2: day [1-31], not specified if any is 0)
const PointAttribute RDB_RIEGL_ACQUISITION_DATE(
    /* name               */ "riegl.acquisition_date",
    /* title              */ "Acquisition Date",
    /* description        */ "Date of acquisition (0: year, 1: month [1-12], 2: day [1-31], not specified if any is 0)",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4095.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_ACQUISITION_DATE_YEAR = 0;
const std::size_t RDB_RIEGL_ACQUISITION_DATE_MONTH = 1;
const std::size_t RDB_RIEGL_ACQUISITION_DATE_DAY = 2;

//______________________________________________________________________________
//
// POINT ATTRIBUTE GROUP "Primary Attributes"
//______________________________________________________________________________
//

// Target surface reflectance
const PointAttribute RDB_RIEGL_REFLECTANCE(
    /* name               */ "riegl.reflectance",
    /* title              */ "Reflectance",
    /* description        */ "Target surface reflectance",
    /* unitSymbol         */ "dB",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ -327.68,
    /* maximumValue       */ 327.67,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Echo signal amplitude
const PointAttribute RDB_RIEGL_AMPLITUDE(
    /* name               */ "riegl.amplitude",
    /* title              */ "Amplitude",
    /* description        */ "Echo signal amplitude",
    /* unitSymbol         */ "dB",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ -327.68,
    /* maximumValue       */ 327.67,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Uncalibrated echo signal amplitude (for legacy RIEGL LMS instruments)
const PointAttribute RDB_RIEGL_INTENSITY(
    /* name               */ "riegl.intensity",
    /* title              */ "Intensity",
    /* description        */ "Uncalibrated echo signal amplitude (for legacy RIEGL LMS instruments)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Gain of photodiode
const PointAttribute RDB_RIEGL_GAIN(
    /* name               */ "riegl.gain",
    /* title              */ "Gain",
    /* description        */ "Gain of photodiode",
    /* unitSymbol         */ "dB",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ -327.68,
    /* maximumValue       */ 327.67,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Pulse shape deviation (negative means unavailable)
const PointAttribute RDB_RIEGL_DEVIATION(
    /* name               */ "riegl.deviation",
    /* title              */ "Deviation",
    /* description        */ "Pulse shape deviation (negative means unavailable)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 32767.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::int16_t RDB_RIEGL_DEVIATION_UNAVAILABLE = -1;

// Pulse width (full width at half maximum, for Q-Series instruments, 0 = invalid)
const PointAttribute RDB_RIEGL_PULSE_WIDTH(
    /* name               */ "riegl.pulse_width",
    /* title              */ "Pulse Width",
    /* description        */ "Pulse width (full width at half maximum, for Q-Series instruments, 0 = invalid)",
    /* unitSymbol         */ "ns",
    /* length             */ 1,
    /* resolution         */ 0.1,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 6553.5,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_PULSE_WIDTH_INVALID = 0.0;

// Point class number
const PointAttribute RDB_RIEGL_CLASS(
    /* name               */ "riegl.class",
    /* title              */ "Point Class",
    /* description        */ "Point class number",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=Created, never classified\n"
);

// Point color derived from digital camera, 0: Red, 1: Green, 2: Blue, 3: Alpha (0 = no color); additional colors (if any) are stored in riegl.rgba_2, riegl.rgba_3, ...
const PointAttribute RDB_RIEGL_RGBA(
    /* name               */ "riegl.rgba",
    /* title              */ "True Color",
    /* description        */ "Point color derived from digital camera, 0: Red, 1: Green, 2: Blue, 3: Alpha (0 = no color); additional colors (if any) are stored in riegl.rgba_2, riegl.rgba_3, ...",
    /* unitSymbol         */ "",
    /* length             */ 4,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "color",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_RGBA_RED = 0;
const std::size_t RDB_RIEGL_RGBA_GREEN = 1;
const std::size_t RDB_RIEGL_RGBA_BLUE = 2;
const std::size_t RDB_RIEGL_RGBA_ALPHA = 3;

// Point near infrared (NIR) value derived from NIR camera
const PointAttribute RDB_RIEGL_NIR(
    /* name               */ "riegl.nir",
    /* title              */ "Near Infrared Brightness",
    /* description        */ "Point near infrared (NIR) value derived from NIR camera",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Target temperature measured by thermal camera
const PointAttribute RDB_RIEGL_TEMPERATURE(
    /* name               */ "riegl.temperature",
    /* title              */ "Temperature",
    /* description        */ "Target temperature measured by thermal camera",
    /* unitSymbol         */ "°C",
    /* length             */ 1,
    /* resolution         */ 0.001,
    /* minimumValue       */ -273.15,
    /* maximumValue       */ 4.0e6,
    /* defaultValue       */ 4.0e6,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 4.0e6,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Index of assigned MTA zone. Nearest MTA zone has index 1
const PointAttribute RDB_RIEGL_MTA_ZONE(
    /* name               */ "riegl.mta_zone",
    /* title              */ "MTA Zone Assigned",
    /* description        */ "Index of assigned MTA zone. Nearest MTA zone has index 1",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 1.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ ""
);

// 1 for points with uncertain MTA zone assignment, 0 for certainly assigned MTA zone
const PointAttribute RDB_RIEGL_MTA_UNCERTAIN_POINT(
    /* name               */ "riegl.mta_uncertain_point",
    /* title              */ "MTA Uncertain Point",
    /* description        */ "1 for points with uncertain MTA zone assignment, 0 for certainly assigned MTA zone",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_MTA_UNCERTAIN_POINT_FALSE = 0;
const std::uint8_t RDB_RIEGL_MTA_UNCERTAIN_POINT_TRUE = 1;

// 1 for all points originating from a full waveform analysis (FWA), 0 for all points originating from online waveform processing (OWP)
const PointAttribute RDB_RIEGL_FWA(
    /* name               */ "riegl.fwa",
    /* title              */ "Full Waveform Analysis",
    /* description        */ "1 for all points originating from a full waveform analysis (FWA), 0 for all points originating from online waveform processing (OWP)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ "0=Origin OWP\n1=Origin FWA\n"
);
const std::uint8_t RDB_RIEGL_FWA_ONLINE_WAVEFORM_PROCESSING = 0;
const std::uint8_t RDB_RIEGL_FWA_FULL_WAVEFORM_ANALYSIS = 1;

// Background Radiation (for VZ-400-HT/HAT only)
const PointAttribute RDB_RIEGL_BACKGROUND_RADIATION(
    /* name               */ "riegl.background_radiation",
    /* title              */ "Background Radiation",
    /* description        */ "Background Radiation (for VZ-400-HT/HAT only)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Background Radiation (for VZ-400-HTo only, Si-PD)
const PointAttribute RDB_RIEGL_BACKGROUND_RADIATION_SI(
    /* name               */ "riegl.background_radiation_si",
    /* title              */ "Background Radiation Si-PD",
    /* description        */ "Background Radiation (for VZ-400-HTo only, Si-PD)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Background Radiation (for VZ-400-HTo only, InGaAs-PD)
const PointAttribute RDB_RIEGL_BACKGROUND_RADIATION_INGAAS(
    /* name               */ "riegl.background_radiation_ingaas",
    /* title              */ "Background Radiation InGaAs-PD",
    /* description        */ "Background Radiation (for VZ-400-HTo only, InGaAs-PD)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Estimated temperature derived from Background Radiation Si-PD
const PointAttribute RDB_RIEGL_TEMPERATURE_ESTIMATED_SI(
    /* name               */ "riegl.temperature_estimated_si",
    /* title              */ "Temperature Estimated Si-PD",
    /* description        */ "Estimated temperature derived from Background Radiation Si-PD",
    /* unitSymbol         */ "°C",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 2000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Estimated temperature derived from Background Radiation InGaAs-PD
const PointAttribute RDB_RIEGL_TEMPERATURE_ESTIMATED_INGAAS(
    /* name               */ "riegl.temperature_estimated_ingaas",
    /* title              */ "Temperature Estimated InGaAs-PD",
    /* description        */ "Estimated temperature derived from Background Radiation InGaAs-PD",
    /* unitSymbol         */ "°C",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 2000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Estimated temperature derived from difference in Background Radiation InGaAs and Si
const PointAttribute RDB_RIEGL_TEMPERATURE_ESTIMATED_INGAAS_SI(
    /* name               */ "riegl.temperature_estimated_ingaas_si",
    /* title              */ "Temperature Estimated InGaAs/Si-PD",
    /* description        */ "Estimated temperature derived from difference in Background Radiation InGaAs and Si",
    /* unitSymbol         */ "°C",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 2000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// nth target of a laser-shot (0 = unknown, 1 = first target, ...)
const PointAttribute RDB_RIEGL_TARGET_INDEX(
    /* name               */ "riegl.target_index",
    /* title              */ "Target Index",
    /* description        */ "nth target of a laser-shot (0 = unknown, 1 = first target, ...)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of targets of a laser-shot (0 = unknown, 1 = one target, ...)
const PointAttribute RDB_RIEGL_TARGET_COUNT(
    /* name               */ "riegl.target_count",
    /* title              */ "Target Count",
    /* description        */ "Number of targets of a laser-shot (0 = unknown, 1 = one target, ...)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Target rank among all targets of a laser-shot (0 = unknown, 1 = single, 2 = first, 3 = intermediate, 4 = last target)
const PointAttribute RDB_RIEGL_TARGET_TYPE(
    /* name               */ "riegl.target_type",
    /* title              */ "Target Type",
    /* description        */ "Target rank among all targets of a laser-shot (0 = unknown, 1 = single, 2 = first, 3 = intermediate, 4 = last target)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "1=Single target\n2=First target\n3=Intermediate target\n4=Last target\n"
);
const std::uint8_t RDB_RIEGL_TARGET_TYPE_UNKNOWN = 0;
const std::uint8_t RDB_RIEGL_TARGET_TYPE_SINGLE = 1;
const std::uint8_t RDB_RIEGL_TARGET_TYPE_FIRST = 2;
const std::uint8_t RDB_RIEGL_TARGET_TYPE_INTERMEDIATE = 3;
const std::uint8_t RDB_RIEGL_TARGET_TYPE_LAST = 4;

// Identifier of first echo that belongs to the laser shot (0 = invalid). This is not an array index but the value of riegl.id of the echo.
const PointAttribute RDB_RIEGL_ECHO_FIRST(
    /* name               */ "riegl.echo_first",
    /* title              */ "Echo First",
    /* description        */ "Identifier of first echo that belongs to the laser shot (0 = invalid). This is not an array index but the value of riegl.id of the echo.",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_ECHO_FIRST_INVALID = 0;

// Number of echoes that belong to the laser shot
const PointAttribute RDB_RIEGL_ECHO_COUNT(
    /* name               */ "riegl.echo_count",
    /* title              */ "Echo Count",
    /* description        */ "Number of echoes that belong to the laser shot",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Height at center of grid cell
const PointAttribute RDB_RIEGL_HEIGHT_CENTER(
    /* name               */ "riegl.height_center",
    /* title              */ "Height Center",
    /* description        */ "Height at center of grid cell",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -100000.0,
    /* maximumValue       */ 100000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Mean height within grid cell
const PointAttribute RDB_RIEGL_HEIGHT_MEAN(
    /* name               */ "riegl.height_mean",
    /* title              */ "Height Mean",
    /* description        */ "Mean height within grid cell",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -100000.0,
    /* maximumValue       */ 100000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Minimum height within grid cell
const PointAttribute RDB_RIEGL_HEIGHT_MIN(
    /* name               */ "riegl.height_min",
    /* title              */ "Height Minimum",
    /* description        */ "Minimum height within grid cell",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -100000.0,
    /* maximumValue       */ 100000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Maximum height within grid cell
const PointAttribute RDB_RIEGL_HEIGHT_MAX(
    /* name               */ "riegl.height_max",
    /* title              */ "Height Maximum",
    /* description        */ "Maximum height within grid cell",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -100000.0,
    /* maximumValue       */ 100000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of points this point represents (e.g. points combined to voxels or plane patches, 0 = unknown)
const PointAttribute RDB_RIEGL_POINT_COUNT(
    /* name               */ "riegl.point_count",
    /* title              */ "Point Count",
    /* description        */ "Number of points this point represents (e.g. points combined to voxels or plane patches, 0 = unknown)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4294967295.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint32_t RDB_RIEGL_POINT_COUNT_UNKNOWN = 0;

// Number of total points in a grid cell this point represents.
const PointAttribute RDB_RIEGL_POINT_COUNT_GRID_CELL(
    /* name               */ "riegl.point_count_grid_cell",
    /* title              */ "Point Count of Grid Cell",
    /* description        */ "Number of total points in a grid cell this point represents.",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4294967295.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint32_t RDB_RIEGL_POINT_COUNT_GRID_CELL_UNKNOWN = 0;

// Volume extents along 0: riegl.pca_axis_max, 1: riegl.pca_axis_min x riegl.pca_axis_max, 2: riegl.pca_axis_min
const PointAttribute RDB_RIEGL_PCA_EXTENTS(
    /* name               */ "riegl.pca_extents",
    /* title              */ "PCA Extents",
    /* description        */ "Volume extents along 0: riegl.pca_axis_max, 1: riegl.pca_axis_min x riegl.pca_axis_max, 2: riegl.pca_axis_min",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 0.00025,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Volume extents along riegl.pca_axis_min or riegl.surface_normal (result of PCA)
const PointAttribute RDB_RIEGL_PCA_THICKNESS(
    /* name               */ "riegl.pca_thickness",
    /* title              */ "PCA Thickness",
    /* description        */ "Volume extents along riegl.pca_axis_min or riegl.surface_normal (result of PCA)",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Standard deviation, e.g. of residual point-to-plane distances (0 = unknown)
const PointAttribute RDB_RIEGL_STD_DEV(
    /* name               */ "riegl.std_dev",
    /* title              */ "Standard Deviation",
    /* description        */ "Standard deviation, e.g. of residual point-to-plane distances (0 = unknown)",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.0001,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65.535,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_STD_DEV_UNKNOWN = 0.0;

// Confidence ellipse for the normal vector of a plane patch (0: up-axis, 1: width-axis, tilt angle wrt. up-axis)
const PointAttribute RDB_RIEGL_PLANE_CONFIDENCE_NORMAL(
    /* name               */ "riegl.plane_confidence_normal",
    /* title              */ "Confidence Normal Direction",
    /* description        */ "Confidence ellipse for the normal vector of a plane patch (0: up-axis, 1: width-axis, tilt angle wrt. up-axis)",
    /* unitSymbol         */ "deg",
    /* length             */ 3,
    /* resolution         */ 0.006,
    /* minimumValue       */ -180.006,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -180.006,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Plane patch slope class number. Meaning see metadata riegl.plane_slope_class_info (0 = invalid)
const PointAttribute RDB_RIEGL_PLANE_SLOPE_CLASS(
    /* name               */ "riegl.plane_slope_class",
    /* title              */ "Plane Patch Slope Class",
    /* description        */ "Plane patch slope class number. Meaning see metadata riegl.plane_slope_class_info (0 = invalid)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ ""
);

// 8x8 occupancy matrix indicating point support of plane patch
const PointAttribute RDB_RIEGL_PLANE_OCCUPANCY(
    /* name               */ "riegl.plane_occupancy",
    /* title              */ "Plane Patch Occupancy",
    /* description        */ "8x8 occupancy matrix indicating point support of plane patch",
    /* unitSymbol         */ "",
    /* length             */ 8,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Size of plane patch along the longer edge (0 = unknown)
const PointAttribute RDB_RIEGL_PLANE_WIDTH(
    /* name               */ "riegl.plane_width",
    /* title              */ "Plane Patch Width",
    /* description        */ "Size of plane patch along the longer edge (0 = unknown)",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.001,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_PLANE_WIDTH_UNKNOWN = 0.0;

// Size of plane patch along the shorter edge (0 = unknown)
const PointAttribute RDB_RIEGL_PLANE_HEIGHT(
    /* name               */ "riegl.plane_height",
    /* title              */ "Plane Patch Height",
    /* description        */ "Size of plane patch along the shorter edge (0 = unknown)",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.001,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_PLANE_HEIGHT_UNKNOWN = 0.0;

// For merged plane patches, the number of plane patches the merged plane patch is based on
const PointAttribute RDB_RIEGL_PLANE_COUNT(
    /* name               */ "riegl.plane_count",
    /* title              */ "Plane Patch Count",
    /* description        */ "For merged plane patches, the number of plane patches the merged plane patch is based on",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// The number of source plane patch files the plane patch has matches to
const PointAttribute RDB_RIEGL_MATCH_COUNT(
    /* name               */ "riegl.match_count",
    /* title              */ "Plane Patch Match Count",
    /* description        */ "The number of source plane patch files the plane patch has matches to",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Distance between the origins of two plane patches, projected onto the average of their normal vectors
const PointAttribute RDB_RIEGL_PLANE_PATCH_DISTANCE(
    /* name               */ "riegl.plane_patch_distance",
    /* title              */ "Plane Patch Distance",
    /* description        */ "Distance between the origins of two plane patches, projected onto the average of their normal vectors",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -2100.0,
    /* maximumValue       */ 2000.0,
    /* defaultValue       */ -2100.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -2100.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_PLANE_PATCH_DISTANCE_LOWEST = -2000.0;

// Distance between the origins of two plane patches, projected onto the plane defined by the average of their normal vectors
const PointAttribute RDB_RIEGL_PLANE_PATCH_LATERAL_DISTANCE(
    /* name               */ "riegl.plane_patch_lateral_distance",
    /* title              */ "Plane Patch Lateral Distance",
    /* description        */ "Distance between the origins of two plane patches, projected onto the plane defined by the average of their normal vectors",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -2100.0,
    /* maximumValue       */ 2000.0,
    /* defaultValue       */ -2100.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -2100.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_PLANE_PATCH_LATERAL_DISTANCE_LOWEST = -2000.0;

// Angle between the normal vectors of two plane patches
const PointAttribute RDB_RIEGL_PLANE_PATCH_ANGULAR_DISTANCE(
    /* name               */ "riegl.plane_patch_angular_distance",
    /* title              */ "Plane Patch Angular Distance",
    /* description        */ "Angle between the normal vectors of two plane patches",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ -1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Accuracy in North direction
const PointAttribute RDB_RIEGL_POF_ACCURACY_NORTH(
    /* name               */ "riegl.pof_accuracy_north",
    /* title              */ "Accuracy North",
    /* description        */ "Accuracy in North direction",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Accuracy in East direction
const PointAttribute RDB_RIEGL_POF_ACCURACY_EAST(
    /* name               */ "riegl.pof_accuracy_east",
    /* title              */ "Accuracy East",
    /* description        */ "Accuracy in East direction",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Accuracy in Down direction
const PointAttribute RDB_RIEGL_POF_ACCURACY_DOWN(
    /* name               */ "riegl.pof_accuracy_down",
    /* title              */ "Accuracy Down",
    /* description        */ "Accuracy in Down direction",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Accuracy of Roll rotation
const PointAttribute RDB_RIEGL_POF_ACCURACY_ROLL(
    /* name               */ "riegl.pof_accuracy_roll",
    /* title              */ "Accuracy Roll",
    /* description        */ "Accuracy of Roll rotation",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Accuracy of Pitch rotation
const PointAttribute RDB_RIEGL_POF_ACCURACY_PITCH(
    /* name               */ "riegl.pof_accuracy_pitch",
    /* title              */ "Accuracy Pitch",
    /* description        */ "Accuracy of Pitch rotation",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Accuracy of Yaw rotation
const PointAttribute RDB_RIEGL_POF_ACCURACY_YAW(
    /* name               */ "riegl.pof_accuracy_yaw",
    /* title              */ "Accuracy Yaw",
    /* description        */ "Accuracy of Yaw rotation",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Waveform sample block channel number (255 = invalid)
const PointAttribute RDB_RIEGL_WFM_SBL_CHANNEL(
    /* name               */ "riegl.wfm_sbl_channel",
    /* title              */ "Waveform Sample Block Channel",
    /* description        */ "Waveform sample block channel number (255 = invalid)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 255.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 255.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=High power\n1=Low power\n3=Reference pulse\n"
);
const std::uint8_t RDB_RIEGL_WFM_SBL_CHANNEL_INVALID = 255;

// Waveform sample value mean
const PointAttribute RDB_RIEGL_WFM_SBL_MEAN(
    /* name               */ "riegl.wfm_sbl_mean",
    /* title              */ "Waveform Sample Value Mean",
    /* description        */ "Waveform sample value mean",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 0.0625,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4095.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Waveform sample value standard deviation
const PointAttribute RDB_RIEGL_WFM_SBL_STD_DEV(
    /* name               */ "riegl.wfm_sbl_std_dev",
    /* title              */ "Waveform Sample Value Standard Deviation",
    /* description        */ "Waveform sample value standard deviation",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 0.25,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Identifier of first waveform sample block that belongs to the laser shot (0 = invalid). This is not an array index but the value of riegl.id of the block.
const PointAttribute RDB_RIEGL_WFM_SBL_FIRST(
    /* name               */ "riegl.wfm_sbl_first",
    /* title              */ "Waveform Sample Block First",
    /* description        */ "Identifier of first waveform sample block that belongs to the laser shot (0 = invalid). This is not an array index but the value of riegl.id of the block.",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_WFM_SBL_FIRST_INVALID = 0;

// Number of waveform sample blocks that belong to the laser shot
const PointAttribute RDB_RIEGL_WFM_SBL_COUNT(
    /* name               */ "riegl.wfm_sbl_count",
    /* title              */ "Waveform Sample Block Count",
    /* description        */ "Number of waveform sample blocks that belong to the laser shot",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Identifier of first waveform sample value that belongs to the sample block (0 = invalid). This is not an array index but the value of riegl.id of the sample.
const PointAttribute RDB_RIEGL_WFM_SDA_FIRST(
    /* name               */ "riegl.wfm_sda_first",
    /* title              */ "Waveform Sample Data First",
    /* description        */ "Identifier of first waveform sample value that belongs to the sample block (0 = invalid). This is not an array index but the value of riegl.id of the sample.",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_WFM_SDA_FIRST_INVALID = 0;

// Number of waveform sample values that belong to the sample block
const PointAttribute RDB_RIEGL_WFM_SDA_COUNT(
    /* name               */ "riegl.wfm_sda_count",
    /* title              */ "Waveform Sample Data Count",
    /* description        */ "Number of waveform sample values that belong to the sample block",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Raw waveform sample value
const PointAttribute RDB_RIEGL_WFM_SAMPLE_VALUE(
    /* name               */ "riegl.wfm_sample_value",
    /* title              */ "Waveform Sample Value",
    /* description        */ "Raw waveform sample value",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Zero-based index of control object type listed in riegl.control_object_catalog (meta data entry)
const PointAttribute RDB_RIEGL_CONTROL_OBJECT_TYPE(
    /* name               */ "riegl.control_object_type",
    /* title              */ "Control Object Type",
    /* description        */ "Zero-based index of control object type listed in riegl.control_object_catalog (meta data entry)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 32767.0,
    /* defaultValue       */ -1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ ""
);

// Model fit quality value between 0 and 1 (0 = unspecified)
const PointAttribute RDB_RIEGL_MODEL_FIT_QUALITY(
    /* name               */ "riegl.model_fit_quality",
    /* title              */ "Model Fit Quality",
    /* description        */ "Model fit quality value between 0 and 1 (0 = unspecified)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 0.001,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Observed inclination angle of the surface in the vicinity of a control point. It is defined as the arccosine of the vertical component of the surface normal vector. Hence: angle = 0 deg: horizontal (floor); angle = 90 deg: vertical (wall); angle = 180 deg: horizontal (ceiling)
const PointAttribute RDB_RIEGL_CP_SURFACE_INCLINATION_ANGLE(
    /* name               */ "riegl.cp_surface_inclination_angle",
    /* title              */ "Surface Inclination Angle",
    /* description        */ "Observed inclination angle of the surface in the vicinity of a control point. It is defined as the arccosine of the vertical component of the surface normal vector. Hence: angle = 0 deg: horizontal (floor); angle = 90 deg: vertical (wall); angle = 180 deg: horizontal (ceiling)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_CP_SURFACE_INCLINATION_ANGLE_FLOOR = 0.0;
const double RDB_RIEGL_CP_SURFACE_INCLINATION_ANGLE_WALL = 90.0;
const double RDB_RIEGL_CP_SURFACE_INCLINATION_ANGLE_CEILING = 180.0;

// Tolerance angle for the inclination of the surface in the vicinity of a control point
const PointAttribute RDB_RIEGL_CP_SURFACE_INCLINATION_TOLERANCE_ANGLE(
    /* name               */ "riegl.cp_surface_inclination_tolerance_angle",
    /* title              */ "Surface Inclination Tolerance Angle",
    /* description        */ "Tolerance angle for the inclination of the surface in the vicinity of a control point",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 180.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Confidence value for xy position of observed point wrt. local observation coordinate system
const PointAttribute RDB_RIEGL_OBS_CONFIDENCE_XY(
    /* name               */ "riegl.obs_confidence_xy",
    /* title              */ "XY confidence of observed point",
    /* description        */ "Confidence value for xy position of observed point wrt. local observation coordinate system",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1e-06,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Confidence value for z position of observed point wrt. local observation coordinate system
const PointAttribute RDB_RIEGL_OBS_CONFIDENCE_Z(
    /* name               */ "riegl.obs_confidence_z",
    /* title              */ "Z confidence of observed point",
    /* description        */ "Confidence value for z position of observed point wrt. local observation coordinate system",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1e-06,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Confidence of observation coordinates in local radial direction (range)
const PointAttribute RDB_RIEGL_OBS_CONFIDENCE_RANGE(
    /* name               */ "riegl.obs_confidence_range",
    /* title              */ "Positional confidence of observation in radial direction",
    /* description        */ "Confidence of observation coordinates in local radial direction (range)",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1e-06,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Confidence of observation coordinates in local elevation direction (theta)
const PointAttribute RDB_RIEGL_OBS_CONFIDENCE_THETA(
    /* name               */ "riegl.obs_confidence_theta",
    /* title              */ "Positional confidence of observation in theta direction",
    /* description        */ "Confidence of observation coordinates in local elevation direction (theta)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1e-06,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Confidence of observation coordinates in local azimuth direction (phi)
const PointAttribute RDB_RIEGL_OBS_CONFIDENCE_PHI(
    /* name               */ "riegl.obs_confidence_phi",
    /* title              */ "Positional confidence of observation in phi direction",
    /* description        */ "Confidence of observation coordinates in local azimuth direction (phi)",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1e-06,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Confidence value for rotation angle within plane of observed signal
const PointAttribute RDB_RIEGL_OBS_SIGNAL_CONFIDENCE_ROT(
    /* name               */ "riegl.obs_signal_confidence_rot",
    /* title              */ "Rotation angle confidence of observed signal",
    /* description        */ "Confidence value for rotation angle within plane of observed signal",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1e-06,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Flag indicating if observation shall be used for adjustment (0 = used as verification point; 1 = used for adjustment)
const PointAttribute RDB_RIEGL_USED_FOR_ADJUSTMENT(
    /* name               */ "riegl.used_for_adjustment",
    /* title              */ "Used for Adjustment",
    /* description        */ "Flag indicating if observation shall be used for adjustment (0 = used as verification point; 1 = used for adjustment)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=Used as verification point\n1=Used for adjustment\n"
);
const std::uint8_t RDB_RIEGL_USED_FOR_ADJUSTMENT_VERIFICATION = 0;
const std::uint8_t RDB_RIEGL_USED_FOR_ADJUSTMENT_ADJUSTMENT = 1;

// ID (riegl.id) of a referenced object (0 = invalid)
const PointAttribute RDB_RIEGL_REFERENCE_OBJECT_ID(
    /* name               */ "riegl.reference_object_id",
    /* title              */ "Reference Object ID",
    /* description        */ "ID (riegl.id) of a referenced object (0 = invalid)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000000000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

//______________________________________________________________________________
//
// POINT ATTRIBUTE GROUP "Secondary Attributes"
//______________________________________________________________________________
//

// Raw range of echo
const PointAttribute RDB_RIEGL_RAW_RANGE(
    /* name               */ "riegl.raw_range",
    /* title              */ "Raw Range",
    /* description        */ "Raw range of echo",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -50000.0,
    /* maximumValue       */ 50000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Raw line angle
const PointAttribute RDB_RIEGL_RAW_LINE_ANGLE(
    /* name               */ "riegl.raw_line_angle",
    /* title              */ "Raw line angle",
    /* description        */ "Raw line angle",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Raw frame angle
const PointAttribute RDB_RIEGL_RAW_FRAME_ANGLE(
    /* name               */ "riegl.raw_frame_angle",
    /* title              */ "Raw frame angle",
    /* description        */ "Raw frame angle",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 1e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Coarse line scan angle
const PointAttribute RDB_RIEGL_LINE_ANGLE_COARSE(
    /* name               */ "riegl.line_angle_coarse",
    /* title              */ "Line Angle Coarse",
    /* description        */ "Coarse line scan angle",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 0.025,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Reduced line scan angle
const PointAttribute RDB_RIEGL_LINE_ANGLE_REDUCED(
    /* name               */ "riegl.line_angle_reduced",
    /* title              */ "Line Angle Reduced",
    /* description        */ "Reduced line scan angle",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 0.025,
    /* minimumValue       */ -360.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Coarse frame scan angle
const PointAttribute RDB_RIEGL_FRAME_ANGLE_COARSE(
    /* name               */ "riegl.frame_angle_coarse",
    /* title              */ "Frame Angle Coarse",
    /* description        */ "Coarse frame scan angle",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 0.001,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 360.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Scan Line Index in Scan
const PointAttribute RDB_RIEGL_SCAN_LINE_INDEX(
    /* name               */ "riegl.scan_line_index",
    /* title              */ "Scan Line Index",
    /* description        */ "Scan Line Index in Scan",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -2000000000.0,
    /* maximumValue       */ 2000000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Laser Shot Index in Scan Line
const PointAttribute RDB_RIEGL_SHOT_INDEX_LINE(
    /* name               */ "riegl.shot_index_line",
    /* title              */ "Laser Shot Index in Line",
    /* description        */ "Laser Shot Index in Scan Line",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -2000000000.0,
    /* maximumValue       */ 2000000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Mirror facet number (0 = invalid, 1 = first facet, ...)
const PointAttribute RDB_RIEGL_MIRROR_FACET(
    /* name               */ "riegl.mirror_facet",
    /* title              */ "Mirror Facet",
    /* description        */ "Mirror facet number (0 = invalid, 1 = first facet, ...)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 15.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_MIRROR_FACET_INVALID = 0;

// Scan segment number (0 = invalid, 1 = first segment, ...)
const PointAttribute RDB_RIEGL_SCAN_SEGMENT(
    /* name               */ "riegl.scan_segment",
    /* title              */ "Scan Segment",
    /* description        */ "Scan segment number (0 = invalid, 1 = first segment, ...)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 15.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_SCAN_SEGMENT_INVALID = 0;

// Waveform data available for laser-shot (0 = no, 1 = yes)
const PointAttribute RDB_RIEGL_WAVEFORM_AVAILABLE(
    /* name               */ "riegl.waveform_available",
    /* title              */ "Waveform Available",
    /* description        */ "Waveform data available for laser-shot (0 = no, 1 = yes)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ "0=No waveform available\n1=Waveform available\n"
);
const std::uint8_t RDB_RIEGL_WAVEFORM_AVAILABLE_FALSE = 0;
const std::uint8_t RDB_RIEGL_WAVEFORM_AVAILABLE_TRUE = 1;

// 1 if the point was refraction corrected, 0 otherwise
const PointAttribute RDB_RIEGL_HYDRO_REFRACTION_CORRECTED(
    /* name               */ "riegl.hydro_refraction_corrected",
    /* title              */ "Refraction-corrected",
    /* description        */ "1 if the point was refraction corrected, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ "0=No refraction correction applied\n1=Refraction correction applied\n"
);
const std::uint8_t RDB_RIEGL_HYDRO_REFRACTION_CORRECTED_FALSE = 0;
const std::uint8_t RDB_RIEGL_HYDRO_REFRACTION_CORRECTED_TRUE = 1;

// Extinction coefficient, i.e. exponential damping coefficient usually present in water bodies. N.B.: The factor is subject to refraction correction.
const PointAttribute RDB_RIEGL_EXTINCTION(
    /* name               */ "riegl.extinction",
    /* title              */ "Extinction Coefficient",
    /* description        */ "Extinction coefficient, i.e. exponential damping coefficient usually present in water bodies. N.B.: The factor is subject to refraction correction.",
    /* unitSymbol         */ "dB/m",
    /* length             */ 1,
    /* resolution         */ 0.001,
    /* minimumValue       */ -30.0,
    /* maximumValue       */ 30.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Amplitude from volumetric backscatter in SVB FWA
const PointAttribute RDB_RIEGL_SVB_AMPLITUDE_VOLUMETRIC(
    /* name               */ "riegl.svb_amplitude_volumetric",
    /* title              */ "SVB Volumetric Backscatter Amplitude",
    /* description        */ "Amplitude from volumetric backscatter in SVB FWA",
    /* unitSymbol         */ "dB",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ -327.68,
    /* maximumValue       */ 327.67,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Indicates surface point from SVB FWA (1 = surface)
const PointAttribute RDB_RIEGL_SVB_SURFACE(
    /* name               */ "riegl.svb_surface",
    /* title              */ "SVB Surface Point",
    /* description        */ "Indicates surface point from SVB FWA (1 = surface)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_SVB_SURFACE_FALSE = 0;
const std::uint8_t RDB_RIEGL_SVB_SURFACE_TRUE = 1;

// Indicates bottom point from SVB FWA (1 = bottom)
const PointAttribute RDB_RIEGL_SVB_BOTTOM(
    /* name               */ "riegl.svb_bottom",
    /* title              */ "SVB Bottom Point",
    /* description        */ "Indicates bottom point from SVB FWA (1 = bottom)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_SVB_BOTTOM_FALSE = 0;
const std::uint8_t RDB_RIEGL_SVB_BOTTOM_TRUE = 1;

// Path length between surface and bottom from SVB FWA
const PointAttribute RDB_RIEGL_SVB_PATH_LENGTH(
    /* name               */ "riegl.svb_path_length",
    /* title              */ "SVB Path Length",
    /* description        */ "Path length between surface and bottom from SVB FWA",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.004,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 200.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// 1 for all points of the first laser shot of a scan line, 0 otherwise
const PointAttribute RDB_RIEGL_START_OF_SCAN_LINE(
    /* name               */ "riegl.start_of_scan_line",
    /* title              */ "Start of Scan Line",
    /* description        */ "1 for all points of the first laser shot of a scan line, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_START_OF_SCAN_LINE_FALSE = 0;
const std::uint8_t RDB_RIEGL_START_OF_SCAN_LINE_TRUE = 1;

// 1 for all points of the last laser shot of a scan line, 0 otherwise
const PointAttribute RDB_RIEGL_END_OF_SCAN_LINE(
    /* name               */ "riegl.end_of_scan_line",
    /* title              */ "End of Scan Line",
    /* description        */ "1 for all points of the last laser shot of a scan line, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_END_OF_SCAN_LINE_FALSE = 0;
const std::uint8_t RDB_RIEGL_END_OF_SCAN_LINE_TRUE = 1;

// see LAS format specification 1.4-R13
const PointAttribute RDB_RIEGL_SCAN_ANGLE(
    /* name               */ "riegl.scan_angle",
    /* title              */ "Scan Angle",
    /* description        */ "see LAS format specification 1.4-R13",
    /* unitSymbol         */ "deg",
    /* length             */ 1,
    /* resolution         */ 0.096,
    /* minimumValue       */ -180.0,
    /* maximumValue       */ 180.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// see LAS format specification 1.4-R13
const PointAttribute RDB_RIEGL_SCAN_DIRECTION(
    /* name               */ "riegl.scan_direction",
    /* title              */ "Scan Direction",
    /* description        */ "see LAS format specification 1.4-R13",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=Negative\n1=Positive\n"
);

// Voxel has been collapsed with neighbor (0 = not collapsed, 1 = collapsed)
const PointAttribute RDB_RIEGL_VOXEL_COLLAPSED(
    /* name               */ "riegl.voxel_collapsed",
    /* title              */ "Voxel Collapsed with Neighbor",
    /* description        */ "Voxel has been collapsed with neighbor (0 = not collapsed, 1 = collapsed)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_VOXEL_COLLAPSED_FALSE = 0;
const std::uint8_t RDB_RIEGL_VOXEL_COLLAPSED_TRUE = 1;

// 1 if the mirror wheel rotates, 0 otherwise
const PointAttribute RDB_RIEGL_LINE_SCAN_ACTIVE(
    /* name               */ "riegl.line_scan_active",
    /* title              */ "Line Scan Active",
    /* description        */ "1 if the mirror wheel rotates, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ -1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::int8_t RDB_RIEGL_LINE_SCAN_ACTIVE_FALSE = 0;
const std::int8_t RDB_RIEGL_LINE_SCAN_ACTIVE_TRUE = 1;

// 1 if the scanner head rotates, 0 otherwise
const PointAttribute RDB_RIEGL_FRAME_SCAN_ACTIVE(
    /* name               */ "riegl.frame_scan_active",
    /* title              */ "Frame Scan Active",
    /* description        */ "1 if the scanner head rotates, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ -1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::int8_t RDB_RIEGL_FRAME_SCAN_ACTIVE_FALSE = 0;
const std::int8_t RDB_RIEGL_FRAME_SCAN_ACTIVE_TRUE = 1;

// 1 if the data acquisition is in progress, 0 otherwise
const PointAttribute RDB_RIEGL_DATA_ACQUISITION_ACTIVE(
    /* name               */ "riegl.data_acquisition_active",
    /* title              */ "Data Acquisition Active",
    /* description        */ "1 if the data acquisition is in progress, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ -1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::int8_t RDB_RIEGL_DATA_ACQUISITION_ACTIVE_FALSE = 0;
const std::int8_t RDB_RIEGL_DATA_ACQUISITION_ACTIVE_TRUE = 1;

// IDs (riegl.id) of plane patches this observation refers to (0 = invalid)
const PointAttribute RDB_RIEGL_PLANE_REFERENCES(
    /* name               */ "riegl.plane_references",
    /* title              */ "Plane Patch References",
    /* description        */ "IDs (riegl.id) of plane patches this observation refers to (0 = invalid)",
    /* unitSymbol         */ "",
    /* length             */ 2,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_PLANE_REFERENCES_INVALID = 0;

// Cumulative distance travelled
const PointAttribute RDB_RIEGL_POF_PATH_LENGTH(
    /* name               */ "riegl.pof_path_length",
    /* title              */ "Path Length",
    /* description        */ "Cumulative distance travelled",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 1.0e-3,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4.0e6,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Position (3D) dilution of precision
const PointAttribute RDB_RIEGL_POF_PDOP(
    /* name               */ "riegl.pof_pdop",
    /* title              */ "PDOP",
    /* description        */ "Position (3D) dilution of precision",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 100.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Horizontal dilution of precision
const PointAttribute RDB_RIEGL_POF_HDOP(
    /* name               */ "riegl.pof_hdop",
    /* title              */ "HDOP",
    /* description        */ "Horizontal dilution of precision",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 100.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Vertical dilution of precision
const PointAttribute RDB_RIEGL_POF_VDOP(
    /* name               */ "riegl.pof_vdop",
    /* title              */ "VDOP",
    /* description        */ "Vertical dilution of precision",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 100.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Age of GNSS RTK corrections (-1 = unknown)
const PointAttribute RDB_RIEGL_POF_AGE_OF_CORRECTIONS(
    /* name               */ "riegl.pof_age_of_corrections",
    /* title              */ "Age Of Corrections",
    /* description        */ "Age of GNSS RTK corrections (-1 = unknown)",
    /* unitSymbol         */ "s",
    /* length             */ 1,
    /* resolution         */ 0.1,
    /* minimumValue       */ -1.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ -1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -1.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Length of GNSS RTK baseline, i.e. the distance between the antennas of the base station and the rover
const PointAttribute RDB_RIEGL_POF_BASELINE_LENGTH(
    /* name               */ "riegl.pof_baseline_length",
    /* title              */ "Baseline Length",
    /* description        */ "Length of GNSS RTK baseline, i.e. the distance between the antennas of the base station and the rover",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.1,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Solution type of GNSS
const PointAttribute RDB_RIEGL_POF_SOLUTION_GNSS(
    /* name               */ "riegl.pof_solution_gnss",
    /* title              */ "GNSS Solution",
    /* description        */ "Solution type of GNSS",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 8.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=GNSS fix invalid\n1=GNSS fix single\n2=GNSS fix DGPS\n3=GNSS fix time only\n4=GNSS fix RTK fixed\n5=GNSS fix RTK float\n6=GNSS fix estimated\n7=GNSS fix manual\n8=GNSS fix simulated\n"
);

// Total number of GNSS satellites that were used to calculate the position
const PointAttribute RDB_RIEGL_POF_SATELLITES_GNSS(
    /* name               */ "riegl.pof_satellites_gnss",
    /* title              */ "Number of GNSS Satellites",
    /* description        */ "Total number of GNSS satellites that were used to calculate the position",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of GPS satellites that were used to calculate the position
const PointAttribute RDB_RIEGL_POF_SATELLITES_GPS(
    /* name               */ "riegl.pof_satellites_gps",
    /* title              */ "Number of GPS Satellites",
    /* description        */ "Number of GPS satellites that were used to calculate the position",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of GLONASS satellites that were used to calculate the position
const PointAttribute RDB_RIEGL_POF_SATELLITES_GLONASS(
    /* name               */ "riegl.pof_satellites_glonass",
    /* title              */ "Number of GLONASS Satellites",
    /* description        */ "Number of GLONASS satellites that were used to calculate the position",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of Beidou satellites that were used to calculate the position
const PointAttribute RDB_RIEGL_POF_SATELLITES_BEIDOU(
    /* name               */ "riegl.pof_satellites_beidou",
    /* title              */ "Number of Beidou Satellites",
    /* description        */ "Number of Beidou satellites that were used to calculate the position",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of Galileo satellites that were used to calculate the position
const PointAttribute RDB_RIEGL_POF_SATELLITES_GALILEO(
    /* name               */ "riegl.pof_satellites_galileo",
    /* title              */ "Number of Galileo Satellites",
    /* description        */ "Number of Galileo satellites that were used to calculate the position",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of Quasi-Zenith Satellite System (QZSS) satellites that were used to calculate the position
const PointAttribute RDB_RIEGL_POF_SATELLITES_QZSS(
    /* name               */ "riegl.pof_satellites_qzss",
    /* title              */ "Number of QZSS Satellites",
    /* description        */ "Number of Quasi-Zenith Satellite System (QZSS) satellites that were used to calculate the position",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Sums of the linear point distances to the pixel corner (0: dx, 1: dy, 2: dz)
const PointAttribute RDB_RIEGL_PIXEL_LINEAR_SUMS(
    /* name               */ "riegl.pixel_linear_sums",
    /* title              */ "Linear Sums",
    /* description        */ "Sums of the linear point distances to the pixel corner (0: dx, 1: dy, 2: dz)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 1e-3,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 64000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PIXEL_LINEAR_SUMS_DX = 0;
const std::size_t RDB_RIEGL_PIXEL_LINEAR_SUMS_DY = 1;
const std::size_t RDB_RIEGL_PIXEL_LINEAR_SUMS_DZ = 2;

// Sums of the square point distances to the pixel corner (0: dx*dx, 1: dy*dy, 2: dz*dz, 3: dx*dy, 4: dy*dz, 5: dx*dz)
const PointAttribute RDB_RIEGL_PIXEL_SQUARE_SUMS(
    /* name               */ "riegl.pixel_square_sums",
    /* title              */ "Square Sums",
    /* description        */ "Sums of the square point distances to the pixel corner (0: dx*dx, 1: dy*dy, 2: dz*dz, 3: dx*dy, 4: dy*dz, 5: dx*dz)",
    /* unitSymbol         */ "m²",
    /* length             */ 6,
    /* resolution         */ 1e-6,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 5120000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_PIXEL_SQUARE_SUMS_DX_DX = 0;
const std::size_t RDB_RIEGL_PIXEL_SQUARE_SUMS_DY_DY = 1;
const std::size_t RDB_RIEGL_PIXEL_SQUARE_SUMS_DZ_DZ = 2;
const std::size_t RDB_RIEGL_PIXEL_SQUARE_SUMS_DX_DY = 3;
const std::size_t RDB_RIEGL_PIXEL_SQUARE_SUMS_DY_DZ = 4;
const std::size_t RDB_RIEGL_PIXEL_SQUARE_SUMS_DX_DZ = 5;

// Estimated shape of point cloud (0 = undefined, 1 = plane, 2 = line, 3 = volume)
const PointAttribute RDB_RIEGL_SHAPE_ID(
    /* name               */ "riegl.shape_id",
    /* title              */ "Point Cloud Shape",
    /* description        */ "Estimated shape of point cloud (0 = undefined, 1 = plane, 2 = line, 3 = volume)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 3.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=Undefined\n1=Plane\n2=Line\n3=Volume\n"
);
const std::uint8_t RDB_RIEGL_SHAPE_ID_UNDEFINED = 0;
const std::uint8_t RDB_RIEGL_SHAPE_ID_PLANE = 1;
const std::uint8_t RDB_RIEGL_SHAPE_ID_LINE = 2;
const std::uint8_t RDB_RIEGL_SHAPE_ID_VOLUME = 3;

// The plane cluster ID this point belongs to (0 = no cluster)
const PointAttribute RDB_RIEGL_PLANE_CLUSTER_ID(
    /* name               */ "riegl.plane_cluster_id",
    /* title              */ "Plane Cluster ID",
    /* description        */ "The plane cluster ID this point belongs to (0 = no cluster)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4000000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// The segment ID this point belongs to (0 = no segment)
const PointAttribute RDB_RIEGL_SEGMENT_ID(
    /* name               */ "riegl.segment_id",
    /* title              */ "Segment ID",
    /* description        */ "The segment ID this point belongs to (0 = no segment)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4000000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Sums of the linear point distances to the voxel corner (0: dx, 1: dy, 2: dz)
const PointAttribute RDB_RIEGL_VOXEL_LINEAR_SUMS(
    /* name               */ "riegl.voxel_linear_sums",
    /* title              */ "Linear Sums",
    /* description        */ "Sums of the linear point distances to the voxel corner (0: dx, 1: dy, 2: dz)",
    /* unitSymbol         */ "m",
    /* length             */ 3,
    /* resolution         */ 2.5e-4,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 16000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_VOXEL_LINEAR_SUMS_DX = 0;
const std::size_t RDB_RIEGL_VOXEL_LINEAR_SUMS_DY = 1;
const std::size_t RDB_RIEGL_VOXEL_LINEAR_SUMS_DZ = 2;

// Sums of the square point distances to the voxel corner (0: dx*dx, 1: dy*dy, 2: dz*dz, 3: dx*dy, 4: dy*dz, 5: dx*dz)
const PointAttribute RDB_RIEGL_VOXEL_SQUARE_SUMS(
    /* name               */ "riegl.voxel_square_sums",
    /* title              */ "Square Sums",
    /* description        */ "Sums of the square point distances to the voxel corner (0: dx*dx, 1: dy*dy, 2: dz*dz, 3: dx*dy, 4: dy*dz, 5: dx*dz)",
    /* unitSymbol         */ "m²",
    /* length             */ 6,
    /* resolution         */ 6.25e-8,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 320000000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::size_t RDB_RIEGL_VOXEL_SQUARE_SUMS_DX_DX = 0;
const std::size_t RDB_RIEGL_VOXEL_SQUARE_SUMS_DY_DY = 1;
const std::size_t RDB_RIEGL_VOXEL_SQUARE_SUMS_DZ_DZ = 2;
const std::size_t RDB_RIEGL_VOXEL_SQUARE_SUMS_DX_DY = 3;
const std::size_t RDB_RIEGL_VOXEL_SQUARE_SUMS_DY_DZ = 4;
const std::size_t RDB_RIEGL_VOXEL_SQUARE_SUMS_DX_DZ = 5;

// Integer coordinates of voxel corner
const PointAttribute RDB_RIEGL_VOXEL_INDEX(
    /* name               */ "riegl.voxel_index",
    /* title              */ "Voxel Index",
    /* description        */ "Integer coordinates of voxel corner",
    /* unitSymbol         */ "",
    /* length             */ 3,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4294967295.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Elements 00, 11, 22, 10, 21 and 20 (in that order) of point cloud covariance matrix
const PointAttribute RDB_RIEGL_COVARIANCES(
    /* name               */ "riegl.covariances",
    /* title              */ "Point Cloud Covariances",
    /* description        */ "Elements 00, 11, 22, 10, 21 and 20 (in that order) of point cloud covariance matrix",
    /* unitSymbol         */ "",
    /* length             */ 6,
    /* resolution         */ 1.0e-6,
    /* minimumValue       */ -4.5e9,
    /* maximumValue       */ 4.5e9,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of voxels this point represents (e.g. voxels combined to pixels, 0 = unknown)
const PointAttribute RDB_RIEGL_VOXEL_COUNT(
    /* name               */ "riegl.voxel_count",
    /* title              */ "Voxel Count",
    /* description        */ "Number of voxels this point represents (e.g. voxels combined to pixels, 0 = unknown)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4294967295.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint32_t RDB_RIEGL_VOXEL_COUNT_UNKNOWN = 0;

// Point identifier, unique within database (0 = invalid)
const PointAttribute RDB_RIEGL_ID(
    /* name               */ "riegl.id",
    /* title              */ "PID",
    /* description        */ "Point identifier, unique within database (0 = invalid)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_ID_INVALID = 0;

// Identifier of first vertex that belongs to a geometry object (e.g. polyline) (0 = invalid)
const PointAttribute RDB_RIEGL_VERTEX_FIRST(
    /* name               */ "riegl.vertex_first",
    /* title              */ "Vertex First",
    /* description        */ "Identifier of first vertex that belongs to a geometry object (e.g. polyline) (0 = invalid)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 4294967295.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Number of vertices that belong to a geometry object (e.g. polyline)
const PointAttribute RDB_RIEGL_VERTEX_COUNT(
    /* name               */ "riegl.vertex_count",
    /* title              */ "Vertex Count",
    /* description        */ "Number of vertices that belong to a geometry object (e.g. polyline)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Search radius for finding the control point in the scan data. This value (if valid) shall be preferred over that of the common settings when finding observation points for the respective control point.
const PointAttribute RDB_RIEGL_CP_SEARCH_RADIUS(
    /* name               */ "riegl.cp_search_radius",
    /* title              */ "Search Radius",
    /* description        */ "Search radius for finding the control point in the scan data. This value (if valid) shall be preferred over that of the common settings when finding observation points for the respective control point.",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 655.35,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_CP_SEARCH_RADIUS_INVALID = 0.0;

// Maximum accepted distance of an observed control point from SOCS center. This value (if valid) shall be preferred over that of the common settings when finding observation points for the respective control point.
const PointAttribute RDB_RIEGL_CP_MAXIMUM_DISTANCE(
    /* name               */ "riegl.cp_maximum_distance",
    /* title              */ "Maximum distance",
    /* description        */ "Maximum accepted distance of an observed control point from SOCS center. This value (if valid) shall be preferred over that of the common settings when finding observation points for the respective control point.",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.1,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 50000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_CP_MAXIMUM_DISTANCE_INVALID = 0.0;

//______________________________________________________________________________
//
// POINT ATTRIBUTE GROUP "Other Attributes"
//______________________________________________________________________________
//

// Point selected by user (0 = not selected, 1 = selected)
const PointAttribute RDB_RIEGL_SELECTED(
    /* name               */ "riegl.selected",
    /* title              */ "Selected",
    /* description        */ "Point selected by user (0 = not selected, 1 = selected)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_DYNAMIC,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_SELECTED_FALSE = 0;
const std::uint8_t RDB_RIEGL_SELECTED_TRUE = 1;

// Point visible (i.e. not hidden) in view (0 = hidden, 1 = visible)
const PointAttribute RDB_RIEGL_VISIBLE(
    /* name               */ "riegl.visible",
    /* title              */ "Visible",
    /* description        */ "Point visible (i.e. not hidden) in view (0 = hidden, 1 = visible)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_DYNAMIC,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_VISIBLE_FALSE = 0;
const std::uint8_t RDB_RIEGL_VISIBLE_TRUE = 1;

// ID of original point cloud (0 = unknown)
const PointAttribute RDB_RIEGL_SOURCE_CLOUD_ID(
    /* name               */ "riegl.source_cloud_id",
    /* title              */ "Point Cloud ID",
    /* description        */ "ID of original point cloud (0 = unknown)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 10000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint16_t RDB_RIEGL_SOURCE_CLOUD_ID_UNKNOWN = 0;

// For points merged from multiple source files, the number of source files contributing to the point (0 = unknown)
const PointAttribute RDB_RIEGL_SOURCE_CLOUD_COUNT(
    /* name               */ "riegl.source_cloud_count",
    /* title              */ "Point Cloud Count",
    /* description        */ "For points merged from multiple source files, the number of source files contributing to the point (0 = unknown)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 65535.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint16_t RDB_RIEGL_SOURCE_CLOUD_COUNT_UNKNOWN = 0;

// Index of point in original point cloud (0 = unknown)
const PointAttribute RDB_RIEGL_SOURCE_INDEX(
    /* name               */ "riegl.source_index",
    /* title              */ "Point Index",
    /* description        */ "Index of point in original point cloud (0 = unknown)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_SOURCE_INDEX_UNKNOWN = 0;

// 0 for all points derived by standard waveform processing, 1 for additional points derived from interpolation, other enum values to be defined separately
const PointAttribute RDB_RIEGL_SOURCE_INDICATOR(
    /* name               */ "riegl.source_indicator",
    /* title              */ "Source Indicator",
    /* description        */ "0 for all points derived by standard waveform processing, 1 for additional points derived from interpolation, other enum values to be defined separately",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 255.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "enumeration",
    /* namedValues        */ "0=Standard processing\n1=Target interpolation\n"
);
const std::uint8_t RDB_RIEGL_SOURCE_INDICATOR_STANDARD_PROCESSING = 0;
const std::uint8_t RDB_RIEGL_SOURCE_INDICATOR_TARGET_INTERPOLATION = 1;

// Marks points that belong to dynamic objects (0 = no dynamic object, 1 = dynamic object)
const PointAttribute RDB_RIEGL_DYNAMIC_OBJECT_POINT(
    /* name               */ "riegl.dynamic_object_point",
    /* title              */ "Dynamic Object Point",
    /* description        */ "Marks points that belong to dynamic objects (0 = no dynamic object, 1 = dynamic object)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);

// Marks points that originate from one source file (0 = multiple source files, 1 = single source file)
const PointAttribute RDB_RIEGL_SINGLE_SOURCE_POINT(
    /* name               */ "riegl.single_source_point",
    /* title              */ "Single Source Point",
    /* description        */ "Marks points that originate from one source file (0 = multiple source files, 1 = single source file)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 1.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);

// Marks points that belong to mirror objects (0 = no mirror object, 1 = mirror object)
const PointAttribute RDB_RIEGL_MIRROR_OBJECT_POINT(
    /* name               */ "riegl.mirror_object_point",
    /* title              */ "Mirror Object Point",
    /* description        */ "Marks points that belong to mirror objects (0 = no mirror object, 1 = mirror object)",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);

// 1 for all points in temporal vicinity of echoes from the exit aperture and corrected for the impact of the exit pane on amplitude and range, 0 otherwise
const PointAttribute RDB_RIEGL_WINDOW_ECHO_IMPACT_CORRECTED(
    /* name               */ "riegl.window_echo_impact_corrected",
    /* title              */ "Window Echo Impact Corrected",
    /* description        */ "1 for all points in temporal vicinity of echoes from the exit aperture and corrected for the impact of the exit pane on amplitude and range, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ "0=Not impacted by exit aperture\n1=Impacted by exit aperture\n"
);
const std::uint8_t RDB_RIEGL_WINDOW_ECHO_IMPACT_CORRECTED_FALSE = 0;
const std::uint8_t RDB_RIEGL_WINDOW_ECHO_IMPACT_CORRECTED_TRUE = 1;

// 1 for all points with an echo signal amplitude below the dynamic trigger level, 0 otherwise
const PointAttribute RDB_RIEGL_DYNTRIG_UNCERTAIN_POINT(
    /* name               */ "riegl.dyntrig_uncertain_point",
    /* title              */ "Dyntrig Uncertain Point",
    /* description        */ "1 for all points with an echo signal amplitude below the dynamic trigger level, 0 otherwise",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DEFAULT,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "boolean",
    /* namedValues        */ ""
);
const std::uint8_t RDB_RIEGL_DYNTRIG_UNCERTAIN_POINT_FALSE = 0;
const std::uint8_t RDB_RIEGL_DYNTRIG_UNCERTAIN_POINT_TRUE = 1;

// Altitude determined based on the atmospheric pressure according to the standard atmosphere laws
const PointAttribute RDB_RIEGL_BAROMETRIC_HEIGHT_AMSL(
    /* name               */ "riegl.barometric_height_amsl",
    /* title              */ "Barometric Altitude",
    /* description        */ "Altitude determined based on the atmospheric pressure according to the standard atmosphere laws",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.01,
    /* minimumValue       */ -100.0,
    /* maximumValue       */ 10000.0,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ RDB_NO_INVALID_VALUE,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);

// Distance between point and a reference surface (values less than -2000.0 mean no distance available)
const PointAttribute RDB_RIEGL_DISTANCE_TO_SURFACE(
    /* name               */ "riegl.distance_to_surface",
    /* title              */ "Distance to Surface",
    /* description        */ "Distance between point and a reference surface (values less than -2000.0 mean no distance available)",
    /* unitSymbol         */ "m",
    /* length             */ 1,
    /* resolution         */ 0.00025,
    /* minimumValue       */ -2100.0,
    /* maximumValue       */ 2000.0,
    /* defaultValue       */ -2100.0,
    /* storageClass       */ RDB_STORAGE_VARIABLE,
    /* compressionOptions */ RDB_COMPRESSION_SHUFFLE,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ -2100.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const double RDB_RIEGL_DISTANCE_TO_SURFACE_LOWEST = -2000.0;

// Identifier of laser shot (0 = invalid). This is not an array index but the value of riegl.id of the laser shot.
const PointAttribute RDB_RIEGL_SHOT_ID(
    /* name               */ "riegl.shot_id",
    /* title              */ "Shot ID",
    /* description        */ "Identifier of laser shot (0 = invalid). This is not an array index but the value of riegl.id of the laser shot.",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_SHOT_ID_INVALID = 0;

// Identifier of waveform sample block (0 = invalid). This is not an array index but the value of riegl.id of the block.
const PointAttribute RDB_RIEGL_WFM_SBL_ID(
    /* name               */ "riegl.wfm_sbl_id",
    /* title              */ "Waveform Sample Block ID",
    /* description        */ "Identifier of waveform sample block (0 = invalid). This is not an array index but the value of riegl.id of the block.",
    /* unitSymbol         */ "",
    /* length             */ 1,
    /* resolution         */ 1.0,
    /* minimumValue       */ 0.0,
    /* maximumValue       */ 1.0e12,
    /* defaultValue       */ 0.0,
    /* storageClass       */ RDB_STORAGE_CONSTANT,
    /* compressionOptions */ RDB_COMPRESSION_DELTA,
    /* scaleFactor        */ 1.0,
    /* invalidValue       */ 0.0,
    /* lodSettings        */ "default",
    /* tags               */ "",
    /* namedValues        */ ""
);
const std::uint64_t RDB_RIEGL_WFM_SBL_ID_INVALID = 0;

// Table of all point attribute details records
const PointAttribute* const RDB_POINT_ATTRIBUTES[] = {
    &RDB_RIEGL_XYZ,
    &RDB_RIEGL_XYZ_SOCS,
    &RDB_RIEGL_XYZ_MAP,
    &RDB_RIEGL_XY_MAP,
    &RDB_RIEGL_XYZ_CORRECTIONS,
    &RDB_RIEGL_RANGE,
    &RDB_RIEGL_THETA,
    &RDB_RIEGL_PHI,
    &RDB_RIEGL_SCANNER_POSITION,
    &RDB_RIEGL_DIRECTION,
    &RDB_RIEGL_DIRECTION_MEDIUM,
    &RDB_RIEGL_DIRECTION_COARSE,
    &RDB_RIEGL_SHOT_ORIGIN,
    &RDB_RIEGL_SHOT_BIAXIAL_SHIFT,
    &RDB_RIEGL_SHOT_DIRECTION,
    &RDB_RIEGL_SHOT_DIRECTION_LEVELLED,
    &RDB_RIEGL_SURFACE_NORMAL,
    &RDB_RIEGL_PLANE_UP,
    &RDB_RIEGL_PLANE_COG_LINK,
    &RDB_RIEGL_PLANE_PATCH_LINK_VECTOR,
    &RDB_RIEGL_PCA_AXIS_MIN,
    &RDB_RIEGL_PCA_AXIS_MAX,
    &RDB_RIEGL_MODEL_CS_AXIS_X,
    &RDB_RIEGL_MODEL_CS_AXIS_Y,
    &RDB_RIEGL_MODEL_CS_AXIS_Z,
    &RDB_RIEGL_ACCELEROMETER,
    &RDB_RIEGL_GYROSCOPE,
    &RDB_RIEGL_MAGNETIC_FIELD_SENSOR,
    &RDB_RIEGL_ACCELEROMETER_RAW,
    &RDB_RIEGL_GYROSCOPE_RAW,
    &RDB_RIEGL_MAGNETIC_FIELD_SENSOR_RAW,
    &RDB_RIEGL_POF_LATITUDE,
    &RDB_RIEGL_POF_LONGITUDE,
    &RDB_RIEGL_POF_HEIGHT,
    &RDB_RIEGL_POF_ROLL,
    &RDB_RIEGL_POF_PITCH,
    &RDB_RIEGL_POF_YAW,
    &RDB_RIEGL_POF_XYZ,
    &RDB_RIEGL_POF_ROLL_NED,
    &RDB_RIEGL_POF_PITCH_NED,
    &RDB_RIEGL_POF_YAW_NED,
    &RDB_RIEGL_HYDRO_INTERSECTION_POINT,
    &RDB_RIEGL_HYDRO_INTERSECTION_NORMAL,
    &RDB_RIEGL_HYDRO_WSM_UNCERTAINTY,
    &RDB_RIEGL_XYZ_ACCURACIES,
    &RDB_RIEGL_ZENITH_VECTOR,
    &RDB_RIEGL_SHOT_TIMESTAMP_HR,
    &RDB_RIEGL_TIMESTAMP,
    &RDB_RIEGL_WFM_SBL_TIME_OFFSET,
    &RDB_RIEGL_WFM_ECHO_TIME_OFFSET,
    &RDB_RIEGL_PPS_TIMESTAMP_EXTERN,
    &RDB_RIEGL_PPS_TIMESTAMP_INTERN,
    &RDB_RIEGL_TIMESTAMP_MIN,
    &RDB_RIEGL_TIMESTAMP_MAX,
    &RDB_RIEGL_POF_TIMESTAMP,
    &RDB_RIEGL_ACQUISITION_DATE,
    &RDB_RIEGL_REFLECTANCE,
    &RDB_RIEGL_AMPLITUDE,
    &RDB_RIEGL_INTENSITY,
    &RDB_RIEGL_GAIN,
    &RDB_RIEGL_DEVIATION,
    &RDB_RIEGL_PULSE_WIDTH,
    &RDB_RIEGL_CLASS,
    &RDB_RIEGL_RGBA,
    &RDB_RIEGL_NIR,
    &RDB_RIEGL_TEMPERATURE,
    &RDB_RIEGL_MTA_ZONE,
    &RDB_RIEGL_MTA_UNCERTAIN_POINT,
    &RDB_RIEGL_FWA,
    &RDB_RIEGL_BACKGROUND_RADIATION,
    &RDB_RIEGL_BACKGROUND_RADIATION_SI,
    &RDB_RIEGL_BACKGROUND_RADIATION_INGAAS,
    &RDB_RIEGL_TEMPERATURE_ESTIMATED_SI,
    &RDB_RIEGL_TEMPERATURE_ESTIMATED_INGAAS,
    &RDB_RIEGL_TEMPERATURE_ESTIMATED_INGAAS_SI,
    &RDB_RIEGL_TARGET_INDEX,
    &RDB_RIEGL_TARGET_COUNT,
    &RDB_RIEGL_TARGET_TYPE,
    &RDB_RIEGL_ECHO_FIRST,
    &RDB_RIEGL_ECHO_COUNT,
    &RDB_RIEGL_HEIGHT_CENTER,
    &RDB_RIEGL_HEIGHT_MEAN,
    &RDB_RIEGL_HEIGHT_MIN,
    &RDB_RIEGL_HEIGHT_MAX,
    &RDB_RIEGL_POINT_COUNT,
    &RDB_RIEGL_POINT_COUNT_GRID_CELL,
    &RDB_RIEGL_PCA_EXTENTS,
    &RDB_RIEGL_PCA_THICKNESS,
    &RDB_RIEGL_STD_DEV,
    &RDB_RIEGL_PLANE_CONFIDENCE_NORMAL,
    &RDB_RIEGL_PLANE_SLOPE_CLASS,
    &RDB_RIEGL_PLANE_OCCUPANCY,
    &RDB_RIEGL_PLANE_WIDTH,
    &RDB_RIEGL_PLANE_HEIGHT,
    &RDB_RIEGL_PLANE_COUNT,
    &RDB_RIEGL_MATCH_COUNT,
    &RDB_RIEGL_PLANE_PATCH_DISTANCE,
    &RDB_RIEGL_PLANE_PATCH_LATERAL_DISTANCE,
    &RDB_RIEGL_PLANE_PATCH_ANGULAR_DISTANCE,
    &RDB_RIEGL_POF_ACCURACY_NORTH,
    &RDB_RIEGL_POF_ACCURACY_EAST,
    &RDB_RIEGL_POF_ACCURACY_DOWN,
    &RDB_RIEGL_POF_ACCURACY_ROLL,
    &RDB_RIEGL_POF_ACCURACY_PITCH,
    &RDB_RIEGL_POF_ACCURACY_YAW,
    &RDB_RIEGL_WFM_SBL_CHANNEL,
    &RDB_RIEGL_WFM_SBL_MEAN,
    &RDB_RIEGL_WFM_SBL_STD_DEV,
    &RDB_RIEGL_WFM_SBL_FIRST,
    &RDB_RIEGL_WFM_SBL_COUNT,
    &RDB_RIEGL_WFM_SDA_FIRST,
    &RDB_RIEGL_WFM_SDA_COUNT,
    &RDB_RIEGL_WFM_SAMPLE_VALUE,
    &RDB_RIEGL_CONTROL_OBJECT_TYPE,
    &RDB_RIEGL_MODEL_FIT_QUALITY,
    &RDB_RIEGL_CP_SURFACE_INCLINATION_ANGLE,
    &RDB_RIEGL_CP_SURFACE_INCLINATION_TOLERANCE_ANGLE,
    &RDB_RIEGL_OBS_CONFIDENCE_XY,
    &RDB_RIEGL_OBS_CONFIDENCE_Z,
    &RDB_RIEGL_OBS_CONFIDENCE_RANGE,
    &RDB_RIEGL_OBS_CONFIDENCE_THETA,
    &RDB_RIEGL_OBS_CONFIDENCE_PHI,
    &RDB_RIEGL_OBS_SIGNAL_CONFIDENCE_ROT,
    &RDB_RIEGL_USED_FOR_ADJUSTMENT,
    &RDB_RIEGL_REFERENCE_OBJECT_ID,
    &RDB_RIEGL_RAW_RANGE,
    &RDB_RIEGL_RAW_LINE_ANGLE,
    &RDB_RIEGL_RAW_FRAME_ANGLE,
    &RDB_RIEGL_LINE_ANGLE_COARSE,
    &RDB_RIEGL_LINE_ANGLE_REDUCED,
    &RDB_RIEGL_FRAME_ANGLE_COARSE,
    &RDB_RIEGL_SCAN_LINE_INDEX,
    &RDB_RIEGL_SHOT_INDEX_LINE,
    &RDB_RIEGL_MIRROR_FACET,
    &RDB_RIEGL_SCAN_SEGMENT,
    &RDB_RIEGL_WAVEFORM_AVAILABLE,
    &RDB_RIEGL_HYDRO_REFRACTION_CORRECTED,
    &RDB_RIEGL_EXTINCTION,
    &RDB_RIEGL_SVB_AMPLITUDE_VOLUMETRIC,
    &RDB_RIEGL_SVB_SURFACE,
    &RDB_RIEGL_SVB_BOTTOM,
    &RDB_RIEGL_SVB_PATH_LENGTH,
    &RDB_RIEGL_START_OF_SCAN_LINE,
    &RDB_RIEGL_END_OF_SCAN_LINE,
    &RDB_RIEGL_SCAN_ANGLE,
    &RDB_RIEGL_SCAN_DIRECTION,
    &RDB_RIEGL_VOXEL_COLLAPSED,
    &RDB_RIEGL_LINE_SCAN_ACTIVE,
    &RDB_RIEGL_FRAME_SCAN_ACTIVE,
    &RDB_RIEGL_DATA_ACQUISITION_ACTIVE,
    &RDB_RIEGL_PLANE_REFERENCES,
    &RDB_RIEGL_POF_PATH_LENGTH,
    &RDB_RIEGL_POF_PDOP,
    &RDB_RIEGL_POF_HDOP,
    &RDB_RIEGL_POF_VDOP,
    &RDB_RIEGL_POF_AGE_OF_CORRECTIONS,
    &RDB_RIEGL_POF_BASELINE_LENGTH,
    &RDB_RIEGL_POF_SOLUTION_GNSS,
    &RDB_RIEGL_POF_SATELLITES_GNSS,
    &RDB_RIEGL_POF_SATELLITES_GPS,
    &RDB_RIEGL_POF_SATELLITES_GLONASS,
    &RDB_RIEGL_POF_SATELLITES_BEIDOU,
    &RDB_RIEGL_POF_SATELLITES_GALILEO,
    &RDB_RIEGL_POF_SATELLITES_QZSS,
    &RDB_RIEGL_PIXEL_LINEAR_SUMS,
    &RDB_RIEGL_PIXEL_SQUARE_SUMS,
    &RDB_RIEGL_SHAPE_ID,
    &RDB_RIEGL_PLANE_CLUSTER_ID,
    &RDB_RIEGL_SEGMENT_ID,
    &RDB_RIEGL_VOXEL_LINEAR_SUMS,
    &RDB_RIEGL_VOXEL_SQUARE_SUMS,
    &RDB_RIEGL_VOXEL_INDEX,
    &RDB_RIEGL_COVARIANCES,
    &RDB_RIEGL_VOXEL_COUNT,
    &RDB_RIEGL_ID,
    &RDB_RIEGL_VERTEX_FIRST,
    &RDB_RIEGL_VERTEX_COUNT,
    &RDB_RIEGL_CP_SEARCH_RADIUS,
    &RDB_RIEGL_CP_MAXIMUM_DISTANCE,
    &RDB_RIEGL_SELECTED,
    &RDB_RIEGL_VISIBLE,
    &RDB_RIEGL_SOURCE_CLOUD_ID,
    &RDB_RIEGL_SOURCE_CLOUD_COUNT,
    &RDB_RIEGL_SOURCE_INDEX,
    &RDB_RIEGL_SOURCE_INDICATOR,
    &RDB_RIEGL_DYNAMIC_OBJECT_POINT,
    &RDB_RIEGL_SINGLE_SOURCE_POINT,
    &RDB_RIEGL_MIRROR_OBJECT_POINT,
    &RDB_RIEGL_WINDOW_ECHO_IMPACT_CORRECTED,
    &RDB_RIEGL_DYNTRIG_UNCERTAIN_POINT,
    &RDB_RIEGL_BAROMETRIC_HEIGHT_AMSL,
    &RDB_RIEGL_DISTANCE_TO_SURFACE,
    &RDB_RIEGL_SHOT_ID,
    &RDB_RIEGL_WFM_SBL_ID
};
const std::size_t RDB_POINT_ATTRIBUTE_COUNT(
    sizeof(RDB_POINT_ATTRIBUTES) / sizeof(RDB_POINT_ATTRIBUTES[0])
);
const std::vector<const PointAttribute*> RDB_POINT_ATTRIBUTES_VECTOR(
    RDB_POINT_ATTRIBUTES, RDB_POINT_ATTRIBUTES + RDB_POINT_ATTRIBUTE_COUNT
);

// Table of all point attribute group names
// (same length+order as RDB_POINT_ATTRIBUTES)
const std::string RDB_POINT_ATTRIBUTE_GROUPS[] = {
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Coordinates/Vectors",
    "Time",
    "Time",
    "Time",
    "Time",
    "Time",
    "Time",
    "Time",
    "Time",
    "Time",
    "Time",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Primary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Secondary Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes",
    "Other Attributes"
};

// Point attribute tags
const std::string RDB_TAG_BOOLEAN = "boolean"; // state/flag
const std::string RDB_TAG_COLOR = "color"; // color values
const std::string RDB_TAG_DIRECTION = "direction"; // direction vector
const std::string RDB_TAG_ENUMERATION = "enumeration"; // finite set of unique values, optionally with a name
const std::string RDB_TAG_POSITION = "position"; // position vector
const std::string RDB_TAG_TRANSFORM = "transform"; // transform position or direction vector during import/export

// Table of all point attribute tags (alphabetical order)
const std::string RDB_POINT_ATTRIBUTE_TAGS[] = {
    RDB_TAG_BOOLEAN,
    RDB_TAG_COLOR,
    RDB_TAG_DIRECTION,
    RDB_TAG_ENUMERATION,
    RDB_TAG_POSITION,
    RDB_TAG_TRANSFORM
};
const std::size_t RDB_POINT_ATTRIBUTE_TAG_COUNT(
    sizeof(RDB_POINT_ATTRIBUTE_TAGS) / sizeof(RDB_POINT_ATTRIBUTE_TAGS[0])
);
const std::vector<std::string> RDB_POINT_ATTRIBUTE_TAGS_VECTOR(
    RDB_POINT_ATTRIBUTE_TAGS, RDB_POINT_ATTRIBUTE_TAGS + RDB_POINT_ATTRIBUTE_TAG_COUNT
);

}}} // namespace riegl::rdb::pointcloud

#endif // RDB_354CFFB3_BDAA_4E38_98C8_9C09D0C0AD86
