var searchData=
[
  ['library',['library',['../namespaceriegl_1_1rdb_1_1library.html',1,'riegl::rdb']]],
  ['pointattributes',['PointAttributes',['../classriegl_1_1rdb_1_1_pointcloud.html#a408cd3512cc4aea1be031bb250e2374e',1,'riegl::rdb::Pointcloud']]],
  ['pointcloud',['pointcloud',['../namespaceriegl_1_1rdb_1_1pointcloud.html',1,'riegl::rdb']]],
  ['rdb',['rdb',['../namespaceriegl_1_1rdb.html',1,'riegl']]],
  ['rdb',['rdb',['../classriegl_1_1rdb_1_1pointcloud_1_1_transaction.html#aed63bc28612eaaa227c7338bbb38e642',1,'riegl::rdb::pointcloud::Transaction']]],
  ['rdb_2ehpp',['rdb.hpp',['../rdb_8hpp.html',1,'']]],
  ['remove',['remove',['../classriegl_1_1rdb_1_1pointcloud_1_1_meta_data.html#ab90004e9c43694c6ed9c4ca78993746d',1,'riegl::rdb::pointcloud::MetaData::remove()'],['../classriegl_1_1rdb_1_1pointcloud_1_1_point_attributes.html#aac7ef475fd692faa108b51c01ea29a18',1,'riegl::rdb::pointcloud::PointAttributes::remove()'],['../classriegl_1_1rdb_1_1_pointcloud.html#af82c9926569c247f53d49db0740c0e1b',1,'riegl::rdb::Pointcloud::remove()']]],
  ['resolution',['resolution',['../classriegl_1_1rdb_1_1pointcloud_1_1_point_attribute.html#aa496890297085b0d807755d591676108',1,'riegl::rdb::pointcloud::PointAttribute']]],
  ['restore',['restore',['../classriegl_1_1rdb_1_1pointcloud_1_1_transactions.html#af8892d258d583af7dd1e443e0f41ab89',1,'riegl::rdb::pointcloud::Transactions']]],
  ['revision',['revision',['../classriegl_1_1rdb_1_1pointcloud_1_1_graph_node.html#a2ed96d2a35961e2eb8b2c9f79e8b2d1b',1,'riegl::rdb::pointcloud::GraphNode::revision()'],['../classriegl_1_1rdb_1_1pointcloud_1_1_query_stat.html#a4703da46ec9f0e784899d328c0265c6c',1,'riegl::rdb::pointcloud::QueryStat::revision(const GraphNode::ID &amp;nodeID, const std::string &amp;attribute, Transaction::ID &amp;revision)'],['../classriegl_1_1rdb_1_1pointcloud_1_1_query_stat.html#ad40dadde855fb340936dad9934bb0459',1,'riegl::rdb::pointcloud::QueryStat::revision(const GraphNode::ID &amp;nodeID, const std::string &amp;attribute)']]],
  ['riegl',['riegl',['../namespaceriegl.html',1,'']]],
  ['riegl_5frdb_5finterface_5fmajor',['RIEGL_RDB_INTERFACE_MAJOR',['../version_8hpp.html#a9295d1ac88ba209a601f881fbc94db5e',1,'RIEGL_RDB_INTERFACE_MAJOR():&#160;version.hpp'],['../version_8template_8hpp.html#a9295d1ac88ba209a601f881fbc94db5e',1,'RIEGL_RDB_INTERFACE_MAJOR():&#160;version.template.hpp']]],
  ['riegl_5frdb_5finterface_5fmicro',['RIEGL_RDB_INTERFACE_MICRO',['../version_8hpp.html#a36d9d9915fc5b5fe1384cc4e2317af45',1,'RIEGL_RDB_INTERFACE_MICRO():&#160;version.hpp'],['../version_8template_8hpp.html#a36d9d9915fc5b5fe1384cc4e2317af45',1,'RIEGL_RDB_INTERFACE_MICRO():&#160;version.template.hpp']]],
  ['riegl_5frdb_5finterface_5fminor',['RIEGL_RDB_INTERFACE_MINOR',['../version_8hpp.html#a761ddacbe601e7febdc0bec47ab40ebc',1,'RIEGL_RDB_INTERFACE_MINOR():&#160;version.hpp'],['../version_8template_8hpp.html#a761ddacbe601e7febdc0bec47ab40ebc',1,'RIEGL_RDB_INTERFACE_MINOR():&#160;version.template.hpp']]],
  ['rollback',['rollback',['../classriegl_1_1rdb_1_1pointcloud_1_1_transactions.html#aa24736f092ccbe512b7502823595e6ac',1,'riegl::rdb::pointcloud::Transactions::rollback()'],['../classriegl_1_1rdb_1_1pointcloud_1_1_transaction_scope.html#ac120d7604bd13c6f894eb4570ed02af2',1,'riegl::rdb::pointcloud::TransactionScope::rollback()']]]
];
