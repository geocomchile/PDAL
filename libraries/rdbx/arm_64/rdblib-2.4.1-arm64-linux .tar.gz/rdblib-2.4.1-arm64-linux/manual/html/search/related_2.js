var searchData=
[
  ['opensettingswrapper',['OpenSettingsWrapper',['../classriegl_1_1rdb_1_1pointcloud_1_1_open_settings.html#aff89fd2f35c2b65392329ee0cda502db',1,'riegl::rdb::pointcloud::OpenSettings']]]
];
