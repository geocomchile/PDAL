var searchData=
[
  ['failedtoparsejson',['FailedToParseJSON',['../classriegl_1_1rdb_1_1_error.html#a86412887e0cec8cf2f546c47c48d5e50a591602a8368d706b6d02e7e084f4fb53',1,'riegl::rdb::Error']]],
  ['featurenotlicensed',['FeatureNotLicensed',['../classriegl_1_1rdb_1_1_error.html#a86412887e0cec8cf2f546c47c48d5e50aeb2f10ba7fbf0c765224785fb43d8abb',1,'riegl::rdb::Error']]],
  ['float32',['FLOAT32',['../namespaceriegl_1_1rdb_1_1pointcloud.html#a31bd0835b98b92b062d4fa88ed034ddbaa3c742fed886f55cfa64078bf1043c56',1,'riegl::rdb::pointcloud']]],
  ['float64',['FLOAT64',['../namespaceriegl_1_1rdb_1_1pointcloud.html#a31bd0835b98b92b062d4fa88ed034ddbaa4c5978352322333b7fa5dbfab890cc1',1,'riegl::rdb::pointcloud']]]
];
