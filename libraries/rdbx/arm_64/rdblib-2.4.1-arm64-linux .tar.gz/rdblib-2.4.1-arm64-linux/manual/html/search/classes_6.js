var searchData=
[
  ['opensettings',['OpenSettings',['../classriegl_1_1rdb_1_1pointcloud_1_1_open_settings.html',1,'riegl::rdb::pointcloud']]]
];
