var searchData=
[
  ['logger',['Logger',['../classriegl_1_1rdb_1_1_context.html#aff02b76416d2846736b7ecd798921a0a',1,'riegl::rdb::Context']]]
];
