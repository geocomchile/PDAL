var searchData=
[
  ['what',['what',['../classriegl_1_1rdb_1_1_error.html#a631f05d0ce98ad9d5acf9fb525fc2928',1,'riegl::rdb::Error']]]
];
