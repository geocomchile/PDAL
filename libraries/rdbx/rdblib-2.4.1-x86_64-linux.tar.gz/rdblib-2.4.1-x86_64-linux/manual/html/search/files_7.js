var searchData=
[
  ['namespaces_2etxt',['namespaces.txt',['../namespaces_8txt.html',1,'']]]
];
