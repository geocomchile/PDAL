var searchData=
[
  ['metadatainvalidname',['MetadataInvalidName',['../classriegl_1_1rdb_1_1_error.html#a86412887e0cec8cf2f546c47c48d5e50a8abeac77c4bfebf9813eb4c0461705bb',1,'riegl::rdb::Error']]],
  ['metadatasignatureerror',['MetadataSignatureError',['../classriegl_1_1rdb_1_1_error.html#a86412887e0cec8cf2f546c47c48d5e50acc3a8a994e7a147c9247bce12bcae358',1,'riegl::rdb::Error']]],
  ['metadatatabletoolarge',['MetadataTableTooLarge',['../classriegl_1_1rdb_1_1_error.html#a86412887e0cec8cf2f546c47c48d5e50a3cbc5109f6693f1197d52adfdc17e10f',1,'riegl::rdb::Error']]],
  ['metadatavalidationfailed',['MetadataValidationFailed',['../classriegl_1_1rdb_1_1_error.html#a86412887e0cec8cf2f546c47c48d5e50afdb6b442fea05eb31fc2f71bb42e90b6',1,'riegl::rdb::Error']]]
];
