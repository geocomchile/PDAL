var searchData=
[
  ['riegl_5frdb_5finterface_5fmajor',['RIEGL_RDB_INTERFACE_MAJOR',['../version_8hpp.html#a9295d1ac88ba209a601f881fbc94db5e',1,'RIEGL_RDB_INTERFACE_MAJOR():&#160;version.hpp'],['../version_8template_8hpp.html#a9295d1ac88ba209a601f881fbc94db5e',1,'RIEGL_RDB_INTERFACE_MAJOR():&#160;version.template.hpp']]],
  ['riegl_5frdb_5finterface_5fmicro',['RIEGL_RDB_INTERFACE_MICRO',['../version_8hpp.html#a36d9d9915fc5b5fe1384cc4e2317af45',1,'RIEGL_RDB_INTERFACE_MICRO():&#160;version.hpp'],['../version_8template_8hpp.html#a36d9d9915fc5b5fe1384cc4e2317af45',1,'RIEGL_RDB_INTERFACE_MICRO():&#160;version.template.hpp']]],
  ['riegl_5frdb_5finterface_5fminor',['RIEGL_RDB_INTERFACE_MINOR',['../version_8hpp.html#a761ddacbe601e7febdc0bec47ab40ebc',1,'RIEGL_RDB_INTERFACE_MINOR():&#160;version.hpp'],['../version_8template_8hpp.html#a761ddacbe601e7febdc0bec47ab40ebc',1,'RIEGL_RDB_INTERFACE_MINOR():&#160;version.template.hpp']]]
];
