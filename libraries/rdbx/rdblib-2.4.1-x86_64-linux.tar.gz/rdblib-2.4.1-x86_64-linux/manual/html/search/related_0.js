var searchData=
[
  ['createsettingswrapper',['CreateSettingsWrapper',['../classriegl_1_1rdb_1_1pointcloud_1_1_create_settings.html#a609e1fcc72cc516134086a911eb0574c',1,'riegl::rdb::pointcloud::CreateSettings']]]
];
