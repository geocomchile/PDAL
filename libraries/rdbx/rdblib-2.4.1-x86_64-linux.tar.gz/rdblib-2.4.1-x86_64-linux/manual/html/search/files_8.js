var searchData=
[
  ['opensettings_2ehpp',['openSettings.hpp',['../open_settings_8hpp.html',1,'']]]
];
